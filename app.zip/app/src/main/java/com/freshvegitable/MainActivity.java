package com.freshvegitable;


import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.widget.RelativeLayout;

import com.freshvegitable.Adapter.ExamplePagerAdapter;
import com.freshvegitable.ViewPagerIndicator.MagicIndicator;
import com.freshvegitable.ViewPagerIndicator.ViewPagerHelper;
import com.freshvegitable.ViewPagerIndicator.autoscroll.AutoScrollViewPager;
import com.freshvegitable.ViewPagerIndicator.circlenavigator.CircleNavigator;
import com.freshvegitable.ViewPagerIndicator.ext.navigator.ScaleCircleNavigator;
import com.freshvegitable.activities.VegitableActivity;
import com.freshvegitable.utils.Constant;

import java.util.Arrays;
import java.util.List;

public class MainActivity extends BaseActivity implements View.OnClickListener {

    private static final String[] CHANNELS = new String[]{"CUPCAKE", "DONUT", "ECLAIR", "GINGERBREAD", "HONEYCOMB", "ICE_CREAM_SANDWICH", "JELLY_BEAN", "KITKAT", "LOLLIPOP", "M", "NOUGAT"};
    private List<String> mDataList = Arrays.asList(CHANNELS);
    private ExamplePagerAdapter mExamplePagerAdapter = new ExamplePagerAdapter(mDataList);

    private AutoScrollViewPager mViewPager;
    RelativeLayout vegitable_RL, fruit_RL, bread_dairy_RL, fresh_special_RL;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        setToViews();
        clickToViews();
        setAdapter();


    }

    @Override
    public void initViews() {
        super.initViews();

        mViewPager = (AutoScrollViewPager) findViewById(R.id.view_pager);
        vegitable_RL = (RelativeLayout) findViewById(R.id.vegitable_RL);
        fruit_RL = (RelativeLayout) findViewById(R.id.fruit_RL);
        bread_dairy_RL = (RelativeLayout) findViewById(R.id.bread_dairy_RL);
        fresh_special_RL = (RelativeLayout) findViewById(R.id.fresh_special_RL);

    }

    @Override
    public void setToViews() {
        super.setToViews();




    }

    @Override
    protected void onResume() {
        super.onResume();

        updateCart();

    }

    @Override
    public void clickToViews() {
        super.clickToViews();

        vegitable_RL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startViewpagerActivity(0);

            }
        });

        fruit_RL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startViewpagerActivity(2);


            }
        });

        bread_dairy_RL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startViewpagerActivity(3);


            }
        });

        fresh_special_RL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startViewpagerActivity(4);

            }
        });

    }

    public void setAdapter() {
        mViewPager.setAdapter(mExamplePagerAdapter);
        initMagicIndicator1();
        mViewPager.startAutoScroll();

        //initMagicIndicator3();
    }

    private void initMagicIndicator1() {
        MagicIndicator magicIndicator = (MagicIndicator) findViewById(R.id.magic_indicator3);
        CircleNavigator circleNavigator = new CircleNavigator(this);
        circleNavigator.setCircleCount(CHANNELS.length);
        circleNavigator.setCircleColor(Color.RED);
        circleNavigator.setCircleClickListener(new CircleNavigator.OnCircleClickListener() {
            @Override
            public void onClick(int index) {
                mViewPager.setCurrentItem(index);
            }
        });
        magicIndicator.setNavigator(circleNavigator);
        ViewPagerHelper.bind(magicIndicator, mViewPager);
    }

    @Override
    public void onClick(View v) {

      /*  switch (v.getId()) {
            case R.id.vegitable_RL:

                startViewpagerActivity(0);
                break;

            case R.id.fruit_RL:
                startViewpagerActivity(2);

                break;

            case R.id.bread_dairy_RL:
                startViewpagerActivity(3);

                break;

            case R.id.fresh_special_RL:
                startViewpagerActivity(4);

                break;
        }*/


    }


   /* private void initMagicIndicator3() {
        MagicIndicator magicIndicator = (MagicIndicator) findViewById(R.id.magic_indicator3);
        ScaleCircleNavigator scaleCircleNavigator = new ScaleCircleNavigator(this);
        scaleCircleNavigator.setCircleCount(CHANNELS.length);
        scaleCircleNavigator.setNormalCircleColor(Color.LTGRAY);
        scaleCircleNavigator.setSelectedCircleColor(Color.DKGRAY);


        scaleCircleNavigator.setCircleClickListener(new ScaleCircleNavigator.OnCircleClickListener() {
            @Override
            public void onClick(int index) {
                mViewPager.setCurrentItem(index);
            }
        });
        magicIndicator.setNavigator(scaleCircleNavigator);
        ViewPagerHelper.bind(magicIndicator, mViewPager);
    }*/


    public void startViewpagerActivity(int pagenumber)
    {
        Bundle bundle = new Bundle();
        Intent intent = new Intent(MainActivity.this, VegitableActivity.class);
        bundle.putInt("pagerTabNumber", pagenumber);
        intent.putExtras(bundle);
        startActivityForResult(intent, Constant.NORMAL);
    }
}
