package com.freshvegitable;


import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.View;
import android.widget.RelativeLayout;

import com.freshvegitable.Adapter.ExamplePagerAdapter;
import com.freshvegitable.SweetAlert.SweetAlertDialog;
import com.freshvegitable.ViewPagerIndicator.MagicIndicator;
import com.freshvegitable.ViewPagerIndicator.ViewPagerHelper;
import com.freshvegitable.ViewPagerIndicator.autoscroll.AutoScrollViewPager;
import com.freshvegitable.ViewPagerIndicator.circlenavigator.CircleNavigator;
import com.freshvegitable.ViewPagerIndicator.ext.navigator.ScaleCircleNavigator;
import com.freshvegitable.Wrappers.AddressWrapper;
import com.freshvegitable.activities.AddressBookAcitvity;
import com.freshvegitable.activities.VegitableActivity;
import com.freshvegitable.utils.Constant;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;

public class MainActivity extends BaseActivity implements View.OnClickListener {

    private static final String[] CHANNELS = new String[]{"CUPCAKE", "DONUT", "ECLAIR", "GINGERBREAD", "HONEYCOMB", "ICE_CREAM_SANDWICH", "JELLY_BEAN", "KITKAT", "LOLLIPOP", "M", "NOUGAT"};
    private List<String> mDataList = Arrays.asList(CHANNELS);
    private ExamplePagerAdapter mExamplePagerAdapter = new ExamplePagerAdapter(mDataList);

    private AutoScrollViewPager mViewPager;
    RelativeLayout vegitable_RL, fruit_RL, bread_dairy_RL, fresh_special_RL;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        setToViews();
        clickToViews();
        setAdapter();

        ParseJsonData();

        ApplicationObj app = (ApplicationObj)getApplication();
        app.getSqlObj().openToWrite();


    }

    @Override
    public void initViews() {
        super.initViews();

        File folder = new File(Constant.FilePath);
        boolean success = true;
        if (!folder.exists()) {

            success = folder.mkdir();
        }
        if (success) {
            //Toast.makeText(MainActivity.this, "Directory Created", Toast.LENGTH_SHORT).show();
        } else {
            //Toast.makeText(MainActivity.this, "Failed - Error", Toast.LENGTH_SHORT).show();
        }

        mViewPager = (AutoScrollViewPager) findViewById(R.id.view_pager);
        vegitable_RL = (RelativeLayout) findViewById(R.id.vegitable_RL);
        fruit_RL = (RelativeLayout) findViewById(R.id.fruit_RL);
        bread_dairy_RL = (RelativeLayout) findViewById(R.id.bread_dairy_RL);
        fresh_special_RL = (RelativeLayout) findViewById(R.id.fresh_special_RL);

    }

    @Override
    public void setToViews() {
        super.setToViews();




    }

    @Override
    public void onResume() {
        super.onResume();

        updateCart();

    }

    @Override
    public void clickToViews() {
        super.clickToViews();

        vegitable_RL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startViewpagerActivity(0);

            }
        });

        fruit_RL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startViewpagerActivity(2);


            }
        });

        bread_dairy_RL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startViewpagerActivity(3);


            }
        });

        fresh_special_RL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startViewpagerActivity(4);

            }
        });

    }

    public void setAdapter() {
        mViewPager.setAdapter(mExamplePagerAdapter);
        initMagicIndicator1();
        mViewPager.startAutoScroll();

        //initMagicIndicator3();
    }

    private void initMagicIndicator1() {
        MagicIndicator magicIndicator = (MagicIndicator) findViewById(R.id.magic_indicator3);
        CircleNavigator circleNavigator = new CircleNavigator(this);
        circleNavigator.setCircleCount(CHANNELS.length);
        circleNavigator.setCircleColor(Color.RED);
        circleNavigator.setCircleClickListener(new CircleNavigator.OnCircleClickListener() {
            @Override
            public void onClick(int index) {
                mViewPager.setCurrentItem(index);
            }
        });
        magicIndicator.setNavigator(circleNavigator);
        ViewPagerHelper.bind(magicIndicator, mViewPager);
    }

    @Override
    public void onClick(View v) {

      /*  switch (v.getId()) {
            case R.id.vegitable_RL:

                startViewpagerActivity(0);
                break;

            case R.id.fruit_RL:
                startViewpagerActivity(2);

                break;

            case R.id.bread_dairy_RL:
                startViewpagerActivity(3);

                break;

            case R.id.fresh_special_RL:
                startViewpagerActivity(4);

                break;
        }*/


    }


   /* private void initMagicIndicator3() {
        MagicIndicator magicIndicator = (MagicIndicator) findViewById(R.id.magic_indicator3);
        ScaleCircleNavigator scaleCircleNavigator = new ScaleCircleNavigator(this);
        scaleCircleNavigator.setCircleCount(CHANNELS.length);
        scaleCircleNavigator.setNormalCircleColor(Color.LTGRAY);
        scaleCircleNavigator.setSelectedCircleColor(Color.DKGRAY);


        scaleCircleNavigator.setCircleClickListener(new ScaleCircleNavigator.OnCircleClickListener() {
            @Override
            public void onClick(int index) {
                mViewPager.setCurrentItem(index);
            }
        });
        magicIndicator.setNavigator(scaleCircleNavigator);
        ViewPagerHelper.bind(magicIndicator, mViewPager);
    }*/


    public void startViewpagerActivity(int pagenumber)
    {
        Bundle bundle = new Bundle();
        Intent intent = new Intent(MainActivity.this, VegitableActivity.class);
        bundle.putInt("pagerTabNumber", pagenumber);
        intent.putExtras(bundle);
        startActivityForResult(intent, Constant.NORMAL);
    }

    public void ParseJsonData()
    {
        Constant.linkedHashMap =  parseJsonData(R.raw.address);
    }

    public LinkedHashMap parseJsonData(int resourceid)
    {
        LinkedHashMap linkedHashMap = new LinkedHashMap();


        String Json_String = null;
        try {

            Json_String = Constant.readTextFile(MainActivity.this,resourceid);

            JSONObject jsonObject = new JSONObject(Json_String);
            String status = jsonObject.getString("status");
            if(status.equalsIgnoreCase("success"))
            {
                JSONArray jsonArray = jsonObject.getJSONArray("data");

                for(int i=0;i <jsonArray.length();i++)
                {
                    JSONObject arr_object = jsonArray.getJSONObject(i);

                    //String group_id = arr_object.getString("group_id");
                    //String itemid = arr_object.getString("item_id");
                    //String unique_id = group_id+"_"+itemid;

                    AddressWrapper wrapper = new AddressWrapper();
                    int Id = (arr_object.getInt("id"));
                    wrapper.setId(arr_object.getInt("id"));
                    wrapper.setName(arr_object.getString("name"));
                    wrapper.setMobile_no(arr_object.getString("mobile_no"));
                    wrapper.setAddress1(arr_object.getString("address1"));
                    wrapper.setAddress2(arr_object.getString("address2"));
                    wrapper.setAddress3(arr_object.getString("address3"));
                    wrapper.setPincode(arr_object.getString("pincode"));
                    wrapper.setCity(arr_object.getString("city"));
                    wrapper.setState(arr_object.getString("state"));
                    wrapper.setCountry(arr_object.getString("country"));

                    linkedHashMap.put(Id,wrapper);

                }
            }


        } catch (Exception e) {
            Log.e(Constant.TAG,"Exception",e);
        }

        return linkedHashMap;
    }



    SweetAlertDialog sweetAlertDialog_Reviewer;
    private class RmClickAsyncTask extends AsyncTask<String, String, String>
    {
        String response = "";
        @Override
        protected void onPreExecute()
        {
            try
            {
                if (sweetAlertDialog_Reviewer != null && sweetAlertDialog_Reviewer.isShowing())
                {
                    sweetAlertDialog_Reviewer.dismiss();
                }
            }
            catch (final Exception e){}
            sweetAlertDialog_Reviewer = new SweetAlertDialog(MainActivity.this, SweetAlertDialog.PROGRESS_TYPE).setTitleText("Please wait...");
            sweetAlertDialog_Reviewer.setCancelable(false);
            sweetAlertDialog_Reviewer.setCanceledOnTouchOutside(false);
            sweetAlertDialog_Reviewer.getProgressHelper().setBarColor(getBaseContext().getResources().getColor(R.color.blue_btn_bg_color));
            sweetAlertDialog_Reviewer.show();
        }

        @Override
        protected String doInBackground(String... params)
        {
            try
            {
                // RMNAME = params[1];
               /* ContentValues values = new ContentValues();
                Log.i(Constants.TAG_REVIEWER, Constants.BASE_URL + "ViewOpp.aspx?loginid="+Login+"&prodid="+params[0]+"&flag="+params[1]);
                PostData postData = new PostData(values, Constants.BASE_URL + "ViewOpp.aspx?loginid="+Login+"&prodid="+params[0]+"&flag="+params[1]);
                response = postData.post();
                response = Constants.decryptPassword(response);*/
            }
            catch (Exception e)
            {
                response = "Error : "+e;
            }
            return response;
        }

        @Override
        protected void onPostExecute(String s)
        {
            /*Log.i(Constants.TAG_REVIEWER, "Response : "+response);
            try
            {
                if(s.contains("Cust_Name") && s.contains("Status"))
                {
                    mParseAndSavePipeLineOpportunities(s, RMNAME);
                }
                else
                {
                    Constants.showAlertCustom("No Records Found!", activity, false);
                }
            }
            catch (Exception e)
            {
                Log.e(Constants.TAG_REVIEWER, "Caught exception", e);
            }
            finally
            {
                sweetAlertDialog_Reviewer.dismiss();
            }*/
        }
    }
}
