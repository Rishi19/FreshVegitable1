package com.freshvegitable.Wrappers;

/**
 * Created by jude on 05-11-2015.
 */
public class VegiWrapper
{
    private String RM_ID;
    private String RM_NAME;
    private String Segment;
    private String PPC;
    private String B_NII;
    private String B_PROCESSING_FEE;
    private String B_SYNDICATION_FEE;
    private String B_LC;
    private String B_BG;
    private String B_FOREX_AND_DERIVATIVES;
    private String B_EXCHANGE;
    private String B_COMMISSION;
    private String B_DERIVATIVES;
    private String B_GFID;
    private String B_IB_INCOME;
    private String B_DCM_INCOME;
    private String B_CA_CDAB;
    private String B_SALARY_CDAB;
    private String B_NO_OF_SALARY_ACCOUNTS;
    private String AYTD_TOTAL_NII;
    private String AYTD_NII_TL;
    private String AYTD_NII_WC;
    private String AYTD_NII_OTHERS;
    private String AYTD_TOTAL_FEES;
    private String AYTD_LC;
    private String AYTD_BG;
    private String AYTD_PROCESSING_FEES;
    private String AYTD_SYNDICATION;
    private String AYTD_FOREX_AND_DERIVATIVES;
    private String AYTD_EXCHANGE;
    private String AYTD_COMMISSION;
    private String AYTD_DERIVATIVES;
    private String AYTD_GFID;
    private String AYTD_DCM;
    private String AYTD_IB_INCOME;
    private String BAR_NII;
    private String BAR_PROC_AND_SYNDICATION_FEES;
    private String BAR_LC_AND_BG_FEES;
    private String BAR_FOREX_AND_DERIVATIVES;
    private String BAR_IB_AND_DCM_INCOME;
    private String BAR_CA_CDAB;
    private String BAR_SALARY_CDAB;
    private String ADV_TOTAL;
    private String ADV_A_MINUS_AND_ABOVE;
    private String ADV_BBB_PLUS;
    private String ADV_BBB_AND_BELOW;
    private String ADV_NON_RATED;
    private String CA_CDAB;
    private String SALARY_CDAB;
    private String NO_OF_NEW_SALARY_ACCTS;
    private String NO_OF_MAPPED_CUSTOMERS;
    private String CNT_OF_CUST_GRTR15_RAROC;
    private String NetAdvances;
    private String AYTD_BILLS;





    public VegiWrapper(String RM_ID, String RM_NAME, String segment, String PPC, String b_NII, String b_PROCESSING_FEE, String b_SYNDICATION_FEE, String b_LC, String b_BG, String b_FOREX_AND_DERIVATIVES, String b_EXCHANGE, String b_COMMISSION, String b_DERIVATIVES, String b_GFID, String b_IB_INCOME, String b_DCM_INCOME, String b_CA_CDAB, String b_SALARY_CDAB, String b_NO_OF_SALARY_ACCOUNTS, String AYTD_TOTAL_NII, String AYTD_NII_TL, String AYTD_NII_WC, String AYTD_NII_OTHERS, String AYTD_TOTAL_FEES, String AYTD_LC, String AYTD_BG, String AYTD_PROCESSING_FEES, String AYTD_SYNDICATION, String AYTD_FOREX_AND_DERIVATIVES, String AYTD_EXCHANGE, String AYTD_COMMISSION, String AYTD_DERIVATIVES, String AYTD_GFID, String AYTD_DCM, String AYTD_IB_INCOME, String BAR_NII, String BAR_PROC_AND_SYNDICATION_FEES, String BAR_LC_AND_BG_FEES, String BAR_FOREX_AND_DERIVATIVES, String BAR_IB_AND_DCM_INCOME, String BAR_CA_CDAB, String BAR_SALARY_CDAB, String ADV_TOTAL, String ADV_A_MINUS_AND_ABOVE, String ADV_BBB_PLUS, String ADV_BBB_AND_BELOW, String ADV_NON_RATED, String CA_CDAB, String SALARY_CDAB, String NO_OF_NEW_SALARY_ACCTS, String NO_OF_MAPPED_CUSTOMERS, String CNT_OF_CUST_GRTR15_RAROC, String NetAdvances)
    {
        this.RM_ID = RM_ID;
        this.RM_NAME = RM_NAME;
        Segment = segment;
        this.PPC = PPC;
        B_NII = b_NII;
        B_PROCESSING_FEE = b_PROCESSING_FEE;
        B_SYNDICATION_FEE = b_SYNDICATION_FEE;
        B_LC = b_LC;
        B_BG = b_BG;
        B_FOREX_AND_DERIVATIVES = b_FOREX_AND_DERIVATIVES;
        B_EXCHANGE = b_EXCHANGE;
        B_COMMISSION = b_COMMISSION;
        B_DERIVATIVES = b_DERIVATIVES;
        B_GFID = b_GFID;
        B_IB_INCOME = b_IB_INCOME;
        B_DCM_INCOME = b_DCM_INCOME;
        B_CA_CDAB = b_CA_CDAB;
        B_SALARY_CDAB = b_SALARY_CDAB;
        B_NO_OF_SALARY_ACCOUNTS = b_NO_OF_SALARY_ACCOUNTS;
        this.AYTD_TOTAL_NII = AYTD_TOTAL_NII;
        this.AYTD_NII_TL = AYTD_NII_TL;
        this.AYTD_NII_WC = AYTD_NII_WC;
        this.AYTD_NII_OTHERS = AYTD_NII_OTHERS;
        this.AYTD_TOTAL_FEES = AYTD_TOTAL_FEES;
        this.AYTD_LC = AYTD_LC;
        this.AYTD_BG = AYTD_BG;
        this.AYTD_PROCESSING_FEES = AYTD_PROCESSING_FEES;
        this.AYTD_SYNDICATION = AYTD_SYNDICATION;
        this.AYTD_FOREX_AND_DERIVATIVES = AYTD_FOREX_AND_DERIVATIVES;
        this.AYTD_EXCHANGE = AYTD_EXCHANGE;
        this.AYTD_COMMISSION = AYTD_COMMISSION;
        this.AYTD_DERIVATIVES = AYTD_DERIVATIVES;
        this.AYTD_GFID = AYTD_GFID;
        this.AYTD_DCM = AYTD_DCM;
        this.AYTD_IB_INCOME = AYTD_IB_INCOME;
        this.BAR_NII = BAR_NII;
        this.BAR_PROC_AND_SYNDICATION_FEES = BAR_PROC_AND_SYNDICATION_FEES;
        this.BAR_LC_AND_BG_FEES = BAR_LC_AND_BG_FEES;
        this.BAR_FOREX_AND_DERIVATIVES = BAR_FOREX_AND_DERIVATIVES;
        this.BAR_IB_AND_DCM_INCOME = BAR_IB_AND_DCM_INCOME;
        this.BAR_CA_CDAB = BAR_CA_CDAB;
        this.BAR_SALARY_CDAB = BAR_SALARY_CDAB;
        this.ADV_TOTAL = ADV_TOTAL;
        this.ADV_A_MINUS_AND_ABOVE = ADV_A_MINUS_AND_ABOVE;
        this.ADV_BBB_PLUS = ADV_BBB_PLUS;
        this.ADV_BBB_AND_BELOW = ADV_BBB_AND_BELOW;
        this.ADV_NON_RATED = ADV_NON_RATED;
        this.CA_CDAB = CA_CDAB;
        this.SALARY_CDAB = SALARY_CDAB;
        this.NO_OF_NEW_SALARY_ACCTS = NO_OF_NEW_SALARY_ACCTS;
        this.NO_OF_MAPPED_CUSTOMERS = NO_OF_MAPPED_CUSTOMERS;
        this.CNT_OF_CUST_GRTR15_RAROC = CNT_OF_CUST_GRTR15_RAROC;
        this.NetAdvances = NetAdvances;
    }

    public VegiWrapper(String RM_ID, String RM_NAME, String segment, String PPC, String b_NII, String b_PROCESSING_FEE, String b_SYNDICATION_FEE, String b_LC, String b_BG, String b_FOREX_AND_DERIVATIVES, String b_EXCHANGE, String b_COMMISSION, String b_DERIVATIVES, String b_GFID, String b_IB_INCOME, String b_DCM_INCOME, String b_CA_CDAB, String b_SALARY_CDAB, String b_NO_OF_SALARY_ACCOUNTS, String AYTD_TOTAL_NII, String AYTD_NII_TL, String AYTD_NII_WC, String AYTD_NII_OTHERS, String AYTD_TOTAL_FEES, String AYTD_LC, String AYTD_BG, String AYTD_BILLS, String AYTD_PROCESSING_FEES, String AYTD_SYNDICATION, String AYTD_FOREX_AND_DERIVATIVES, String AYTD_EXCHANGE, String AYTD_COMMISSION, String AYTD_DERIVATIVES, String AYTD_GFID, String AYTD_DCM, String AYTD_IB_INCOME, String BAR_NII, String BAR_PROC_AND_SYNDICATION_FEES, String BAR_LC_AND_BG_FEES, String BAR_FOREX_AND_DERIVATIVES, String BAR_IB_AND_DCM_INCOME, String BAR_CA_CDAB, String BAR_SALARY_CDAB, String ADV_TOTAL, String ADV_A_MINUS_AND_ABOVE, String ADV_BBB_PLUS, String ADV_BBB_AND_BELOW, String ADV_NON_RATED, String CA_CDAB, String SALARY_CDAB, String NO_OF_NEW_SALARY_ACCTS, String NO_OF_MAPPED_CUSTOMERS, String CNT_OF_CUST_GRTR15_RAROC, String NetAdvances)
    {
        this.RM_ID = RM_ID;
        this.RM_NAME = RM_NAME;
        Segment = segment;
        this.PPC = PPC;
        B_NII = b_NII;
        B_PROCESSING_FEE = b_PROCESSING_FEE;
        B_SYNDICATION_FEE = b_SYNDICATION_FEE;
        B_LC = b_LC;
        B_BG = b_BG;
        B_FOREX_AND_DERIVATIVES = b_FOREX_AND_DERIVATIVES;
        B_EXCHANGE = b_EXCHANGE;
        B_COMMISSION = b_COMMISSION;
        B_DERIVATIVES = b_DERIVATIVES;
        B_GFID = b_GFID;
        B_IB_INCOME = b_IB_INCOME;
        B_DCM_INCOME = b_DCM_INCOME;
        B_CA_CDAB = b_CA_CDAB;
        B_SALARY_CDAB = b_SALARY_CDAB;
        B_NO_OF_SALARY_ACCOUNTS = b_NO_OF_SALARY_ACCOUNTS;
        this.AYTD_TOTAL_NII = AYTD_TOTAL_NII;
        this.AYTD_NII_TL = AYTD_NII_TL;
        this.AYTD_NII_WC = AYTD_NII_WC;
        this.AYTD_NII_OTHERS = AYTD_NII_OTHERS;
        this.AYTD_TOTAL_FEES = AYTD_TOTAL_FEES;
        this.AYTD_LC = AYTD_LC;
        this.AYTD_BG = AYTD_BG;
        this.AYTD_BILLS = AYTD_BILLS;
        this.AYTD_PROCESSING_FEES = AYTD_PROCESSING_FEES;
        this.AYTD_SYNDICATION = AYTD_SYNDICATION;
        this.AYTD_FOREX_AND_DERIVATIVES = AYTD_FOREX_AND_DERIVATIVES;
        this.AYTD_EXCHANGE = AYTD_EXCHANGE;
        this.AYTD_COMMISSION = AYTD_COMMISSION;
        this.AYTD_DERIVATIVES = AYTD_DERIVATIVES;
        this.AYTD_GFID = AYTD_GFID;
        this.AYTD_DCM = AYTD_DCM;
        this.AYTD_IB_INCOME = AYTD_IB_INCOME;
        this.BAR_NII = BAR_NII;
        this.BAR_PROC_AND_SYNDICATION_FEES = BAR_PROC_AND_SYNDICATION_FEES;
        this.BAR_LC_AND_BG_FEES = BAR_LC_AND_BG_FEES;
        this.BAR_FOREX_AND_DERIVATIVES = BAR_FOREX_AND_DERIVATIVES;
        this.BAR_IB_AND_DCM_INCOME = BAR_IB_AND_DCM_INCOME;
        this.BAR_CA_CDAB = BAR_CA_CDAB;
        this.BAR_SALARY_CDAB = BAR_SALARY_CDAB;
        this.ADV_TOTAL = ADV_TOTAL;
        this.ADV_A_MINUS_AND_ABOVE = ADV_A_MINUS_AND_ABOVE;
        this.ADV_BBB_PLUS = ADV_BBB_PLUS;
        this.ADV_BBB_AND_BELOW = ADV_BBB_AND_BELOW;
        this.ADV_NON_RATED = ADV_NON_RATED;
        this.CA_CDAB = CA_CDAB;
        this.SALARY_CDAB = SALARY_CDAB;
        this.NO_OF_NEW_SALARY_ACCTS = NO_OF_NEW_SALARY_ACCTS;
        this.NO_OF_MAPPED_CUSTOMERS = NO_OF_MAPPED_CUSTOMERS;
        this.CNT_OF_CUST_GRTR15_RAROC = CNT_OF_CUST_GRTR15_RAROC;
        this.NetAdvances = NetAdvances;
    }

    public String getRM_ID()
    {
        return RM_ID;
    }

    public void setRM_ID(String RM_ID)
    {
        this.RM_ID = RM_ID;
    }

    public String getRM_NAME()
    {
        return RM_NAME;
    }

    public void setRM_NAME(String RM_NAME)
    {
        this.RM_NAME = RM_NAME;
    }

    public String getSegment()
    {
        return Segment;
    }

    public void setSegment(String segment)
    {
        Segment = segment;
    }

    public String getPPC()
    {
        return PPC;
    }

    public void setPPC(String PPC)
    {
        this.PPC = PPC;
    }

    public String getB_NII()
    {
        return B_NII;
    }

    public void setB_NII(String b_NII)
    {
        B_NII = b_NII;
    }

    public String getB_PROCESSING_FEE()
    {
        return B_PROCESSING_FEE;
    }

    public void setB_PROCESSING_FEE(String b_PROCESSING_FEE)
    {
        B_PROCESSING_FEE = b_PROCESSING_FEE;
    }

    public String getB_SYNDICATION_FEE()
    {
        return B_SYNDICATION_FEE;
    }

    public void setB_SYNDICATION_FEE(String b_SYNDICATION_FEE)
    {
        B_SYNDICATION_FEE = b_SYNDICATION_FEE;
    }

    public String getB_LC()
    {
        return B_LC;
    }

    public void setB_LC(String b_LC)
    {
        B_LC = b_LC;
    }

    public String getB_BG()
    {
        return B_BG;
    }

    public void setB_BG(String b_BG)
    {
        B_BG = b_BG;
    }

    public String getB_FOREX_AND_DERIVATIVES()
    {
        return B_FOREX_AND_DERIVATIVES;
    }

    public void setB_FOREX_AND_DERIVATIVES(String b_FOREX_AND_DERIVATIVES)
    {
        B_FOREX_AND_DERIVATIVES = b_FOREX_AND_DERIVATIVES;
    }

    public String getB_EXCHANGE()
    {
        return B_EXCHANGE;
    }

    public void setB_EXCHANGE(String b_EXCHANGE)
    {
        B_EXCHANGE = b_EXCHANGE;
    }

    public String getB_COMMISSION()
    {
        return B_COMMISSION;
    }

    public void setB_COMMISSION(String b_COMMISSION)
    {
        B_COMMISSION = b_COMMISSION;
    }

    public String getB_DERIVATIVES()
    {
        return B_DERIVATIVES;
    }

    public void setB_DERIVATIVES(String b_DERIVATIVES)
    {
        B_DERIVATIVES = b_DERIVATIVES;
    }

    public String getB_GFID()
    {
        return B_GFID;
    }

    public void setB_GFID(String b_GFID)
    {
        B_GFID = b_GFID;
    }

    public String getB_IB_INCOME()
    {
        return B_IB_INCOME;
    }

    public void setB_IB_INCOME(String b_IB_INCOME)
    {
        B_IB_INCOME = b_IB_INCOME;
    }

    public String getB_DCM_INCOME()
    {
        return B_DCM_INCOME;
    }

    public void setB_DCM_INCOME(String b_DCM_INCOME)
    {
        B_DCM_INCOME = b_DCM_INCOME;
    }

    public String getB_CA_CDAB()
    {
        return B_CA_CDAB;
    }

    public void setB_CA_CDAB(String b_CA_CDAB)
    {
        B_CA_CDAB = b_CA_CDAB;
    }

    public String getB_SALARY_CDAB()
    {
        return B_SALARY_CDAB;
    }

    public void setB_SALARY_CDAB(String b_SALARY_CDAB)
    {
        B_SALARY_CDAB = b_SALARY_CDAB;
    }

    public String getB_NO_OF_SALARY_ACCOUNTS()
    {
        return B_NO_OF_SALARY_ACCOUNTS;
    }

    public void setB_NO_OF_SALARY_ACCOUNTS(String b_NO_OF_SALARY_ACCOUNTS)
    {
        B_NO_OF_SALARY_ACCOUNTS = b_NO_OF_SALARY_ACCOUNTS;
    }

    public String getAYTD_TOTAL_NII()
    {
        return AYTD_TOTAL_NII;
    }

    public void setAYTD_TOTAL_NII(String AYTD_TOTAL_NII)
    {
        this.AYTD_TOTAL_NII = AYTD_TOTAL_NII;
    }

    public String getAYTD_NII_TL()
    {
        return AYTD_NII_TL;
    }

    public void setAYTD_NII_TL(String AYTD_NII_TL)
    {
        this.AYTD_NII_TL = AYTD_NII_TL;
    }

    public String getAYTD_NII_WC()
    {
        return AYTD_NII_WC;
    }

    public void setAYTD_NII_WC(String AYTD_NII_WC)
    {
        this.AYTD_NII_WC = AYTD_NII_WC;
    }

    public String getAYTD_NII_OTHERS()
    {
        return AYTD_NII_OTHERS;
    }

    public void setAYTD_NII_OTHERS(String AYTD_NII_OTHERS)
    {
        this.AYTD_NII_OTHERS = AYTD_NII_OTHERS;
    }

    public String getAYTD_TOTAL_FEES()
    {
        return AYTD_TOTAL_FEES;
    }

    public void setAYTD_TOTAL_FEES(String AYTD_TOTAL_FEES)
    {
        this.AYTD_TOTAL_FEES = AYTD_TOTAL_FEES;
    }

    public String getAYTD_LC()
    {
        return AYTD_LC;
    }

    public void setAYTD_LC(String AYTD_LC)
    {
        this.AYTD_LC = AYTD_LC;
    }

    public String getAYTD_BG()
    {
        return AYTD_BG;
    }

    public void setAYTD_BG(String AYTD_BG)
    {
        this.AYTD_BG = AYTD_BG;
    }

    public String getAYTD_PROCESSING_FEES()
    {
        return AYTD_PROCESSING_FEES;
    }

    public void setAYTD_PROCESSING_FEES(String AYTD_PROCESSING_FEES)
    {
        this.AYTD_PROCESSING_FEES = AYTD_PROCESSING_FEES;
    }

    public String getAYTD_SYNDICATION()
    {
        return AYTD_SYNDICATION;
    }

    public void setAYTD_SYNDICATION(String AYTD_SYNDICATION)
    {
        this.AYTD_SYNDICATION = AYTD_SYNDICATION;
    }

    public String getAYTD_FOREX_AND_DERIVATIVES()
    {
        return AYTD_FOREX_AND_DERIVATIVES;
    }

    public void setAYTD_FOREX_AND_DERIVATIVES(String AYTD_FOREX_AND_DERIVATIVES)
    {
        this.AYTD_FOREX_AND_DERIVATIVES = AYTD_FOREX_AND_DERIVATIVES;
    }

    public String getAYTD_EXCHANGE()
    {
        return AYTD_EXCHANGE;
    }

    public void setAYTD_EXCHANGE(String AYTD_EXCHANGE)
    {
        this.AYTD_EXCHANGE = AYTD_EXCHANGE;
    }

    public String getAYTD_COMMISSION()
    {
        return AYTD_COMMISSION;
    }

    public void setAYTD_COMMISSION(String AYTD_COMMISSION)
    {
        this.AYTD_COMMISSION = AYTD_COMMISSION;
    }

    public String getAYTD_DERIVATIVES()
    {
        return AYTD_DERIVATIVES;
    }

    public void setAYTD_DERIVATIVES(String AYTD_DERIVATIVES)
    {
        this.AYTD_DERIVATIVES = AYTD_DERIVATIVES;
    }

    public String getAYTD_GFID()
    {
        return AYTD_GFID;
    }

    public void setAYTD_GFID(String AYTD_GFID)
    {
        this.AYTD_GFID = AYTD_GFID;
    }

    public String getAYTD_DCM()
    {
        return AYTD_DCM;
    }

    public void setAYTD_DCM(String AYTD_DCM)
    {
        this.AYTD_DCM = AYTD_DCM;
    }

    public String getAYTD_IB_INCOME()
    {
        return AYTD_IB_INCOME;
    }

    public void setAYTD_IB_INCOME(String AYTD_IB_INCOME)
    {
        this.AYTD_IB_INCOME = AYTD_IB_INCOME;
    }

    public String getBAR_NII()
    {
        return BAR_NII;
    }

    public void setBAR_NII(String BAR_NII)
    {
        this.BAR_NII = BAR_NII;
    }

    public String getBAR_PROC_AND_SYNDICATION_FEES()
    {
        return BAR_PROC_AND_SYNDICATION_FEES;
    }

    public void setBAR_PROC_AND_SYNDICATION_FEES(String BAR_PROC_AND_SYNDICATION_FEES)
    {
        this.BAR_PROC_AND_SYNDICATION_FEES = BAR_PROC_AND_SYNDICATION_FEES;
    }

    public String getBAR_LC_AND_BG_FEES()
    {
        return BAR_LC_AND_BG_FEES;
    }

    public void setBAR_LC_AND_BG_FEES(String BAR_LC_AND_BG_FEES)
    {
        this.BAR_LC_AND_BG_FEES = BAR_LC_AND_BG_FEES;
    }

    public String getBAR_FOREX_AND_DERIVATIVES()
    {
        return BAR_FOREX_AND_DERIVATIVES;
    }

    public void setBAR_FOREX_AND_DERIVATIVES(String BAR_FOREX_AND_DERIVATIVES)
    {
        this.BAR_FOREX_AND_DERIVATIVES = BAR_FOREX_AND_DERIVATIVES;
    }

    public String getBAR_IB_AND_DCM_INCOME()
    {
        return BAR_IB_AND_DCM_INCOME;
    }

    public void setBAR_IB_AND_DCM_INCOME(String BAR_IB_AND_DCM_INCOME)
    {
        this.BAR_IB_AND_DCM_INCOME = BAR_IB_AND_DCM_INCOME;
    }

    public String getBAR_CA_CDAB()
    {
        return BAR_CA_CDAB;
    }

    public void setBAR_CA_CDAB(String BAR_CA_CDAB)
    {
        this.BAR_CA_CDAB = BAR_CA_CDAB;
    }

    public String getBAR_SALARY_CDAB()
    {
        return BAR_SALARY_CDAB;
    }

    public void setBAR_SALARY_CDAB(String BAR_SALARY_CDAB)
    {
        this.BAR_SALARY_CDAB = BAR_SALARY_CDAB;
    }

    public String getADV_TOTAL()
    {
        return ADV_TOTAL;
    }

    public void setADV_TOTAL(String ADV_TOTAL)
    {
        this.ADV_TOTAL = ADV_TOTAL;
    }

    public String getADV_A_MINUS_AND_ABOVE()
    {
        return ADV_A_MINUS_AND_ABOVE;
    }

    public void setADV_A_MINUS_AND_ABOVE(String ADV_A_MINUS_AND_ABOVE)
    {
        this.ADV_A_MINUS_AND_ABOVE = ADV_A_MINUS_AND_ABOVE;
    }

    public String getADV_BBB_PLUS()
    {
        return ADV_BBB_PLUS;
    }

    public void setADV_BBB_PLUS(String ADV_BBB_PLUS)
    {
        this.ADV_BBB_PLUS = ADV_BBB_PLUS;
    }

    public String getADV_BBB_AND_BELOW()
    {
        return ADV_BBB_AND_BELOW;
    }

    public void setADV_BBB_AND_BELOW(String ADV_BBB_AND_BELOW)
    {
        this.ADV_BBB_AND_BELOW = ADV_BBB_AND_BELOW;
    }

    public String getADV_NON_RATED()
    {
        return ADV_NON_RATED;
    }

    public void setADV_NON_RATED(String ADV_NON_RATED)
    {
        this.ADV_NON_RATED = ADV_NON_RATED;
    }

    public String getCA_CDAB()
    {
        return CA_CDAB;
    }

    public void setCA_CDAB(String CA_CDAB)
    {
        this.CA_CDAB = CA_CDAB;
    }

    public String getSALARY_CDAB()
    {
        return SALARY_CDAB;
    }

    public void setSALARY_CDAB(String SALARY_CDAB)
    {
        this.SALARY_CDAB = SALARY_CDAB;
    }

    public String getNO_OF_NEW_SALARY_ACCTS()
    {
        return NO_OF_NEW_SALARY_ACCTS;
    }

    public void setNO_OF_NEW_SALARY_ACCTS(String NO_OF_NEW_SALARY_ACCTS)
    {
        this.NO_OF_NEW_SALARY_ACCTS = NO_OF_NEW_SALARY_ACCTS;
    }

    public String getNO_OF_MAPPED_CUSTOMERS()
    {
        return NO_OF_MAPPED_CUSTOMERS;
    }

    public void setNO_OF_MAPPED_CUSTOMERS(String NO_OF_MAPPED_CUSTOMERS)
    {
        this.NO_OF_MAPPED_CUSTOMERS = NO_OF_MAPPED_CUSTOMERS;
    }

    public String getCNT_OF_CUST_GRTR15_RAROC()
    {
        return CNT_OF_CUST_GRTR15_RAROC;
    }

    public void setCNT_OF_CUST_GRTR15_RAROC(String CNT_OF_CUST_GRTR15_RAROC)
    {
        this.CNT_OF_CUST_GRTR15_RAROC = CNT_OF_CUST_GRTR15_RAROC;
    }

    public String getNetAdvances() {
        return NetAdvances;
    }

    public void setNetAdvances(String netAdvances) {
        NetAdvances = netAdvances;
    }


    public String getAYTD_BILLS() {
        return AYTD_BILLS;
    }

    public void setAYTD_BILLS(String AYTD_BILLS) {
        this.AYTD_BILLS = AYTD_BILLS;
    }

}
