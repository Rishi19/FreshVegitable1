package com.freshvegitable.Wrappers;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Rishi Sahu on 9/3/2017.
 */

public class price_wrapper implements Parcelable {

    String name;
    String value;
    String listprice;
    String delivery_charge;
    String tax;
    String promotion_applied;
    String total_amount;


    public  price_wrapper()
    {}


    public String getListprice() {
        return listprice;
    }

    public void setListprice(String listprice) {
        this.listprice = listprice;
    }



    public price_wrapper(String name, String value) {

        this.name = name;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.name);
        dest.writeString(this.value);
        dest.writeString(this.listprice);
        dest.writeString(this.delivery_charge);
        dest.writeString(this.tax);
        dest.writeString(this.promotion_applied);
        dest.writeString(this.total_amount);
    }

    protected price_wrapper(Parcel in) {
        this.name = in.readString();
        this.value = in.readString();
        this.listprice = in.readString();
        this.delivery_charge = in.readString();
        this.tax = in.readString();
        this.promotion_applied = in.readString();
        this.total_amount = in.readString();
    }

    public static final Creator<price_wrapper> CREATOR = new Creator<price_wrapper>() {
        @Override
        public price_wrapper createFromParcel(Parcel source) {
            return new price_wrapper(source);
        }

        @Override
        public price_wrapper[] newArray(int size) {
            return new price_wrapper[size];
        }
    };
}
