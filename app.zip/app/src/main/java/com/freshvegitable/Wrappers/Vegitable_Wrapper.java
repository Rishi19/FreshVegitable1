package com.freshvegitable.Wrappers;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class Vegitable_Wrapper implements Parcelable {


    public  String group_id;
    public  String item_id;
    public  String group_name;
    public  String item_name;
    public  String icon;
    public  String description;
    public  String quentity_type;
    public  String price;
    public  String maximum_order;

    public Vegitable_Wrapper()
    {}

    public Vegitable_Wrapper(String group_id, String item_id, String group_name, String item_name, String icon, String description, String quentity_type, String price, String maximum_order) {

        this.group_id = group_id;
        this.item_id = item_id;
        this.group_name = group_name;
        this.item_name = item_name;
        this.icon = icon;
        this.description = description;
        this.quentity_type = quentity_type;
        this.price = price;
        this.maximum_order = maximum_order;
    }




    public String getGroup_id() {
        return group_id;
    }

    public void setGroup_id(String group_id) {
        this.group_id = group_id;
    }

    public String getItem_id() {
        return item_id;
    }

    public void setItem_id(String item_id) {
        this.item_id = item_id;
    }

    public String getGroup_name() {
        return group_name;
    }

    public void setGroup_name(String group_name) {
        this.group_name = group_name;
    }

    public String getItem_name() {
        return item_name;
    }

    public void setItem_name(String item_name) {
        this.item_name = item_name;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getQuentity_type() {
        return quentity_type;
    }

    public void setQuentity_type(String quentity_type) {
        this.quentity_type = quentity_type;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getMaximum_order() {
        return maximum_order;
    }

    public void setMaximum_order(String maximum_order) {
        this.maximum_order = maximum_order;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.group_id);
        dest.writeString(this.item_id);
        dest.writeString(this.group_name);
        dest.writeString(this.item_name);
        dest.writeString(this.icon);
        dest.writeString(this.description);
        dest.writeString(this.quentity_type);
        dest.writeString(this.price);
        dest.writeString(this.maximum_order);
    }

    protected Vegitable_Wrapper(Parcel in) {
        this.group_id = in.readString();
        this.item_id = in.readString();
        this.group_name = in.readString();
        this.item_name = in.readString();
        this.icon = in.readString();
        this.description = in.readString();
        this.quentity_type = in.readString();
        this.price = in.readString();
        this.maximum_order = in.readString();
    }

    public static final Creator<Vegitable_Wrapper> CREATOR = new Creator<Vegitable_Wrapper>() {
        @Override
        public Vegitable_Wrapper createFromParcel(Parcel source) {
            return new Vegitable_Wrapper(source);
        }

        @Override
        public Vegitable_Wrapper[] newArray(int size) {
            return new Vegitable_Wrapper[size];
        }
    };
}
