package com.freshvegitable.Wrappers;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;

/**
 * Created by tp00021235 on 01-09-2017.
 */

public class AddressWrapper implements Parcelable {

    public int id;
    public String name;
    public String mobile_no;
    public String pincode;
    public String address1;
    public String address2;
    public String address3;
    public String city;
    public String state;
    public String country;


    public  AddressWrapper()
    {}


    public AddressWrapper(int id, String name, String mobile_no, String pincode, String address1, String address2, String address3, String city, String state, String country) {
        this.id = id;
        this.name = name;
        this.mobile_no = mobile_no;
        this.pincode = pincode;
        this.address1 = address1;
        this.address2 = address2;
        this.address3 = address3;
        this.city = city;
        this.state = state;
        this.country = country;
    }




    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMobile_no() {
        return mobile_no;
    }

    public void setMobile_no(String mobile_no) {
        this.mobile_no = mobile_no;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }

    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public String getAddress3() {
        return address3;
    }

    public void setAddress3(String address3) {
        this.address3 = address3;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.id);
        dest.writeString(this.name);
        dest.writeString(this.mobile_no);
        dest.writeString(this.pincode);
        dest.writeString(this.address1);
        dest.writeString(this.address2);
        dest.writeString(this.address3);
        dest.writeString(this.city);
        dest.writeString(this.state);
        dest.writeString(this.country);
    }

    protected AddressWrapper(Parcel in) {
        this.id = in.readInt();
        this.name = in.readString();
        this.mobile_no = in.readString();
        this.pincode = in.readString();
        this.address1 = in.readString();
        this.address2 = in.readString();
        this.address3 = in.readString();
        this.city = in.readString();
        this.state = in.readString();
        this.country = in.readString();
    }

    public static final Creator<AddressWrapper> CREATOR = new Creator<AddressWrapper>() {
        @Override
        public AddressWrapper createFromParcel(Parcel source) {
            return new AddressWrapper(source);
        }

        @Override
        public AddressWrapper[] newArray(int size) {
            return new AddressWrapper[size];
        }
    };
}
