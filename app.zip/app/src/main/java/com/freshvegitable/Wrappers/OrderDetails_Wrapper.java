package com.freshvegitable.Wrappers;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Rishi Sahu on 9/3/2017.
 */

public class OrderDetails_Wrapper implements Parcelable {

    public  String group_id;
    public  String item_id;
    public  String group_name;
    public  String quantity_type;
    public  String maximum_order;


    private String description = "";
    private String longDescription = "";
    private String mrp;
    private String discount;
    private String salePrice;
    private String orderQty;
    private String imageUrl = "";
    private String productName = "";
    private String productId = "";
    private String deliveryStatus = "";
    private String orderedDate = "";
    private String deliveredDate = "";
    private AddressWrapper addressdetail ;
    private price_wrapper price_wrapper;


    public com.freshvegitable.Wrappers.price_wrapper getPrice_wrapper() {
        return price_wrapper;
    }

    public void setPrice_wrapper(com.freshvegitable.Wrappers.price_wrapper price_wrapper) {
        this.price_wrapper = price_wrapper;
    }


    public OrderDetails_Wrapper()
    {}


    public String getGroup_id() {
        return group_id;
    }

    public void setGroup_id(String group_id) {
        this.group_id = group_id;
    }

    public String getItem_id() {
        return item_id;
    }

    public void setItem_id(String item_id) {
        this.item_id = item_id;
    }

    public String getGroup_name() {
        return group_name;
    }

    public void setGroup_name(String group_name) {
        this.group_name = group_name;
    }

    public String getQuantity_type() {
        return quantity_type;
    }

    public void setQuantity_type(String quantity_type) {
        this.quantity_type = quantity_type;
    }

    public String getMaximum_order() {
        return maximum_order;
    }

    public void setMaximum_order(String maximum_order) {
        this.maximum_order = maximum_order;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLongDescription() {
        return longDescription;
    }

    public void setLongDescription(String longDescription) {
        this.longDescription = longDescription;
    }

    public String getMrp() {
        return mrp;
    }

    public void setMrp(String mrp) {
        this.mrp = mrp;
    }

    public String getDiscount() {
        return discount;
    }

    public void setDiscount(String discount) {
        this.discount = discount;
    }

    public String getSalePrice() {
        return salePrice;
    }

    public void setSalePrice(String salePrice) {
        this.salePrice = salePrice;
    }

    public String getOrderQty() {
        return orderQty;
    }

    public void setOrderQty(String orderQty) {
        this.orderQty = orderQty;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getDeliveryStatus() {
        return deliveryStatus;
    }

    public void setDeliveryStatus(String deliveryStatus) {
        this.deliveryStatus = deliveryStatus;
    }

    public String getOrderedDate() {
        return orderedDate;
    }

    public void setOrderedDate(String orderedDate) {
        this.orderedDate = orderedDate;
    }

    public String getDeliveredDate() {
        return deliveredDate;
    }

    public void setDeliveredDate(String deliveredDate) {
        this.deliveredDate = deliveredDate;
    }

    public AddressWrapper getAddressdetail() {
        return addressdetail;
    }

    public void setAddressdetail(AddressWrapper addressdetail) {
        this.addressdetail = addressdetail;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.group_id);
        dest.writeString(this.item_id);
        dest.writeString(this.group_name);
        dest.writeString(this.quantity_type);
        dest.writeString(this.maximum_order);
        dest.writeString(this.description);
        dest.writeString(this.longDescription);
        dest.writeString(this.mrp);
        dest.writeString(this.discount);
        dest.writeString(this.salePrice);
        dest.writeString(this.orderQty);
        dest.writeString(this.imageUrl);
        dest.writeString(this.productName);
        dest.writeString(this.productId);
        dest.writeString(this.deliveryStatus);
        dest.writeString(this.orderedDate);
        dest.writeString(this.deliveredDate);
        dest.writeParcelable(this.addressdetail, flags);
        dest.writeParcelable(this.price_wrapper, flags);
    }

    protected OrderDetails_Wrapper(Parcel in) {
        this.group_id = in.readString();
        this.item_id = in.readString();
        this.group_name = in.readString();
        this.quantity_type = in.readString();
        this.maximum_order = in.readString();
        this.description = in.readString();
        this.longDescription = in.readString();
        this.mrp = in.readString();
        this.discount = in.readString();
        this.salePrice = in.readString();
        this.orderQty = in.readString();
        this.imageUrl = in.readString();
        this.productName = in.readString();
        this.productId = in.readString();
        this.deliveryStatus = in.readString();
        this.orderedDate = in.readString();
        this.deliveredDate = in.readString();
        this.addressdetail = in.readParcelable(AddressWrapper.class.getClassLoader());
        this.price_wrapper = in.readParcelable(price_wrapper.class.getClassLoader());
    }

    public static final Creator<OrderDetails_Wrapper> CREATOR = new Creator<OrderDetails_Wrapper>() {
        @Override
        public OrderDetails_Wrapper createFromParcel(Parcel source) {
            return new OrderDetails_Wrapper(source);
        }

        @Override
        public OrderDetails_Wrapper[] newArray(int size) {
            return new OrderDetails_Wrapper[size];
        }
    };
}
