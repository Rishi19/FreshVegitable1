package com.freshvegitable.Wrappers;

import java.util.ArrayList;
import java.util.Vector;

/**
 * Created by jude on 19-11-2015.
 */
public class DataHolder
{
    public Vector vector;
    public ArrayList<String> dates;

    public DataHolder(){}

    public DataHolder(Vector vector, ArrayList<String> dates)
    {
        this.vector = vector;
        this.dates = dates;
    }

    public Vector getVector()
    {
        return vector;
    }

    public void setVector(Vector vector)
    {
        this.vector = vector;
    }

    public ArrayList<String> getDates()
    {
        return dates;
    }

    public void setDates(ArrayList<String> dates)
    {
        this.dates = dates;
    }
}