package com.freshvegitable.utils;


public class AppConstants {

    public static int CURRENT_CATEGORY = 0;

    public static final String FIRST_TIME = "FirstTime";

    public static final String WHATS_NEW_LAST_SHOWN = "whats_new_last_shown";

    // Audio prefernces
    public static final String VIEW_PAGER_ANIME = "PagerAnime";

    // Help Preference
    public static final String SUBMIT_LOGS = "CrashLogs";


}
