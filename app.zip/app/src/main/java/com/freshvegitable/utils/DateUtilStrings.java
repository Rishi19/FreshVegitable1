package com.freshvegitable.utils;

/**
 * Created by Rishi on 13-09-2016.
 */
public class DateUtilStrings {

    //============================= - Dash seprator ==========================================================

    /*-*/String dd_MM_yyyy = "(^(((0[1-9]|1[0-9]|2[0-8])[\\/](0[1-9]|1[012]))|((29|30|31)[\\/](0[13578]|1[02]))|((29|30)[\\/](0[4,6,9]|11)))[\\/](19|[2-9][0-9])\\d\\d$)|(^29[\\/]02[\\/](19|[2-9][0-9])(00|04|08|12|16|20|24|28|32|36|40|44|48|52|56|60|64|68|72|76|80|84|88|92|96)$)";
    /*-*/String dd_MM_yyyy_HH = new String("dd-MM-yyyy HH");
    /*-*/String dd_MM_yyyy_HH_mm = new String("dd-MM-yyyy HH:mm");
    /*-*/String dd_MM_yyyy_HH_mm_ss = new String("dd-MM-yyyy HH:mm:ss");
    /*-*/String dd_MM_yyyy_HH_mm_ss_a = new String("dd-MM-yyyy HH:mm:ss a");
    /*-*/String dd_MM_yyyy_HH_mm_ss_SS = new String("dd-MM-yyyy HH:mm:ss.SS");
    /*-*/String dd_MM_yyyy_HH_mm_ss_SSS = new String("dd-MM-yyyy HH:mm:ss.SSS");
    /*-*/String dd_MM_yyyy_HH_mm_ss_SSSZ = new String("dd-MM-yyyy HH:mm:ss.SSSZ");
    /*-*/String dd_MM_yyyy_T_HH_mm_ss_SS = new String("dd-MM-yyyy'T'HH:mm:ss.SS");
    /*-*/String dd_MM_yyyy_T_HH_mm_ss_SSS = new String("dd-MM-yyyy'T'HH:mm:ss.SSS");
    /*-*/String dd_MM_yyyy_T_HH_mm_ss_SSSZ = new String("dd-MM-yyyy'T'HH:mm:ss.SSSZ");
    /*-*/String dd_MM_yyyy_T_HH_mm_ss_SSSXXX = new String("dd-MM-yyyy'T'HH:mm:ss.SSSXXX");

    /*-*/String MM_dd_yyyy = new String("MM-dd-yyyy");
    /*-*/String MM_dd_yyyy_HH = new String("MM-dd-yyyy HH");
    /*-*/String MM_dd_yyyy_HH_mm = new String("MM-dd-yyyy HH:mm");
    /*-*/String MM_dd_yyyy_HH_mm_ss = new String("MM-dd-yyyy HH:mm:ss");
    /*-*/String MM_dd_yyyy_HH_mm_ss_a = new String("MM-dd-yyyy HH:mm:ss a");
    /*-*/String MM_dd_yyyy_HH_mm_ss_SS = new String("MM-dd-yyyy HH:mm:ss.SS");
    /*-*/String MM_dd_yyyy_HH_mm_ss_SSS = new String("MM-dd-yyyy HH:mm:ss.SSS");
    /*-*/String MM_dd_yyyy_HH_mm_ss_SSSZ = new String("MM-dd-yyyyy HH:mm:ss.SSSZ");
    /*-*/String MM_dd_yyyy_T_HH_mm_ss_SS = new String("MM-dd-yyyy'T'HH:mm:ss.SS");
    /*-*/String MM_dd_yyyy_T_HH_mm_ss_SSS = new String("MM-dd-yyyy'T'HH:mm:ss.SSS");
    /*-*/String MM_dd_yyyy_T_HH_mm_ss_SSSZ = new String("MM-dd-yyyy'T'HH:mm:ss.SSSZ");
    /*-*/String MM_dd_yyyy_T_HH_mm_ss_SSSXXX = new String("MM-dd-yyyy'T'HH:mm:ss.SSSXXX");

    /*-*/String yyyy_MM_dd = new String("yyyy-MM-dd");
    /*-*/String yyyy_MM_dd_HH = new String("yyyy-MM-dd HH");
    /*-*/String yyyy_MM_dd_HH_mm = new String("yyyy-MM-dd HH:mm");
    /*-*/String yyyy_MM_dd_HH_mm_ss = new String("yyyy-MM-dd HH:mm:ss");
    /*-*/String yyyy_MM_dd_HH_mm_ss_a = new String("yyyy-MM-dd HH:mm:ss a");
    /*-*/String yyyy_MM_dd_HH_mm_ss_SS = new String("yyyy-MM-dd HH:mm:ss.SS");
    /*-*/String yyyy_MM_dd_HH_mm_ss_SSS = new String("yyyy-MM-dd HH:mm:ss.SSS");
    /*-*/String yyyy_MM_dd_HH_mm_ss_SSSZ = new String("yyyy-MM-ddy HH:mm:ss.SSSZ");
    /*-*/String yyyy_MM_dd_T_HH_mm_ss_SS = new String("yyyy-MM-dd'T'HH:mm:ss.SS");
    /*-*/String yyyy_MM_dd_T_HH_mm_ss_SSS = new String("yyyy-MM-dd'T'HH:mm:ss.SSS");
    /*-*/String yyyy_MM_dd_T_HH_mm_ss_SSSZ = new String("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
    /*-*/String yyyy_MM_dd_T_HH_mm_ss_SSSXXX = new String("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");

    /*-*/String yyyy_dd_MM = new String("yyyy-dd-MM");
    /*-*/String yyyy_dd_MM_HH = new String("yyyy-dd-MM HH");
    /*-*/String yyyy_dd_MM_HH_mm = new String("yyyy-dd-MM HH:mm");
    /*-*/String yyyy_dd_MM_HH_mm_ss = new String("yyyy-dd-MM HH:mm:ss");
    /*-*/String yyyy_dd_MM_HH_mm_ss_a = new String("yyyy-dd-MM HH:mm:ss a");
    /*-*/String yyyy_dd_MM_HH_mm_ss_SS = new String("yyyy-dd-MM HH:mm:ss.SS");
    /*-*/String yyyy_dd_MM_HH_mm_ss_SSS = new String("yyyy-dd-MM HH:mm:ss.SSS");
    /*-*/String yyyy_dd_MM_HH_mm_ss_SSSZ = new String("yyyy-dd-MMy HH:mm:ss.SSSZ");
    /*-*/String yyyy_dd_MM_T_HH_mm_ss_SS = new String("yyyy-dd-MM'T'HH:mm:ss.SS");
    /*-*/String yyyy_dd_MM_T_HH_mm_ss_SSS = new String("yyyy-dd-MM'T'HH:mm:ss.SSS");
    /*-*/String yyyy_dd_MM_T_HH_mm_ss_SSSZ = new String("yyyy-dd-MM'T'HH:mm:ss.SSSZ");
    /*-*/String yyyy_dd_MM_T_HH_mm_ss_SSSXXX = new String("yyyy-dd-MM'T'HH:mm:ss.SSSXXX");


    //============================= - DASH 1 seprator ==========================================================

    /*-*/String dd_MM_yy = new String("dd-MM-yy");
    /*-*/String dd_MM_yy_HH = new String("dd-MM-yy HH");
    /*-*/String dd_MM_yy_HH_mm = new String("dd-MM-yy HH:mm");
    /*-*/String dd_MM_yy_HH_mm_ss = new String("dd-MM-yy HH:mm:ss");
    /*-*/String dd_MM_yy_HH_mm_ss_a = new String("dd-MM-yy HH:mm:ss a");
    /*-*/String dd_MM_yy_HH_mm_ss_SS = new String("dd-MM-yy HH:mm:ss.SS");
    /*-*/String dd_MM_yy_HH_mm_ss_SSS = new String("dd-MM-yy HH:mm:ss.SSS");
    /*-*/String dd_MM_yy_HH_mm_ss_SSSZ = new String("dd-MM-yy HH:mm:ss.SSSZ");
    /*-*/String dd_MM_yy_T_HH_mm_ss_SS = new String("dd-MM-yy'T'HH:mm:ss.SS");
    /*-*/String dd_MM_yy_T_HH_mm_ss_SSS = new String("dd-MM-yy'T'HH:mm:ss.SSS");
    /*-*/String dd_MM_yy_T_HH_mm_ss_SSSZ = new String("dd-MM-yy'T'HH:mm:ss.SSSZ");
    /*-*/String dd_MM_yy_T_HH_mm_ss_SSSXXX = new String("dd-MM-yy'T'HH:mm:ss.SSSXXX");

    /*-*/String MM_dd_yy = new String("MM-dd-yy");
    /*-*/String MM_dd_yy_HH = new String("MM-dd-yy HH");
    /*-*/String MM_dd_yy_HH_mm = new String("MM-dd-yy HH:mm");
    /*-*/String MM_dd_yy_HH_mm_ss = new String("MM-dd-yy HH:mm:ss");
    /*-*/String MM_dd_yy_HH_mm_ss_a = new String("MM-dd-yy HH:mm:ss a");
    /*-*/String MM_dd_yy_HH_mm_ss_SS = new String("MM-dd-yy HH:mm:ss.SS");
    /*-*/String MM_dd_yy_HH_mm_ss_SSS = new String("MM-dd-yy HH:mm:ss.SSS");
    /*-*/String MM_dd_yy_HH_mm_ss_SSSZ = new String("MM-dd-yyy HH:mm:ss.SSSZ");
    /*-*/String MM_dd_yy_T_HH_mm_ss_SS = new String("MM-dd-yy'T'HH:mm:ss.SS");
    /*-*/String MM_dd_yy_T_HH_mm_ss_SSS = new String("MM-dd-yy'T'HH:mm:ss.SSS");
    /*-*/String MM_dd_yy_T_HH_mm_ss_SSSZ = new String("MM-dd-yy'T'HH:mm:ss.SSSZ");
    /*-*/String MM_dd_yy_T_HH_mm_ss_SSSXXX = new String("MM-dd-yy'T'HH:mm:ss.SSSXXX");

    /*-*/String yy_MM_dd = new String("yy-MM-dd");
    /*-*/String yy_MM_dd_HH = new String("yy-MM-dd HH");
    /*-*/String yy_MM_dd_HH_mm = new String("yy-MM-dd HH:mm");
    /*-*/String yy_MM_dd_HH_mm_ss = new String("yy-MM-dd HH:mm:ss");
    /*-*/String yy_MM_dd_HH_mm_ss_a = new String("yy-MM-dd HH:mm:ss a");
    /*-*/String yy_MM_dd_HH_mm_ss_SS = new String("yy-MM-dd HH:mm:ss.SS");
    /*-*/String yy_MM_dd_HH_mm_ss_SSS = new String("yy-MM-dd HH:mm:ss.SSS");
    /*-*/String yy_MM_dd_HH_mm_ss_SSSZ = new String("yy-MM-ddy HH:mm:ss.SSSZ");
    /*-*/String yy_MM_dd_T_HH_mm_ss_SS = new String("yy-MM-dd'T'HH:mm:ss.SS");
    /*-*/String yy_MM_dd_T_HH_mm_ss_SSS = new String("yy-MM-dd'T'HH:mm:ss.SSS");
    /*-*/String yy_MM_dd_T_HH_mm_ss_SSSZ = new String("yy-MM-dd'T'HH:mm:ss.SSSZ");
    /*-*/String yy_MM_dd_T_HH_mm_ss_SSSXXX = new String("yy-MM-dd'T'HH:mm:ss.SSSXXX");

    /*-*/String yy_dd_MM = new String("yy-dd-MM");
    /*-*/String yy_dd_MM_HH = new String("yy-dd-MM HH");
    /*-*/String yy_dd_MM_HH_mm = new String("yy-dd-MM HH:mm");
    /*-*/String yy_dd_MM_HH_mm_ss = new String("yy-dd-MM HH:mm:ss");
    /*-*/String yy_dd_MM_HH_mm_ss_a = new String("yy-dd-MM HH:mm:ss a");
    /*-*/String yy_dd_MM_HH_mm_ss_SS = new String("yy-dd-MM HH:mm:ss.SS");
    /*-*/String yy_dd_MM_HH_mm_ss_SSS = new String("yy-dd-MM HH:mm:ss.SSS");
    /*-*/String yy_dd_MM_HH_mm_ss_SSSZ = new String("yy-dd-MMy HH:mm:ss.SSSZ");
    /*-*/String yy_dd_MM_T_HH_mm_ss_SS = new String("yy-dd-MM'T'HH:mm:ss.SS");
    /*-*/String yy_dd_MM_T_HH_mm_ss_SSS = new String("yy-dd-MM'T'HH:mm:ss.SSS");
    /*-*/String yy_dd_MM_T_HH_mm_ss_SSSZ = new String("yy-dd-MM'T'HH:mm:ss.SSSZ");
    /*-*/String yy_dd_MM_T_HH_mm_ss_SSSXXX = new String("yy-dd-MM'T'HH:mm:ss.SSSXXX");


    //============================= / slash seprator ==========================================================

    /* / dd/MM/yyyy */String Slash_dd_MM_yyyy = "^(((0[1-9]|[12]\\d|3[01])\\/(0[13578]|1[02])\\/((19|[2-9]\\d)\\d{2}))|((0[1-9]|[12]\\d|30)\\/(0[13456789]|1[012])\\/((19|[2-9]\\d)\\d{2}))|((0[1-9]|1\\d|2[0-8])\\/02\\/((19|[2-9]\\d)\\d{2}))|(29\\/02\\/((1[6-9]|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|((16|[2468][048]|[3579][26])00))))$";
    /* / dd/MM/yyyy HH */String Slash_dd_MM_yyyy_HH = "^(((0[1-9]|[12]\\d|3[01])\\/(0[13578]|1[02])\\/((19|[2-9]\\d)\\d{2})\\s(([01]\\d|2[0-3])))|((0[1-9]|[12]\\d|30)\\/(0[13456789]|1[012])\\/((19|[2-9]\\d)\\d{2})\\s(([01]\\d|2[0-3])))|((0[1-9]|1\\d|2[0-8])\\/02\\/((19|[2-9]\\d)\\d{2})\\s(([01]\\d|2[0-3])))|((29\\/02\\/((1[6-9]|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|((16|[2468][048]|[3579][26])00)))\\s(([01]\\d|2[0-3]))))$";
    /* / dd/MM/yyyy HH:mm */String Slash_dd_MM_yyyy_HH_mm = "^(((0[1-9]|[12]\\d|3[01])\\/(0[13578]|1[02])\\/((19|[2-9]\\d)\\d{2})\\s(([01]\\d|2[0-3]):([0-5]\\d)))|((0[1-9]|[12]\\d|30)\\/(0[13456789]|1[012])\\/((19|[2-9]\\d)\\d{2})\\s(([01]\\d|2[0-3]):([0-5]\\d)))|((0[1-9]|1\\d|2[0-8])\\/02\\/((19|[2-9]\\d)\\d{2})\\s(([01]\\d|2[0-3]):([0-5]\\d)))|((29\\/02\\/((1[6-9]|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|((16|[2468][048]|[3579][26])00)))\\s(([01]\\d|2[0-3]):([0-5]\\d))))$";
    /* / dd/MM/yyyy HH:mm:ss */String Slash_dd_MM_yyyy_HH_mm_ss = "^(((0[1-9]|[12]\\d|3[01])\\/(0[13578]|1[02])\\/((19|[2-9]\\d)\\d{2})\\s(([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d)))|((0[1-9]|[12]\\d|30)\\/(0[13456789]|1[012])\\/((19|[2-9]\\d)\\d{2})\\s(([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d)))|((0[1-9]|1\\d|2[0-8])\\/02\\/((19|[2-9]\\d)\\d{2})\\s(([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d)))|(29\\/02\\/((1[6-9]|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|((16|[2468][048]|[3579][26])00)))\\s(([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d)))$";
    /* / dd/MM/yyyy HH:mm:ss a */String Slash_dd_MM_yyyy_HH_mm_ss_a = "^(((0[1-9]|[12]\\d|3[01])\\/(0[13578]|1[02])\\/((19|[2-9]\\d)\\d{2})\\s(([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d)\\s(AM|am|PM|pm)))|((0[1-9]|[12]\\d|30)\\/(0[13456789]|1[012])\\/((19|[2-9]\\d)\\d{2})\\s(([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d)\\s(AM|am|PM|pm)))|((0[1-9]|1\\d|2[0-8])\\/02\\/((19|[2-9]\\d)\\d{2})\\s(([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d)\\s(AM|am|PM|pm)))|(29\\/02\\/((1[6-9]|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|((16|[2468][048]|[3579][26])00)))\\s(([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d))\\s(AM|am|PM|pm))$";
    /* / dd/MM/yyyy HH:mm:ss.SS */String Slash_dd_MM_yyyy_HH_mm_ss_SS = "^(((0[1-9]|[12]\\d|3[01])\\/(0[13578]|1[02])\\/((19|[2-9]\\d)\\d{2})\\s(([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d)\\.(\\d\\d\\d)))|((0[1-9]|[12]\\d|30)\\/(0[13456789]|1[012])\\/((19|[2-9]\\d)\\d{2})\\s(([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d)\\.(\\d\\d\\d)))|((0[1-9]|1\\d|2[0-8])\\/02\\/((19|[2-9]\\d)\\d{2})\\s(([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d)\\.(\\d\\d\\d)))|(29\\/02\\/((1[6-9]|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|((16|[2468][048]|[3579][26])00)))\\s(([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d))\\.(\\d\\d\\d))$";
    /* / dd/MM/yyyy HH:mm:ss.SSS */String Slash_dd_MM_yyyy_HH_mm_ss_SSS = "^(((0[1-9]|[12]\\d|3[01])\\/(0[13578]|1[02])\\/((19|[2-9]\\d)\\d{2})\\s(([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d)\\.(\\d{3})))|((0[1-9]|[12]\\d|30)\\/(0[13456789]|1[012])\\/((19|[2-9]\\d)\\d{2})\\s(([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d)\\.(\\d{3})))|((0[1-9]|1\\d|2[0-8])\\/02\\/((19|[2-9]\\d)\\d{2})\\s(([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d)\\.(\\d{3})))|(29\\/02\\/((1[6-9]|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|((16|[2468][048]|[3579][26])00)))\\s(([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d))\\.(\\d{3}))$";
    /* / dd/MM/yyyy HH:mm:ss.SSSZ */String Slash_dd_MM_yyyy_HH_mm_ss_SSSZ = "^(((0[1-9]|[12]\\d|3[01])\\/(0[13578]|1[02])\\/((19|[2-9]\\d)\\d{2})\\s(([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d)\\.(\\d{3}\\-\\d{4})))|((0[1-9]|[12]\\d|30)\\/(0[13456789]|1[012])\\/((19|[2-9]\\d)\\d{2})\\s(([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d)\\.(\\d{3}\\-\\d{4})))|((0[1-9]|1\\d|2[0-8])\\/02\\/((19|[2-9]\\d)\\d{2})\\s(([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d)\\.(\\d{3}\\-\\d{4})))|(29\\/02\\/((1[6-9]|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|((16|[2468][048]|[3579][26])00)))\\s(([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d))\\.(\\d{3}\\-\\d{4}))$";
    /* / dd/MM/yyyy'T'HH:mm:ss.SS */String Slash_dd_MM_yyyy_T_HH_mm_ss_SS = "^(((0[1-9]|[12]\\d|3[01])\\/(0[13578]|1[02])\\/((19|[2-9]\\d)\\d{2})\\T(([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d)\\.(\\d{3})))|((0[1-9]|[12]\\d|30)\\/(0[13456789]|1[012])\\/((19|[2-9]\\d)\\d{2})\\T(([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d)\\.(\\d{3})))|((0[1-9]|1\\d|2[0-8])\\/02\\/((19|[2-9]\\d)\\d{2})\\T(([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d)\\.(\\d{3})))|(29\\/02\\/((1[6-9]|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|((16|[2468][048]|[3579][26])00)))\\T(([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d))\\.(\\d{3}))$";
    /* / dd/MM/yyyy'T'HH:mm:ss.SSS */String Slash_dd_MM_yyyy_T_HH_mm_ss_SSS = "^(((0[1-9]|[12]\\d|3[01])\\/(0[13578]|1[02])\\/((19|[2-9]\\d)\\d{2})\\T(([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d)\\.(\\d{3})))|((0[1-9]|[12]\\d|30)\\/(0[13456789]|1[012])\\/((19|[2-9]\\d)\\d{2})\\T(([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d)\\.(\\d{3})))|((0[1-9]|1\\d|2[0-8])\\/02\\/((19|[2-9]\\d)\\d{2})\\T(([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d)\\.(\\d{3})))|(29\\/02\\/((1[6-9]|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|((16|[2468][048]|[3579][26])00)))\\T(([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d))\\.(\\d{3}))$";
    /* / dd/MM/yyyy'T'HH:mm:ss.SSSZ */String Slash_dd_MM_yyyy_T_HH_mm_ss_SSSZ = "^(((0[1-9]|[12]\\d|3[01])\\/(0[13578]|1[02])\\/((19|[2-9]\\d)\\d{2})\\T(([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d)\\.(\\d{3}\\-\\d{4})))|((0[1-9]|[12]\\d|30)\\/(0[13456789]|1[012])\\/((19|[2-9]\\d)\\d{2})\\T(([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d)\\.(\\d{3}\\-\\d{4})))|((0[1-9]|1\\d|2[0-8])\\/02\\/((19|[2-9]\\d)\\d{2})\\T(([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d)\\.(\\d{3}\\-\\d{4})))|(29\\/02\\/((1[6-9]|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|((16|[2468][048]|[3579][26])00)))\\T(([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d))\\.(\\d{3}\\-\\d{4}))$";
    /* / dd/MM/yyyy'T'HH:mm:ss.SSSXXX */String Slash_dd_MM_yyyy_T_HH_mm_ss_SSSXXX = "^(((0[1-9]|[12]\\d|3[01])\\/(0[13578]|1[02])\\/((19|[2-9]\\d)\\d{2})\\T(([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d)\\.(\\d{3}\\-\\d{2}:\\d{2})))|((0[1-9]|[12]\\d|30)\\/(0[13456789]|1[012])\\/((19|[2-9]\\d)\\d{2})\\T(([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d)\\.(\\d{3}\\-\\d{2}:\\d{2})))|((0[1-9]|1\\d|2[0-8])\\/02\\/((19|[2-9]\\d)\\d{2})\\T(([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d)\\.(\\d{3}\\-\\d{2}:\\d{2})))|(29\\/02\\/((1[6-9]|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|((16|[2468][048]|[3579][26])00)))\\T(([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d))\\.(\\d{3}\\-\\d{2}:\\d{2}))$";

    /* / MM/dd/yyyy */String Slash_MM_dd_yyyy = "^(((0[13578]|1[02])\\/(0[1-9]|[12]\\d|3[01])\\/((19|[2-9]\\d)\\d{2}))|((0[13456789]|1[012])\\/(0[1-9]|[12]\\d|30)\\/((19|[2-9]\\d)\\d{2}))|(02\\/(0[1-9]|1\\d|2[0-8])\\/((19|[2-9]\\d)\\d{2}))|(02\\/29\\/((1[6-9]|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|((16|[2468][048]|[3579][26])00))))$\n";
    /* / MM/dd/yyyy HH */String Slash_MM_dd_yyyy_HH = "^(((0[13578]|1[02])\\/(0[1-9]|[12]\\d|3[01])\\/((19|[2-9]\\d)\\d{2})\\s(([01]\\d|2[0-3])))|((0[13456789]|1[012])\\/(0[1-9]|[12]\\d|30)\\/((19|[2-9]\\d)\\d{2})\\s(([01]\\d|2[0-3])))|(02\\/(0[1-9]|1\\d|2[0-8])\\/((19|[2-9]\\d)\\d{2})\\s(([01]\\d|2[0-3])))|((02\\/29\\/((1[6-9]|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|((16|[2468][048]|[3579][26])00)))\\s(([01]\\d|2[0-3]))))$";
    /* / MM/dd/yyyy HH:mm */String Slash_MM_dd_yyyy_HH_mm = "^(((0[13578]|1[02])\\/(0[1-9]|[12]\\d|3[01])\\/((19|[2-9]\\d)\\d{2})\\s(([01]\\d|2[0-3]):([0-5]\\d)))|((0[13456789]|1[012])\\/(0[1-9]|[12]\\d|30)\\/((19|[2-9]\\d)\\d{2})\\s(([01]\\d|2[0-3]):([0-5]\\d)))|(02\\/(0[1-9]|1\\d|2[0-8])\\/((19|[2-9]\\d)\\d{2})\\s(([01]\\d|2[0-3]):([0-5]\\d)))|((02\\/29\\/((1[6-9]|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|((16|[2468][048]|[3579][26])00)))\\s(([01]\\d|2[0-3]):([0-5]\\d))))$";
    /* / */String Slash_MM_dd_yyyy_HH_mm_ss = new String("MM/dd/yyyy HH:mm:ss");
    /* / */String Slash_MM_dd_yyyy_HH_mm_ss_a = new String("MM/dd/yyyy HH:mm:ss a");
    /* / */String Slash_MM_dd_yyyy_HH_mm_ss_SS = new String("MM/dd/yyyy HH:mm:ss.SS");
    /* / */String Slash_MM_dd_yyyy_HH_mm_ss_SSS = new String("MM/dd/yyyy HH:mm:ss.SSS");
    /* / */String Slash_MM_dd_yyyy_HH_mm_ss_SSSZ = new String("MM/dd/yyyy HH:mm:ss.SSSZ");
    /* / */String Slash_MM_dd_yyyy_T_HH_mm_ss_SS = new String("MM/dd/yyyy'T'HH:mm:ss.SS");
    /* / */String Slash_MM_dd_yyyy_T_HH_mm_ss_SSS = new String("MM/dd/yyyy'T'HH:mm:ss.SSS");
    /* / */String Slash_MM_dd_yyyy_T_HH_mm_ss_SSSZ = new String("MM/dd/yyyy'T'HH:mm:ss.SSSZ");
    /* / */String Slash_MM_dd_yyyy_T_HH_mm_ss_SSSXXX = new String("MM/dd/yyyy'T'HH:mm:ss.SSSXXX");

    /* / */String slash_yyyy_MM_dd = new String("yyyy/MM/dd");
    /* / */String slash_yyyy_MM_dd_HH = new String("yyyy/MM/dd HH");
    /* / */String slash_yyyy_MM_dd_HH_mm = new String("yyyy/MM/dd HH:mm");
    /* / */String slash_yyyy_MM_dd_HH_mm_ss = new String("yyyy/MM/dd HH:mm:ss");
    /* / */String slash_yyyy_MM_dd_HH_mm_ss_a = new String("yyyy/MM/dd HH:mm:ss a");
    /* / */String slash_yyyy_MM_dd_HH_mm_ss_SS = new String("yyyy/MM/dd HH:mm:ss.SS");
    /* / */String slash_yyyy_MM_dd_HH_mm_ss_SSS = new String("yyyy/MM/dd HH:mm:ss.SSS");
    /* / */String slash_yyyy_MM_dd_HH_mm_ss_SSSZ = new String("yyyy/MM/ddy HH:mm:ss.SSSZ");
    /* / */String slash_yyyy_MM_dd_T_HH_mm_ss_SS = new String("yyyy/MM/dd'T'HH:mm:ss.SS");
    /* / */String slash_yyyy_MM_dd_T_HH_mm_ss_SSS = new String("yyyy/MM/dd'T'HH:mm:ss.SSS");
    /* / */String slash_yyyy_MM_dd_T_HH_mm_ss_SSSZ = new String("yyyy/MM/dd'T'HH:mm:ss.SSSZ");
    /* / */String slash_yyyy_MM_dd_T_HH_mm_ss_SSSXXX = new String("yyyy/MM/dd'T'HH:mm:ss.SSSXXX");

    /* / */String slash_yyyy_dd_MM = new String("yyyy/dd/MM");
    /* / */String slash_yyyy_dd_MM_HH = new String("yyyy/dd/MM HH");
    /* / */String slash_yyyy_dd_MM_HH_mm = new String("yyyy/dd/MM HH:mm");
    /* / */String slash_yyyy_dd_MM_HH_mm_ss = new String("yyyy/dd/MM HH:mm:ss");
    /* / */String slash_yyyy_dd_MM_HH_mm_ss_a = new String("yyyy/dd/MM HH:mm:ss a");
    /* / */String slash_yyyy_dd_MM_HH_mm_ss_SS = new String("yyyy/dd/MM HH:mm:ss.SS");
    /* / */String slash_yyyy_dd_MM_HH_mm_ss_SSS = new String("yyyy/dd/MM HH:mm:ss.SSS");
    /* / */String slash_yyyy_dd_MM_HH_mm_ss_SSSZ = new String("yyyy/dd/MMy HH:mm:ss.SSSZ");
    /* / */String slash_yyyy_dd_MM_T_HH_mm_ss_SS = new String("yyyy/dd/MM'T'HH:mm:ss.SS");
    /* / */String slash_yyyy_dd_MM_T_HH_mm_ss_SSS = new String("yyyy/dd/MM'T'HH:mm:ss.SSS");
    /* / */String slash_yyyy_dd_MM_T_HH_mm_ss_SSSZ = new String("yyyy/dd/MM'T'HH:mm:ss.SSSZ");
    /* / */String slash_yyyy_dd_MM_T_HH_mm_ss_SSSXXX = new String("yyyy/dd/MM'T'HH:mm:ss.SSSXXX");


//============================= / slash 1 seprator ==========================================================

    /* / */String Slash_dd_MM_yy = new String("dd/MM/yy");
    /* / */String Slash_dd_MM_yy_HH = new String("dd/MM/yy HH");
    /* / */String Slash_dd_MM_yy_HH_mm = new String("dd/MM/yy HH:mm");
    /* / */String Slash_dd_MM_yy_HH_mm_ss = new String("dd/MM/yy HH:mm:ss");
    /* / */String Slash_dd_MM_yy_HH_mm_ss_a = new String("dd/MM/yy HH:mm:ss a");
    /* / */String Slash_dd_MM_yy_HH_mm_ss_SS = new String("dd/MM/yy HH:mm:ss.SS");
    /* / */String Slash_dd_MM_yy_HH_mm_ss_SSS = new String("dd/MM/yy HH:mm:ss.SSS");
    /* / */String Slash_dd_MM_yy_HH_mm_ss_SSSZ = new String("dd/MM/yy HH:mm:ss.SSSZ");
    /* / */String Slash_dd_MM_yy_T_HH_mm_ss_SS = new String("dd/MM/yy'T'HH:mm:ss.SS");
    /* / */String Slash_dd_MM_yy_T_HH_mm_ss_SSS = new String("dd/MM/yy'T'HH:mm:ss.SSS");
    /* / */String Slash_dd_MM_yy_T_HH_mm_ss_SSSZ = new String("dd/MM/yy'T'HH:mm:ss.SSSZ");
    /* / */String Slash_dd_MM_yy_T_HH_mm_ss_SSSXXX = new String("dd/MM/yy'T'HH:mm:ss.SSSXXX");

    /* / */String Slash_MM_dd_yy = new String("MM/dd/yy");
    /* / */String Slash_MM_dd_yy_HH = new String("MM/dd/yy HH");
    /* / */String Slash_MM_dd_yy_HH_mm = new String("MM/dd/yy HH:mm");
    /* / */String Slash_MM_dd_yy_HH_mm_ss = new String("MM/dd/yy HH:mm:ss");
    /* / */String Slash_MM_dd_yy_HH_mm_ss_a = new String("MM/dd/yy HH:mm:ss a");
    /* / */String Slash_MM_dd_yy_HH_mm_ss_SS = new String("MM/dd/yy HH:mm:ss.SS");
    /* / */String Slash_MM_dd_yy_HH_mm_ss_SSS = new String("MM/dd/yy HH:mm:ss.SSS");
    /* / */String Slash_MM_dd_yy_HH_mm_ss_SSSZ = new String("MM/dd/yy HH:mm:ss.SSSZ");
    /* / */String Slash_MM_dd_yy_T_HH_mm_ss_SS = new String("MM/dd/yy'T'HH:mm:ss.SS");
    /* / */String Slash_MM_dd_yy_T_HH_mm_ss_SSS = new String("MM/dd/yy'T'HH:mm:ss.SSS");
    /* / */String Slash_MM_dd_yy_T_HH_mm_ss_SSSZ = new String("MM/dd/yy'T'HH:mm:ss.SSSZ");
    /* / */String Slash_MM_dd_yy_T_HH_mm_ss_SSSXXX = new String("MM/dd/yy'T'HH:mm:ss.SSSXXX");

    /* / */String slash_yy_MM_dd = new String("yy/MM/dd");
    /* / */String slash_yy_MM_dd_HH = new String("yy/MM/dd HH");
    /* / */String slash_yy_MM_dd_HH_mm = new String("yy/MM/dd HH:mm");
    /* / */String slash_yy_MM_dd_HH_mm_ss = new String("yy/MM/dd HH:mm:ss");
    /* / */String slash_yy_MM_dd_HH_mm_ss_a = new String("yy/MM/dd HH:mm:ss a");
    /* / */String slash_yy_MM_dd_HH_mm_ss_SS = new String("yy/MM/dd HH:mm:ss.SS");
    /* / */String slash_yy_MM_dd_HH_mm_ss_SSS = new String("yy/MM/dd HH:mm:ss.SSS");
    /* / */String slash_yy_MM_dd_HH_mm_ss_SSSZ = new String("yy/MM/ddy HH:mm:ss.SSSZ");
    /* / */String slash_yy_MM_dd_T_HH_mm_ss_SS = new String("yy/MM/dd'T'HH:mm:ss.SS");
    /* / */String slash_yy_MM_dd_T_HH_mm_ss_SSS = new String("yy/MM/dd'T'HH:mm:ss.SSS");
    /* / */String slash_yy_MM_dd_T_HH_mm_ss_SSSZ = new String("yy/MM/dd'T'HH:mm:ss.SSSZ");
    /* / */String slash_yy_MM_dd_T_HH_mm_ss_SSSXXX = new String("yy/MM/dd'T'HH:mm:ss.SSSXXX");

    /* / */String slash_yy_dd_MM = new String("yy/dd/MM");
    /* / */String slash_yy_dd_MM_HH = new String("yy/dd/MM HH");
    /* / */String slash_yy_dd_MM_HH_mm = new String("yy/dd/MM HH:mm");
    /* / */String slash_yy_dd_MM_HH_mm_ss = new String("yy/dd/MM HH:mm:ss");
    /* / */String slash_yy_dd_MM_HH_mm_ss_a = new String("yy/dd/MM HH:mm:ss a");
    /* / */String slash_yy_dd_MM_HH_mm_ss_SS = new String("yy/dd/MM HH:mm:ss.SS");
    /* / */String slash_yy_dd_MM_HH_mm_ss_SSS = new String("yy/dd/MM HH:mm:ss.SSS");
    /* / */String slash_yy_dd_MM_HH_mm_ss_SSSZ = new String("yy/dd/MMy HH:mm:ss.SSSZ");
    /* / */String slash_yy_dd_MM_T_HH_mm_ss_SS = new String("yy/dd/MM'T'HH:mm:ss.SS");
    /* / */String slash_yy_dd_MM_T_HH_mm_ss_SSS = new String("yy/dd/MM'T'HH:mm:ss.SSS");
    /* / */String slash_yy_dd_MM_T_HH_mm_ss_SSSZ = new String("yy/dd/MM'T'HH:mm:ss.SSSZ");
    /* / */String slash_yy_dd_MM_T_HH_mm_ss_SSSXXX = new String("yy/dd/MM'T'HH:mm:ss.SSSXXX");


    /*-*/String dayname_month_dd_yyyy_hh = new String("EEEE, MMMM dd, yyyy h:mm:ss aa zzz");//Thursday, July 27, 2006 10:10:02 PM PST
    /*-*/String day_mon_dd_yy = new String("EEE, MMM dd, ''yy");//Wed, Jul 04, '01
    /*-*/String day_mon_dd_yyyy = new String("EEE, MMM dd, ''yyyy");//Wed, Jul 04, '01
    /* Space */String MM_c_dd_yyyy = new String("MM, dd yyyy");
    /*Space*/String EEEEE_dd_MMMM_yyyy = new String("EEEEE, dd MMMM yyyy");
    /* SPACE */String EEEEE_MMMMM_yyyy_HH_mm_ss_SSSZ = new String("EEEEE MMMMM yyyy HH:mm:ss.SSSZ");
}
