package com.freshvegitable.utils;

import android.util.Log;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class DateUtils implements DateFormats
{
	// ADD WEEKS, MONTHS, YEARS
	public enum DIFF{MILLI, SECONDS, MINUTES, HOURS, WEEKS, DAYS, YEARS}
	public enum FORMAT{hh_mm, hh_mm_ss}
	
	public static long compareDates(String sdate1, String sdate2, String dateFormat)
	{
		long difference = 10;
		try
		{
			SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
			Date date1 = sdf.parse(sdate1);
			Date date2 = new Date();

			if(sdate2 == null || sdate2.equals(""))
			{
				sdate2 = returnTodayDate(dateFormat);
				date2 = sdf.parse(sdate2);
			}
			else if(sdate2.length() > 0 && isValidDate(sdate2, dateFormat))
			{			
				date2 = sdf.parse(sdate2);
			}

			/*
			 * If Date1 is greater than Date2
			 */
			if(date1.compareTo(date2) > 0)
			{
				difference = 1;
			}
			/*
			 * If Date1 is less than Date2
			 */
			else if(date1.compareTo(date2) < 0)
			{
				difference = -1;
			}
			/*
			 * If Date1 is equal to Date2
			 */
			else if(date1.compareTo(date2) == 0)
			{
				difference = 0;
			}			
			//Log.i("UtilsLibrary","Difference : "+difference);
			System.out.println("Difference : "+difference);
			return difference;
		}
		catch(Exception e)
		{
			System.out.println("Caught exception while comparing / parsing dates : "+e);
			return difference;
		}		
	}



	public static long compareBeforeAfter(String sdate1, String sdate2, String dateFormat)
	{
		long difference = 10;
		try
		{
			SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
			Date date1 = sdf.parse(sdate1);
			Date date2 = new Date();

			if(sdate2 == null || sdate2.equals(""))
			{
				sdate2 = returnTodayDate(dateFormat);
				date2 = sdf.parse(sdate2);
			}
			else if(sdate2.length() > 0 && isValidDate(sdate2, dateFormat))
			{
				date2 = sdf.parse(sdate2);
			}

			/*
			 * If Date1 is greater than Date2
			 */
			if(date1.after(date2))
			{
				difference = 1;
			}
			/*
			 * If Date1 is less than Date2
			 */
			else if(date1.before(date2))
			{
				difference = -1;
			}
			/*
			 * If Date1 is equal to Date2
			 */
			else if(date1.equals(date2))
			{
				difference = 0;
			}
			//Log.i("UtilsLibrary","Difference : "+difference);
			System.out.println("Difference : "+difference);
			return difference;
		}
		catch(Exception e)
		{
			System.out.println("Caught exception while comparing / parsing dates : "+e);
			return difference;
		}
	}


	public static boolean isValidDate(String inDate, String format)
	{
		SimpleDateFormat dateFormat = new SimpleDateFormat(format);
		// By default SimpleDateFormat set Lenient to true. So we should set it false if we want strict check up.
		dateFormat.setLenient(false);
		try 
		{
			dateFormat.parse(inDate.trim());
		}
		catch (ParseException pe)
		{
			System.out.println("Caught parse exception : "+pe);
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Caught some exception : "+e);
			return false;
		}
		return true;
	}

	public static String returnTodayDate(String format)
	{ 
		String todaysDate = "NA";
		String output = "";
		try
		{			
			if(format.length() != 0)
			{
				SimpleDateFormat dateFormat = new SimpleDateFormat(format);
				final Calendar c = Calendar.getInstance();
				output = dateFormat.format(c.getTime());
				if(isValidDate(output,format))
				{
					//System.out.println("Date [after operation] : "+output);
					return output;
				}
				else
				{
					//System.out.println("Invalid Date value, hence returned 'NA'"); 
					return "NA";
				}
			}
			else
			{
				//System.out.println("Date Formatter is not appropriate, hence returned 'NA'"); 
				return "NA";
			}
		}
		catch(Exception e)
		{
			return todaysDate;
		}
	}
	
	/*
	 * mDate1 - Start Date
	 * mDate2 - End Date
	 */
	public static String mDateDifference(String mDate1, String mDate2, String mDateFormat, DIFF diff)
	{
		String mDateDifference = "NA";
		long mDiff = 0;
		Date date1, date2;
		try
		{
			SimpleDateFormat sdf = new SimpleDateFormat(mDateFormat);
			if(mDate2 == null || mDate2.equals(""))
			{
				mDate2 = returnTodayDate(sdf.toPattern());
				date2 = sdf.parse(mDate2);
			}
			date1 = sdf.parse(mDate1);
			date2 = sdf.parse(mDate2);
			mDiff = date2.getTime() - date1.getTime();
			switch (diff) 
			{
				case MILLI:
				{
					mDateDifference = String.valueOf(mDiff);
				}
				break;
				case SECONDS:
				{
					mDateDifference = String.valueOf(mDiff / 1000 % 60);
				}
				break;
				case MINUTES:
				{
					mDateDifference = String.valueOf(mDiff / (60 * 1000) % 60);
				}
				break;
				case HOURS:
				{
					mDateDifference = String.valueOf(mDiff / (60 * 60 * 1000));
				}
				break;
				case DAYS:
				{
					mDateDifference = String.valueOf(mDiff / (24 * 60 * 60 * 1000));
				}
				break;
				case WEEKS:
				{
					mDateDifference = String.valueOf(mDiff / (7 * 24 * 60 * 60 * 1000));
				}
				break;
				case YEARS:
				{
					mDateDifference = String.valueOf(mDiff / (1000L * 60 * 60 * 24 * 365));
				}
				break;
				default:
				{
					mDateDifference = "NA";
				}
				break;
			}
		}
		catch(Exception e)
		{
			System.out.println("Caught exception : "+e);
		}
		return mDateDifference;
	}
	
	public static String mReturnFormattedDate(String mDate, String sdf, String req)
	{
		try
		{
			Log.i(Constant.TAG,"formateDate"+mDate);
			Log.i(Constant.TAG,"sdf"+sdf);
			if (mDate != null && !mDate.equalsIgnoreCase(""))
			{
				SimpleDateFormat format = new SimpleDateFormat(sdf, Locale.US);
				Date date = format.parse(mDate);

				//Date date = new SimpleDateFormat(sdf).parse(mDate);
				String dateString = new SimpleDateFormat(req).format(date);
				Log.i(Constant.TAG,"dateString"+dateString);
				return dateString;
			}
			else
			{
				return "";
			}
		}
		catch(Exception e)
		{
			Log.e(Constant.TAG,"returnformatedateException",e);
			return "";
		}
		//return "NA";
	}

	public static String mReturnFormattedDate1(String mDate, String sdf, String req)
	{
		try
		{
			Log.i(Constant.TAG,"formateDate"+mDate);
			Log.i(Constant.TAG,"sdf"+sdf);
			if (mDate != null && !mDate.equalsIgnoreCase(""))
			{
				Date date = null;
				/*if (Constant.aplfileType.equalsIgnoreCase("axislocal") || Constant.aplfileType.equalsIgnoreCase("axisuat")
						|| Constant.aplfileType.equalsIgnoreCase("mobilocal") )
				{
					SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss a", Locale.US);
					date = format.parse(mDate);
				}
				else*/
				{
					SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss a", Locale.US);
					date = format.parse(mDate);
				}

				//Date date = new SimpleDateFormat(sdf).parse(mDate);
				String dateString = new SimpleDateFormat(req).format(date);
				Log.i(Constant.TAG,"dateString"+dateString);
				return dateString;
			}
			else
			{
				return "";
			}
		}
		catch(Exception e)
		{
			Log.e(Constant.TAG,"returnformatedateException",e);
			return "";
		}
		//return "NA";
	}
	
	public static String getTimeAsPerFormat(FORMAT format, String mDate1, String mDate2, SimpleDateFormat sdf)
	{
		String mDateTime = "NA";
		Date date1, date2;
		long mDiff = 0;
		try
		{
			if(mDate2 == null || mDate2.equals(""))
			{
				mDate2 = returnTodayDate(sdf.toPattern());
				date2 = sdf.parse(mDate2);
			}
			date1 = sdf.parse(mDate1);
			date2 = sdf.parse(mDate2);
			mDiff = date2.getTime() - date1.getTime();
			System.out.println("mDiff : "+mDiff);
			
			switch (format)
			{
			case hh_mm:
				mDateTime = String.valueOf(mDiff / (60 * 60 * 1000))+" hr "+ String.valueOf(mDiff / (60 * 1000) % 60)+" min";
				break;
			case hh_mm_ss:
				mDateTime = String.valueOf(mDiff / (60 * 60 * 1000))+" hr "+ String.valueOf(mDiff / (60 * 1000) % 60)+" min "+ String.valueOf(mDiff / 1000 % 60)+" secs";
				break;
			
			default:
				break;
			}
			
			return mDateTime;			
		}
		catch(Exception e)
		{
			
		}
		return mDateTime;
	}
	
	public static String rupeeFormat(String value)
    {
		String mResult = "", result = "", temp = "";
		char lastDigit = '0';
        try
        {
        	temp = value;
        	mResult = value;
        	
        	if(value.startsWith("-") && value.contains("."))
        	{
        		value = value.substring(1, value.length() - 1);
        		value = value.split("\\.")[0];	
        		temp = "."+temp.split("\\.")[1];
        	}
        	else if (value.contains("."))
        	{
        		value = value.split("\\.")[0];	
        		temp = "."+temp.split("\\.")[1];
			}
        	else
        	{
        		value = value.replace(",", "");
        		temp = "";
        	}
			lastDigit = value.charAt(value.length() - 1);
			int len = value.length() - 1;
			int nDigits = 0;
			for (int i = len - 1; i >= 0; i--)
			{
				result = value.charAt(i) + result;
				nDigits++;
				if (((nDigits % 2) == 0) && (i > 0)) 
				{
					result = "," + result;
				}
			}
			if (mResult.startsWith("-")) 
			{
				return ("-"+result + lastDigit + temp);
			}
			else
			{
				return (result + lastDigit + temp);
			}
        }
        catch(Exception e)
        {
        	
        }
        return "0.00";
    }
	
    public static String rupeeFormatWithDecimal(String value)
    {
        String final_result = "";
        value = value.replace(",","");
        String val_arr[] = {"0.0"};
        if (value.contains("."))
        {
            val_arr =  value.replace(",","").split(".");
        }
        value = val_arr[0];
        char lastDigit=value.charAt(value.length()-1);
        String result = "";
        int len = value.length()-1;
        int nDigits = 0;

        for (int i = len - 1; i >= 0; i--)
        {
            result = value.charAt(i) + result;
            nDigits++;
            if (((nDigits % 2) == 0) && (i > 0))
            {
                result = "," + result;
            }
        }
        if(val_arr.length>1)
        {
            final_result = result + lastDigit+"."+val_arr[1];
        }
        else
        {
            final_result = result + lastDigit;
        }
        return final_result;
    }

	public static String returnDatePreviousAfter(String date1, String date1formate, int days, DIFF diff)
	{


		String expecteddate = "";
		try
		{
			SimpleDateFormat dateFormat = new SimpleDateFormat(date1formate, Locale.getDefault());
			Date date = dateFormat.parse(date1);
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(date);
			//calendar.add(Calendar.DATE, days);
			calendar.add(Calendar.MINUTE, days);
			expecteddate = dateFormat.format(calendar.getTime());
			return expecteddate;

		} catch (ParseException e)
		{
			Log.e(Constant.TAG,"returndate_Exception",e);
			return "";
		}



	}

	public static long returnTimeInMilliSecs(String mDate)
	{
		try
		{


			// 2016-02-23 09:12 PM
			DateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm a");
			Date date1 = format.parse(mDate); // Expiry Date
			Date date2 = format.parse(returnTodayDate("yyyy-MM-dd hh:mm a")); // Current Date
			long milliseconds = date1.getTime() - date2.getTime();
			Log.i(Constant.TAG, "Milli seconds : "+milliseconds);

			/// milliseconds = 10_000;

			return  milliseconds;
		}
		catch (Exception e)
		{
			Log.e(Constant.TAG, "Caught exception", e);
		}

		// Default is 2 hours
		return 60_000 * 60 * 2 ;
	}


}
