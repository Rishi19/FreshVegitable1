package com.freshvegitable.utils;

import java.text.SimpleDateFormat;

public interface DateFormats
{


	//============================= - Dash seprator ==========================================================

	/*-*/SimpleDateFormat dd_MM_yyyy = new SimpleDateFormat("dd-MM-yyyy");
	/*-*/SimpleDateFormat dd_MM_yyyy_HH = new SimpleDateFormat("dd-MM-yyyy HH");
	/*-*/SimpleDateFormat dd_MM_yyyy_HH_mm = new SimpleDateFormat("dd-MM-yyyy HH:mm");
	/*-*/SimpleDateFormat dd_MM_yyyy_HH_mm_ss = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
	/*-*/SimpleDateFormat dd_MM_yyyy_HH_mm_ss_a = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss a");
	/*-*/SimpleDateFormat dd_MM_yyyy_HH_mm_ss_SS = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss.SS");
	/*-*/SimpleDateFormat dd_MM_yyyy_HH_mm_ss_SSS = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss.SSS");
	/*-*/SimpleDateFormat dd_MM_yyyy_HH_mm_ss_SSSZ = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss.SSSZ");
	/*-*/SimpleDateFormat dd_MM_yyyy_T_HH_mm_ss_SS = new SimpleDateFormat("dd-MM-yyyy'T'HH:mm:ss.SS");
	/*-*/SimpleDateFormat dd_MM_yyyy_T_HH_mm_ss_SSS = new SimpleDateFormat("dd-MM-yyyy'T'HH:mm:ss.SSS");
	/*-*/SimpleDateFormat dd_MM_yyyy_T_HH_mm_ss_SSSZ = new SimpleDateFormat("dd-MM-yyyy'T'HH:mm:ss.SSSZ");
	/*-*/SimpleDateFormat dd_MM_yyyy_T_HH_mm_ss_SSSXXX = new SimpleDateFormat("dd-MM-yyyy'T'HH:mm:ss.SSSXXX");

	/*-*/SimpleDateFormat MM_dd_yyyy = new SimpleDateFormat("MM-dd-yyyy");
	/*-*/SimpleDateFormat MM_dd_yyyy_HH = new SimpleDateFormat("MM-dd-yyyy HH");
	/*-*/SimpleDateFormat MM_dd_yyyy_HH_mm = new SimpleDateFormat("MM-dd-yyyy HH:mm");
	/*-*/SimpleDateFormat MM_dd_yyyy_HH_mm_ss = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");
	/*-*/SimpleDateFormat MM_dd_yyyy_HH_mm_ss_a = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss a");
	/*-*/SimpleDateFormat MM_dd_yyyy_HH_mm_ss_SS = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss.SS");
	/*-*/SimpleDateFormat MM_dd_yyyy_HH_mm_ss_SSS = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss.SSS");
	/*-*/SimpleDateFormat MM_dd_yyyy_HH_mm_ss_SSSZ = new SimpleDateFormat("MM-dd-yyyyy HH:mm:ss.SSSZ");
	/*-*/SimpleDateFormat MM_dd_yyyy_T_HH_mm_ss_SS = new SimpleDateFormat("MM-dd-yyyy'T'HH:mm:ss.SS");
	/*-*/SimpleDateFormat MM_dd_yyyy_T_HH_mm_ss_SSS = new SimpleDateFormat("MM-dd-yyyy'T'HH:mm:ss.SSS");
	/*-*/SimpleDateFormat MM_dd_yyyy_T_HH_mm_ss_SSSZ = new SimpleDateFormat("MM-dd-yyyy'T'HH:mm:ss.SSSZ");
	/*-*/SimpleDateFormat MM_dd_yyyy_T_HH_mm_ss_SSSXXX = new SimpleDateFormat("MM-dd-yyyy'T'HH:mm:ss.SSSXXX");

	/*-*/SimpleDateFormat yyyy_MM_dd = new SimpleDateFormat("yyyy-MM-dd");
	/*-*/SimpleDateFormat yyyy_MM_dd_HH = new SimpleDateFormat("yyyy-MM-dd HH");
	/*-*/SimpleDateFormat yyyy_MM_dd_HH_mm = new SimpleDateFormat("yyyy-MM-dd HH:mm");
	/*-*/SimpleDateFormat yyyy_MM_dd_HH_mm_ss = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	/*-*/SimpleDateFormat yyyy_MM_dd_HH_mm_ss_a = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss a");
	/*-*/SimpleDateFormat yyyy_MM_dd_HH_mm_ss_SS = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SS");
	/*-*/SimpleDateFormat yyyy_MM_dd_HH_mm_ss_SSS = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
	/*-*/SimpleDateFormat yyyy_MM_dd_HH_mm_ss_SSSZ = new SimpleDateFormat("yyyy-MM-ddy HH:mm:ss.SSSZ");
	/*-*/SimpleDateFormat yyyy_MM_dd_T_HH_mm_ss_SS = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SS");
	/*-*/SimpleDateFormat yyyy_MM_dd_T_HH_mm_ss_SSS = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
	/*-*/SimpleDateFormat yyyy_MM_dd_T_HH_mm_ss_SSSZ = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
	/*-*/SimpleDateFormat yyyy_MM_dd_T_HH_mm_ss_SSSXXX = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");

	/*-*/SimpleDateFormat yyyy_dd_MM = new SimpleDateFormat("yyyy-dd-MM");
	/*-*/SimpleDateFormat yyyy_dd_MM_HH = new SimpleDateFormat("yyyy-dd-MM HH");
	/*-*/SimpleDateFormat yyyy_dd_MM_HH_mm = new SimpleDateFormat("yyyy-dd-MM HH:mm");
	/*-*/SimpleDateFormat yyyy_dd_MM_HH_mm_ss = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
	/*-*/SimpleDateFormat yyyy_dd_MM_HH_mm_ss_a = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss a");
	/*-*/SimpleDateFormat yyyy_dd_MM_HH_mm_ss_SS = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss.SS");
	/*-*/SimpleDateFormat yyyy_dd_MM_HH_mm_ss_SSS = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss.SSS");
	/*-*/SimpleDateFormat yyyy_dd_MM_HH_mm_ss_SSSZ = new SimpleDateFormat("yyyy-dd-MMy HH:mm:ss.SSSZ");
	/*-*/SimpleDateFormat yyyy_dd_MM_T_HH_mm_ss_SS = new SimpleDateFormat("yyyy-dd-MM'T'HH:mm:ss.SS");
	/*-*/SimpleDateFormat yyyy_dd_MM_T_HH_mm_ss_SSS = new SimpleDateFormat("yyyy-dd-MM'T'HH:mm:ss.SSS");
	/*-*/SimpleDateFormat yyyy_dd_MM_T_HH_mm_ss_SSSZ = new SimpleDateFormat("yyyy-dd-MM'T'HH:mm:ss.SSSZ");
	/*-*/SimpleDateFormat yyyy_dd_MM_T_HH_mm_ss_SSSXXX = new SimpleDateFormat("yyyy-dd-MM'T'HH:mm:ss.SSSXXX");


	//============================= - DASH 1 seprator ==========================================================

	/*-*/SimpleDateFormat dd_MM_yy = new SimpleDateFormat("dd-MM-yy");
	/*-*/SimpleDateFormat dd_MM_yy_HH = new SimpleDateFormat("dd-MM-yy HH");
	/*-*/SimpleDateFormat dd_MM_yy_HH_mm = new SimpleDateFormat("dd-MM-yy HH:mm");
	/*-*/SimpleDateFormat dd_MM_yy_HH_mm_ss = new SimpleDateFormat("dd-MM-yy HH:mm:ss");
	/*-*/SimpleDateFormat dd_MM_yy_HH_mm_ss_a = new SimpleDateFormat("dd-MM-yy HH:mm:ss a");
	/*-*/SimpleDateFormat dd_MM_yy_HH_mm_ss_SS = new SimpleDateFormat("dd-MM-yy HH:mm:ss.SS");
	/*-*/SimpleDateFormat dd_MM_yy_HH_mm_ss_SSS = new SimpleDateFormat("dd-MM-yy HH:mm:ss.SSS");
	/*-*/SimpleDateFormat dd_MM_yy_HH_mm_ss_SSSZ = new SimpleDateFormat("dd-MM-yy HH:mm:ss.SSSZ");
	/*-*/SimpleDateFormat dd_MM_yy_T_HH_mm_ss_SS = new SimpleDateFormat("dd-MM-yy'T'HH:mm:ss.SS");
	/*-*/SimpleDateFormat dd_MM_yy_T_HH_mm_ss_SSS = new SimpleDateFormat("dd-MM-yy'T'HH:mm:ss.SSS");
	/*-*/SimpleDateFormat dd_MM_yy_T_HH_mm_ss_SSSZ = new SimpleDateFormat("dd-MM-yy'T'HH:mm:ss.SSSZ");
	/*-*/SimpleDateFormat dd_MM_yy_T_HH_mm_ss_SSSXXX = new SimpleDateFormat("dd-MM-yy'T'HH:mm:ss.SSSXXX");

	/*-*/SimpleDateFormat MM_dd_yy = new SimpleDateFormat("MM-dd-yy");
	/*-*/SimpleDateFormat MM_dd_yy_HH = new SimpleDateFormat("MM-dd-yy HH");
	/*-*/SimpleDateFormat MM_dd_yy_HH_mm = new SimpleDateFormat("MM-dd-yy HH:mm");
	/*-*/SimpleDateFormat MM_dd_yy_HH_mm_ss = new SimpleDateFormat("MM-dd-yy HH:mm:ss");
	/*-*/SimpleDateFormat MM_dd_yy_HH_mm_ss_a = new SimpleDateFormat("MM-dd-yy HH:mm:ss a");
	/*-*/SimpleDateFormat MM_dd_yy_HH_mm_ss_SS = new SimpleDateFormat("MM-dd-yy HH:mm:ss.SS");
	/*-*/SimpleDateFormat MM_dd_yy_HH_mm_ss_SSS = new SimpleDateFormat("MM-dd-yy HH:mm:ss.SSS");
	/*-*/SimpleDateFormat MM_dd_yy_HH_mm_ss_SSSZ = new SimpleDateFormat("MM-dd-yyy HH:mm:ss.SSSZ");
	/*-*/SimpleDateFormat MM_dd_yy_T_HH_mm_ss_SS = new SimpleDateFormat("MM-dd-yy'T'HH:mm:ss.SS");
	/*-*/SimpleDateFormat MM_dd_yy_T_HH_mm_ss_SSS = new SimpleDateFormat("MM-dd-yy'T'HH:mm:ss.SSS");
	/*-*/SimpleDateFormat MM_dd_yy_T_HH_mm_ss_SSSZ = new SimpleDateFormat("MM-dd-yy'T'HH:mm:ss.SSSZ");
	/*-*/SimpleDateFormat MM_dd_yy_T_HH_mm_ss_SSSXXX = new SimpleDateFormat("MM-dd-yy'T'HH:mm:ss.SSSXXX");

	/*-*/SimpleDateFormat yy_MM_dd = new SimpleDateFormat("yy-MM-dd");
	/*-*/SimpleDateFormat yy_MM_dd_HH = new SimpleDateFormat("yy-MM-dd HH");
	/*-*/SimpleDateFormat yy_MM_dd_HH_mm = new SimpleDateFormat("yy-MM-dd HH:mm");
	/*-*/SimpleDateFormat yy_MM_dd_HH_mm_ss = new SimpleDateFormat("yy-MM-dd HH:mm:ss");
	/*-*/SimpleDateFormat yy_MM_dd_HH_mm_ss_a = new SimpleDateFormat("yy-MM-dd HH:mm:ss a");
	/*-*/SimpleDateFormat yy_MM_dd_HH_mm_ss_SS = new SimpleDateFormat("yy-MM-dd HH:mm:ss.SS");
	/*-*/SimpleDateFormat yy_MM_dd_HH_mm_ss_SSS = new SimpleDateFormat("yy-MM-dd HH:mm:ss.SSS");
	/*-*/SimpleDateFormat yy_MM_dd_HH_mm_ss_SSSZ = new SimpleDateFormat("yy-MM-ddy HH:mm:ss.SSSZ");
	/*-*/SimpleDateFormat yy_MM_dd_T_HH_mm_ss_SS = new SimpleDateFormat("yy-MM-dd'T'HH:mm:ss.SS");
	/*-*/SimpleDateFormat yy_MM_dd_T_HH_mm_ss_SSS = new SimpleDateFormat("yy-MM-dd'T'HH:mm:ss.SSS");
	/*-*/SimpleDateFormat yy_MM_dd_T_HH_mm_ss_SSSZ = new SimpleDateFormat("yy-MM-dd'T'HH:mm:ss.SSSZ");
	/*-*/SimpleDateFormat yy_MM_dd_T_HH_mm_ss_SSSXXX = new SimpleDateFormat("yy-MM-dd'T'HH:mm:ss.SSSXXX");

	/*-*/SimpleDateFormat yy_dd_MM = new SimpleDateFormat("yy-dd-MM");
	/*-*/SimpleDateFormat yy_dd_MM_HH = new SimpleDateFormat("yy-dd-MM HH");
	/*-*/SimpleDateFormat yy_dd_MM_HH_mm = new SimpleDateFormat("yy-dd-MM HH:mm");
	/*-*/SimpleDateFormat yy_dd_MM_HH_mm_ss = new SimpleDateFormat("yy-dd-MM HH:mm:ss");
	/*-*/SimpleDateFormat yy_dd_MM_HH_mm_ss_a = new SimpleDateFormat("yy-dd-MM HH:mm:ss a");
	/*-*/SimpleDateFormat yy_dd_MM_HH_mm_ss_SS = new SimpleDateFormat("yy-dd-MM HH:mm:ss.SS");
	/*-*/SimpleDateFormat yy_dd_MM_HH_mm_ss_SSS = new SimpleDateFormat("yy-dd-MM HH:mm:ss.SSS");
	/*-*/SimpleDateFormat yy_dd_MM_HH_mm_ss_SSSZ = new SimpleDateFormat("yy-dd-MMy HH:mm:ss.SSSZ");
	/*-*/SimpleDateFormat yy_dd_MM_T_HH_mm_ss_SS = new SimpleDateFormat("yy-dd-MM'T'HH:mm:ss.SS");
	/*-*/SimpleDateFormat yy_dd_MM_T_HH_mm_ss_SSS = new SimpleDateFormat("yy-dd-MM'T'HH:mm:ss.SSS");
	/*-*/SimpleDateFormat yy_dd_MM_T_HH_mm_ss_SSSZ = new SimpleDateFormat("yy-dd-MM'T'HH:mm:ss.SSSZ");
	/*-*/SimpleDateFormat yy_dd_MM_T_HH_mm_ss_SSSXXX = new SimpleDateFormat("yy-dd-MM'T'HH:mm:ss.SSSXXX");


	//============================= / slash seprator ==========================================================

	/* / */SimpleDateFormat Slash_dd_MM_yyyy = new SimpleDateFormat("dd/MM/yyyy");
	/* / */SimpleDateFormat Slash_dd_MM_yyyy_HH = new SimpleDateFormat("dd/MM/yyyy HH");
	/* / */SimpleDateFormat Slash_dd_MM_yyyy_HH_mm = new SimpleDateFormat("dd/MM/yyyy HH:mm");
	/* / */SimpleDateFormat Slash_dd_MM_yyyy_HH_mm_ss = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
	/* / */SimpleDateFormat Slash_dd_MM_yyyy_HH_mm_ss_a = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss a");
	/* / */SimpleDateFormat Slash_dd_MM_yyyy_HH_mm_ss_SS = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss.SS");
	/* / */SimpleDateFormat Slash_dd_MM_yyyy_HH_mm_ss_SSS = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss.SSS");
	/* / */SimpleDateFormat Slash_dd_MM_yyyy_HH_mm_ss_SSSZ = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss.SSSZ");
	/* / */SimpleDateFormat Slash_dd_MM_yyyy_T_HH_mm_ss_SS = new SimpleDateFormat("dd/MM/yyyy'T'HH:mm:ss.SS");
	/* / */SimpleDateFormat Slash_dd_MM_yyyy_T_HH_mm_ss_SSS = new SimpleDateFormat("dd/MM/yyyy'T'HH:mm:ss.SSS");
	/* / */SimpleDateFormat Slash_dd_MM_yyyy_T_HH_mm_ss_SSSZ = new SimpleDateFormat("dd/MM/yyyy'T'HH:mm:ss.SSSZ");
	/* / */SimpleDateFormat Slash_dd_MM_yyyy_T_HH_mm_ss_SSSXXX = new SimpleDateFormat("dd/MM/yyyy'T'HH:mm:ss.SSSXXX");

	/* / */SimpleDateFormat Slash_MM_dd_yyyy = new SimpleDateFormat("MM/dd/yyyy");
	/* / */SimpleDateFormat Slash_MM_dd_yyyy_HH = new SimpleDateFormat("MM/dd/yyyy HH");
	/* / */SimpleDateFormat Slash_MM_dd_yyyy_HH_mm = new SimpleDateFormat("MM/dd/yyyy HH:mm");
	/* / */SimpleDateFormat Slash_MM_dd_yyyy_HH_mm_ss = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
	/* / */SimpleDateFormat Slash_MM_dd_yyyy_HH_mm_ss_a = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss a");
	/* / */SimpleDateFormat Slash_MM_dd_yyyy_HH_mm_ss_SS = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss.SS");
	/* / */SimpleDateFormat Slash_MM_dd_yyyy_HH_mm_ss_SSS = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss.SSS");
	/* / */SimpleDateFormat Slash_MM_dd_yyyy_HH_mm_ss_SSSZ = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss.SSSZ");
	/* / */SimpleDateFormat Slash_MM_dd_yyyy_T_HH_mm_ss_SS = new SimpleDateFormat("MM/dd/yyyy'T'HH:mm:ss.SS");
	/* / */SimpleDateFormat Slash_MM_dd_yyyy_T_HH_mm_ss_SSS = new SimpleDateFormat("MM/dd/yyyy'T'HH:mm:ss.SSS");
	/* / */SimpleDateFormat Slash_MM_dd_yyyy_T_HH_mm_ss_SSSZ = new SimpleDateFormat("MM/dd/yyyy'T'HH:mm:ss.SSSZ");
	/* / */SimpleDateFormat Slash_MM_dd_yyyy_T_HH_mm_ss_SSSXXX = new SimpleDateFormat("MM/dd/yyyy'T'HH:mm:ss.SSSXXX");

	/* / */SimpleDateFormat slash_yyyy_MM_dd = new SimpleDateFormat("yyyy/MM/dd");
	/* / */SimpleDateFormat slash_yyyy_MM_dd_HH = new SimpleDateFormat("yyyy/MM/dd HH");
	/* / */SimpleDateFormat slash_yyyy_MM_dd_HH_mm = new SimpleDateFormat("yyyy/MM/dd HH:mm");
	/* / */SimpleDateFormat slash_yyyy_MM_dd_HH_mm_ss = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	/* / */SimpleDateFormat slash_yyyy_MM_dd_HH_mm_ss_a = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss a");
	/* / */SimpleDateFormat slash_yyyy_MM_dd_HH_mm_ss_SS = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SS");
	/* / */SimpleDateFormat slash_yyyy_MM_dd_HH_mm_ss_SSS = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS");
	/* / */SimpleDateFormat slash_yyyy_MM_dd_HH_mm_ss_SSSZ = new SimpleDateFormat("yyyy/MM/ddy HH:mm:ss.SSSZ");
	/* / */SimpleDateFormat slash_yyyy_MM_dd_T_HH_mm_ss_SS = new SimpleDateFormat("yyyy/MM/dd'T'HH:mm:ss.SS");
	/* / */SimpleDateFormat slash_yyyy_MM_dd_T_HH_mm_ss_SSS = new SimpleDateFormat("yyyy/MM/dd'T'HH:mm:ss.SSS");
	/* / */SimpleDateFormat slash_yyyy_MM_dd_T_HH_mm_ss_SSSZ = new SimpleDateFormat("yyyy/MM/dd'T'HH:mm:ss.SSSZ");
	/* / */SimpleDateFormat slash_yyyy_MM_dd_T_HH_mm_ss_SSSXXX = new SimpleDateFormat("yyyy/MM/dd'T'HH:mm:ss.SSSXXX");

	/* / */SimpleDateFormat slash_yyyy_dd_MM = new SimpleDateFormat("yyyy/dd/MM");
	/* / */SimpleDateFormat slash_yyyy_dd_MM_HH = new SimpleDateFormat("yyyy/dd/MM HH");
	/* / */SimpleDateFormat slash_yyyy_dd_MM_HH_mm = new SimpleDateFormat("yyyy/dd/MM HH:mm");
	/* / */SimpleDateFormat slash_yyyy_dd_MM_HH_mm_ss = new SimpleDateFormat("yyyy/dd/MM HH:mm:ss");
	/* / */SimpleDateFormat slash_yyyy_dd_MM_HH_mm_ss_a = new SimpleDateFormat("yyyy/dd/MM HH:mm:ss a");
	/* / */SimpleDateFormat slash_yyyy_dd_MM_HH_mm_ss_SS = new SimpleDateFormat("yyyy/dd/MM HH:mm:ss.SS");
	/* / */SimpleDateFormat slash_yyyy_dd_MM_HH_mm_ss_SSS = new SimpleDateFormat("yyyy/dd/MM HH:mm:ss.SSS");
	/* / */SimpleDateFormat slash_yyyy_dd_MM_HH_mm_ss_SSSZ = new SimpleDateFormat("yyyy/dd/MMy HH:mm:ss.SSSZ");
	/* / */SimpleDateFormat slash_yyyy_dd_MM_T_HH_mm_ss_SS = new SimpleDateFormat("yyyy/dd/MM'T'HH:mm:ss.SS");
	/* / */SimpleDateFormat slash_yyyy_dd_MM_T_HH_mm_ss_SSS = new SimpleDateFormat("yyyy/dd/MM'T'HH:mm:ss.SSS");
	/* / */SimpleDateFormat slash_yyyy_dd_MM_T_HH_mm_ss_SSSZ = new SimpleDateFormat("yyyy/dd/MM'T'HH:mm:ss.SSSZ");
	/* / */SimpleDateFormat slash_yyyy_dd_MM_T_HH_mm_ss_SSSXXX = new SimpleDateFormat("yyyy/dd/MM'T'HH:mm:ss.SSSXXX");


//============================= / slash 1 seprator ==========================================================

	/* / */SimpleDateFormat Slash_dd_MM_yy = new SimpleDateFormat("dd/MM/yy");
	/* / */SimpleDateFormat Slash_dd_MM_yy_HH = new SimpleDateFormat("dd/MM/yy HH");
	/* / */SimpleDateFormat Slash_dd_MM_yy_HH_mm = new SimpleDateFormat("dd/MM/yy HH:mm");
	/* / */SimpleDateFormat Slash_dd_MM_yy_HH_mm_ss = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
	/* / */SimpleDateFormat Slash_dd_MM_yy_HH_mm_ss_a = new SimpleDateFormat("dd/MM/yy HH:mm:ss a");
	/* / */SimpleDateFormat Slash_dd_MM_yy_HH_mm_ss_SS = new SimpleDateFormat("dd/MM/yy HH:mm:ss.SS");
	/* / */SimpleDateFormat Slash_dd_MM_yy_HH_mm_ss_SSS = new SimpleDateFormat("dd/MM/yy HH:mm:ss.SSS");
	/* / */SimpleDateFormat Slash_dd_MM_yy_HH_mm_ss_SSSZ = new SimpleDateFormat("dd/MM/yy HH:mm:ss.SSSZ");
	/* / */SimpleDateFormat Slash_dd_MM_yy_T_HH_mm_ss_SS = new SimpleDateFormat("dd/MM/yy'T'HH:mm:ss.SS");
	/* / */SimpleDateFormat Slash_dd_MM_yy_T_HH_mm_ss_SSS = new SimpleDateFormat("dd/MM/yy'T'HH:mm:ss.SSS");
	/* / */SimpleDateFormat Slash_dd_MM_yy_T_HH_mm_ss_SSSZ = new SimpleDateFormat("dd/MM/yy'T'HH:mm:ss.SSSZ");
	/* / */SimpleDateFormat Slash_dd_MM_yy_T_HH_mm_ss_SSSXXX = new SimpleDateFormat("dd/MM/yy'T'HH:mm:ss.SSSXXX");

	/* / */SimpleDateFormat Slash_MM_dd_yy = new SimpleDateFormat("MM/dd/yy");
	/* / */SimpleDateFormat Slash_MM_dd_yy_HH = new SimpleDateFormat("MM/dd/yy HH");
	/* / */SimpleDateFormat Slash_MM_dd_yy_HH_mm = new SimpleDateFormat("MM/dd/yy HH:mm");
	/* / */SimpleDateFormat Slash_MM_dd_yy_HH_mm_ss = new SimpleDateFormat("MM/dd/yy HH:mm:ss");
	/* / */SimpleDateFormat Slash_MM_dd_yy_HH_mm_ss_a = new SimpleDateFormat("MM/dd/yy HH:mm:ss a");
	/* / */SimpleDateFormat Slash_MM_dd_yy_HH_mm_ss_SS = new SimpleDateFormat("MM/dd/yy HH:mm:ss.SS");
	/* / */SimpleDateFormat Slash_MM_dd_yy_HH_mm_ss_SSS = new SimpleDateFormat("MM/dd/yy HH:mm:ss.SSS");
	/* / */SimpleDateFormat Slash_MM_dd_yy_HH_mm_ss_SSSZ = new SimpleDateFormat("MM/dd/yy HH:mm:ss.SSSZ");
	/* / */SimpleDateFormat Slash_MM_dd_yy_T_HH_mm_ss_SS = new SimpleDateFormat("MM/dd/yy'T'HH:mm:ss.SS");
	/* / */SimpleDateFormat Slash_MM_dd_yy_T_HH_mm_ss_SSS = new SimpleDateFormat("MM/dd/yy'T'HH:mm:ss.SSS");
	/* / */SimpleDateFormat Slash_MM_dd_yy_T_HH_mm_ss_SSSZ = new SimpleDateFormat("MM/dd/yy'T'HH:mm:ss.SSSZ");
	/* / */SimpleDateFormat Slash_MM_dd_yy_T_HH_mm_ss_SSSXXX = new SimpleDateFormat("MM/dd/yy'T'HH:mm:ss.SSSXXX");

	/* / */SimpleDateFormat slash_yy_MM_dd = new SimpleDateFormat("yy/MM/dd");
	/* / */SimpleDateFormat slash_yy_MM_dd_HH = new SimpleDateFormat("yy/MM/dd HH");
	/* / */SimpleDateFormat slash_yy_MM_dd_HH_mm = new SimpleDateFormat("yy/MM/dd HH:mm");
	/* / */SimpleDateFormat slash_yy_MM_dd_HH_mm_ss = new SimpleDateFormat("yy/MM/dd HH:mm:ss");
	/* / */SimpleDateFormat slash_yy_MM_dd_HH_mm_ss_a = new SimpleDateFormat("yy/MM/dd HH:mm:ss a");
	/* / */SimpleDateFormat slash_yy_MM_dd_HH_mm_ss_SS = new SimpleDateFormat("yy/MM/dd HH:mm:ss.SS");
	/* / */SimpleDateFormat slash_yy_MM_dd_HH_mm_ss_SSS = new SimpleDateFormat("yy/MM/dd HH:mm:ss.SSS");
	/* / */SimpleDateFormat slash_yy_MM_dd_HH_mm_ss_SSSZ = new SimpleDateFormat("yy/MM/ddy HH:mm:ss.SSSZ");
	/* / */SimpleDateFormat slash_yy_MM_dd_T_HH_mm_ss_SS = new SimpleDateFormat("yy/MM/dd'T'HH:mm:ss.SS");
	/* / */SimpleDateFormat slash_yy_MM_dd_T_HH_mm_ss_SSS = new SimpleDateFormat("yy/MM/dd'T'HH:mm:ss.SSS");
	/* / */SimpleDateFormat slash_yy_MM_dd_T_HH_mm_ss_SSSZ = new SimpleDateFormat("yy/MM/dd'T'HH:mm:ss.SSSZ");
	/* / */SimpleDateFormat slash_yy_MM_dd_T_HH_mm_ss_SSSXXX = new SimpleDateFormat("yy/MM/dd'T'HH:mm:ss.SSSXXX");

	/* / */SimpleDateFormat slash_yy_dd_MM = new SimpleDateFormat("yy/dd/MM");
	/* / */SimpleDateFormat slash_yy_dd_MM_HH = new SimpleDateFormat("yy/dd/MM HH");
	/* / */SimpleDateFormat slash_yy_dd_MM_HH_mm = new SimpleDateFormat("yy/dd/MM HH:mm");
	/* / */SimpleDateFormat slash_yy_dd_MM_HH_mm_ss = new SimpleDateFormat("yy/dd/MM HH:mm:ss");
	/* / */SimpleDateFormat slash_yy_dd_MM_HH_mm_ss_a = new SimpleDateFormat("yy/dd/MM HH:mm:ss a");
	/* / */SimpleDateFormat slash_yy_dd_MM_HH_mm_ss_SS = new SimpleDateFormat("yy/dd/MM HH:mm:ss.SS");
	/* / */SimpleDateFormat slash_yy_dd_MM_HH_mm_ss_SSS = new SimpleDateFormat("yy/dd/MM HH:mm:ss.SSS");
	/* / */SimpleDateFormat slash_yy_dd_MM_HH_mm_ss_SSSZ = new SimpleDateFormat("yy/dd/MMy HH:mm:ss.SSSZ");
	/* / */SimpleDateFormat slash_yy_dd_MM_T_HH_mm_ss_SS = new SimpleDateFormat("yy/dd/MM'T'HH:mm:ss.SS");
	/* / */SimpleDateFormat slash_yy_dd_MM_T_HH_mm_ss_SSS = new SimpleDateFormat("yy/dd/MM'T'HH:mm:ss.SSS");
	/* / */SimpleDateFormat slash_yy_dd_MM_T_HH_mm_ss_SSSZ = new SimpleDateFormat("yy/dd/MM'T'HH:mm:ss.SSSZ");
	/* / */SimpleDateFormat slash_yy_dd_MM_T_HH_mm_ss_SSSXXX = new SimpleDateFormat("yy/dd/MM'T'HH:mm:ss.SSSXXX");


	/*-*/SimpleDateFormat dayname_month_dd_yyyy_hh = new SimpleDateFormat("EEEE, MMMM dd, yyyy h:mm:ss aa zzz");//Thursday, July 27, 2006 10:10:02 PM PST
	/*-*/SimpleDateFormat day_mon_dd_yy = new SimpleDateFormat("EEE, MMM dd, ''yy");//Wed, Jul 04, '01
	/*-*/SimpleDateFormat day_mon_dd_yyyy = new SimpleDateFormat("EEE, MMM dd, ''yyyy");//Wed, Jul 04, '01
	/* Space */SimpleDateFormat MM_c_dd_yyyy = new SimpleDateFormat("MM, dd yyyy");
	/*Space*/SimpleDateFormat EEEEE_dd_MMMM_yyyy = new SimpleDateFormat("EEEEE, dd MMMM yyyy");
	/* SPACE */SimpleDateFormat EEEEE_MMMMM_yyyy_HH_mm_ss_SSSZ = new SimpleDateFormat("EEEEE MMMMM yyyy HH:mm:ss.SSSZ");



	/*-*/SimpleDateFormat dd_MM_yyyy_hh = new SimpleDateFormat("dd-MM-yyyy hh");
	/*-*/SimpleDateFormat dd_MM_yyyy_hh_mm = new SimpleDateFormat("dd-MM-yyyy hh:mm");
	/*-*/SimpleDateFormat dd_MM_yyyy_hh_mm_ss = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss");
	/*-*/SimpleDateFormat dd_MM_yyyy_hh_mm_ss_a = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss a");


	SimpleDateFormat S_dd_MM_yyyy_hh = new SimpleDateFormat("dd/MM/yyyy hh");
	SimpleDateFormat S_dd_MM_yyyy_hh_mm = new SimpleDateFormat("dd/MM/yyyy hh:mm");
	SimpleDateFormat S_dd_MM_yyyy_hh_mm_ss = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
	SimpleDateFormat S_dd_MM_yyyy_hh_mm_ss_a = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss a");

	SimpleDateFormat S_dd_MM_yy = new SimpleDateFormat("dd/MM/yy");
	SimpleDateFormat S_dd_MM_yy_hh = new SimpleDateFormat("dd/MM/yy hh");
	SimpleDateFormat S_dd_MM_yy_hh_mm = new SimpleDateFormat("dd/MM/yy hh:mm");
	SimpleDateFormat S_dd_MM_yy_hh_mm_ss = new SimpleDateFormat("dd/MM/yy hh:mm:ss");
	SimpleDateFormat S_dd_MM_yy_hh_mm_ss_a = new SimpleDateFormat("dd/MM/yy hh:mm:ss a");



	SimpleDateFormat dd_MM_yyyy_hh_mm_ssS = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss.SSS");
	SimpleDateFormat dd_MM_yyyy_hh_mm_ssS_Z = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss.SSSZ");
	SimpleDateFormat S_dd_MM_yyyy_hh_mm_ssS = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss.SSS");
	SimpleDateFormat S_dd_MM_yyyy_hh_mm_ssS_Z = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss.SSSZ");
	SimpleDateFormat dd_MM_yyyy_T_hh_mm_ssS_Z = new SimpleDateFormat("dd-MM-yyyy'T'hh:mm:ss.SSSXXX");
	SimpleDateFormat S_dd_MM_yyyy_T_hh_mm_ssS_Z = new SimpleDateFormat("dd/MM/yyyy'T'hh:mm:ss.SSSXXX");
	SimpleDateFormat HH_mm_ss = new SimpleDateFormat("HH:mm:ss");


	// dd-MM-yyyy
	String dd_MM_yyyy_regex = "([0-9]{1,2}\\-[0-9]{1,2}\\-[1-9]{1}[0-9]{3,3})";
	// dd-MM-yyyy HH:mm
	String dd_MM_yyyy_HH_mm_regex = "([0-9]{1,2}\\-[0-9]{1,2}\\-[1-9]{1}[0-9]{3,3}\\s+[0-9]{2,2}\\:[0-9]{2,2})";
	// dd-MM-yyyy HH:mm:ss
	String dd_MM_yyyy_HH_mm_ss_regex ="([0-9]{1,2}\\-[0-9]{1,2}\\-[1-9]{1}[0-9]{3,3}\\s+[0-9]{2,2}\\:[0-9]{2,2}\\:[0-9]{1,2})";
	// dd-MM-yyyy HH:mm:ss a
	String dd_MM_yyyy_HH_mm_ss_a_regex = "([0-9]{1,2}\\-[0]{1}[0-9]{1,2}\\-[1-9]{1}[0-9]{3,3}\\s+[0-9]{2,2}\\:[0-9]{2,2}\\:[0-9]{1,2}\\s[amAM|pmPM]{2,2})$";
	// dd-MM-yyyy hh:mm
	String dd_MM_yyyy_hh_mm_regex = "([0-9]{1,2}\\-[0-9]{1,2}\\-[1-9]{1}[0-9]{3,3}\\s+[0-9]{2,2}\\:[0-9]{2,2})";
	// dd-MM-yyyy hh:mm:ss
	String dd_MM_yyyy_hh_mm_ss_regex = "([0-9]{1,2}\\-[0-9]{1,2}\\-[1-9]{1}[0-9]{3,3}\\s+[0-9]{2,2}\\:[0-9]{2,2}\\:[0-9]{1,2})";
	// dd-MM-yyyy hh:mm:ss a
	String dd_MM_yyyy_hh_mm_ss_a_regex = "([0-9]{1,2}\\-[0-9]{1,2}\\-[1-9]{1}[0-9]{3,3}\\s+[0-9]{2,2}\\:[0-9]{2,2}\\:[0-9]{1,2}\\s[amAM|pmPM]{2,2})$";
	// dd/MM/yyyy
	String S_dd_MM_yyyy_regex = "";
	// dd/MM/yyyy HH:mm
	String S_dd_MM_yyyy_HH_mm_regex = "";
	// dd/MM/yyyy HH:mm:ss
	String S_dd_MM_yyyy_HH_mm_ss_regex = "";
	// dd/MM/yyyy HH:mm:ss am pm
	String S_dd_MM_yyyy_HH_mm_ss_a_regex = "";
	// dd/MM/yyyy hh:mm
	String S_dd_MM_yyyy_hh_mm_regex = "";
	// dd/MM/yyyy hh:mm:ss
	String S_dd_MM_yyyy_hh_mm_ss_regex = "";
	// dd/MM/yyyy hh:mm:ss am pm
	String S_dd_MM_yyyy_hh_mm_ss_a_regex = "";
	// dd/MM/yyyy hh:mm
	String S_MM_dd_yyyy_regex = "";
	String S_yyyy_dd_MM_regex = "";
	String S_yy_MM_dd_HH_mm_ss_regex = "";
	String S_dd_MM_yy_hh_mm_ss_regex = "";
	String MM_c_ff_yyyy_regex = "";
	String dd_MM_yyyy_hh_mm_ssS_regex = "";
	String dd_MM_yyyy_hh_mm_ssS_Z_regex = "";
	String EEEEE_dd_MMMM_yyyy_regex = "";
	String S_dd_MM_yyyy_hh_mm_ssS_regex = "";
	String S_dd_MM_yyyy_hh_mm_ssS_Z_regex = "";
	String dd_MM_yyyy_T_hh_mm_ssS_Z_regex = "";
	String S_dd_MM_yyyy_T_hh_mm_ssS_Z_regex = "";
	String HH_mm_ss_regex = "";
	// MM-dd-yyyy
	String MM_dd_yyyy_regex ="";
	// yyyy-dd-MM
	String yyyy_dd_MM_regex = "";





}
