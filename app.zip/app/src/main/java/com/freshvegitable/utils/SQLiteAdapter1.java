package com.freshvegitable.utils;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;


import com.freshvegitable.Wrappers.Data;
import com.freshvegitable.Wrappers.DataHolder;

import org.apache.commons.lang3.StringUtils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Vector;
import java.util.regex.Pattern;

/*import net.sqlcipher.Cursor;
import net.sqlcipher.database.SQLiteDatabase;
import net.sqlcipher.database.SQLiteFullException;
import net.sqlcipher.database.SQLiteOpenHelper;*/

/**
 * Created by Dell on 13-10-2015.
 */
public class SQLiteAdapter1
{
    public static String MYDATABASE_NAME = "CRG.db";
    public static final int MYDATABASE_VERSION = Constant.SQLITE_VERSION;

    public static final String MARKET_NEWS_TB = "market_news_tb";
    private static String market_news_tb = "create table " + MARKET_NEWS_TB + "(id text,title text,type text,date text,flagged text)";

    public static final String MARKET_NEWS_DATA_TB = "market_news_data_tb";
    private static String market_news_data_tb = "create table " + MARKET_NEWS_DATA_TB + "(id text,title text,msg text,date text,name text)";

    public static final String FLAGGED_TB = "flagged_tb";
    private static String flagged_tb = "create table " + FLAGGED_TB + "(id text,title text,type text,date text)";

    public static final String OPPORTUNITY_TB = "opportunity_tb";
    private static String opportunity_tb = "create table " + OPPORTUNITY_TB + "(Name text,OpportunityType text,AccountID text,OppOwnerID text,AssignTo text,YourPrice text,CurrentStageID text, OPPStatusCodeID text,ProductCategoryID text, OppProductID text,HtmlText_81 text,InternalSLA text, HtmlText_83 text, Opp_ex1_2 text, Opp_ex1_56 text, Opp_ex1_49 text, Opp_ex1_26 text, CurrencyID text, ROWNUMBER text, Key text, AccountKey text, CurrencyKey text,LayoutID text)";

    public static final String CUSTOMER_DETAILS_TB = "customer_tb";
    private static String customer_tb = "create table " + CUSTOMER_DETAILS_TB + "(customerid text,CUSTNAME text,CDAB text,CMS_THROUGHPUT text,TOTAL_CMSTRANS text,TOTAL_LIMIT text,TOTAL_UTILIZATION text, UTILIZATION_PERCENTAGE text,TOTAL_BG text, FOREX_TURNOVER text,EXCHANGEINCOME text,ACCOUNT_ID text, Details text, flagged text,territory_opp text,products text,customer_ppc text,bestinclass_ppc text,Meeting_Count text)";

    public static final String PORTFOLIO_TB = "portfolio_tb";
    private static String portfolio_tb = "create table " + PORTFOLIO_TB + "(id text,rm_id text,cust_id text,cust_name text,trigger_desc text,expiry_date text,flagged text)";

    public static final String TASK_MANAGER_TB = "task_manager_tb";
    private static String task_manager_tb = "create table " + TASK_MANAGER_TB + "(id text, emp_id text, task text, t_date text, t_time text, priority text)";

    public static final String DASHBOARD_TB = "dashboard_tb";
    private static String dashboard_tb = "create table "+DASHBOARD_TB+"(RM_ID text,RM_NAME text, Segment text,  PPC text, B_NII text,B_PROCESSING_FEE text,B_SYNDICATION_FEE text,B_LC text,B_BG text,B_FOREX_AND_DERIVATIVES text," +
            "B_EXCHANGE text,B_COMMISSION text,B_DERIVATIVES text,B_GFID text,B_IB_INCOME text,B_DCM_INCOME text,B_CA_CDAB text,B_SALARY_CDAB text,B_NO_OF_SALARY_ACCOUNTS text," +
            "AYTD_TOTAL_NII text,AYTD_NII_TL text,AYTD_NII_WC text,AYTD_NII_OTHERS text,AYTD_TOTAL_FEES text,AYTD_LC text,AYTD_BG text,AYTD_PROCESSING_FEES text,AYTD_SYNDICATION text,AYTD_FOREX_AND_DERIVATIVES text,AYTD_EXCHANGE text," +
            "AYTD_COMMISSION text,AYTD_DERIVATIVES text,AYTD_GFID text,AYTD_DCM text,AYTD_IB_INCOME text,BAR_NII text,BAR_PROC_AND_SYNDICATION_FEES text,BAR_LC_AND_BG_FEES text,BAR_FOREX_AND_DERIVATIVES text,BAR_IB_AND_DCM_INCOME text,BAR_CA_CDAB text,BAR_SALARY_CDAB text,ADV_TOTAL text,ADV_A_MINUS_AND_ABOVE text,ADV_BBB_PLUS text," +
            "ADV_BBB_AND_BELOW text,ADV_NON_RATED text,CA_CDAB text,SALARY_CDAB text,NO_OF_NEW_SALARY_ACCTS text,NO_OF_MAPPED_CUSTOMERS text,CNT_OF_CUST_GRTR15_RAROC text,PIPELINE text, LAST_UPDATED text,axis_crg_tb_1 text,axis_crg_tb_2 text,axis_crg_tb_3 text,axis_crg_tb_4 text,axis_crg_tb_5 text,axis_crg_tb_6 text,axis_crg_tb_7 text," +
            "axis_crg_tb_8 text,axis_crg_tb_9 text,axis_crg_tb_10 text,axis_crg_tb_11 text,axis_crg_tb_12 text,axis_crg_tb_13 text,axis_crg_tb_14 text,axis_crg_tb_15 text)";

    public static final String CUSTOMER360_TB = "customer360_tb";
    private static String customer360_tb = "create table " + CUSTOMER360_TB + "(CUSTOMER_ID text,ACCOUNT_ID text,CUST_NAME text," +
            "TERRIOTRY text,NII text,FEE text,TREASURY text,CA_CDAB text,Salary_CDAB text,AP_IB_INCOME text,Rating text," +
            "SMA_Status text, PPC text,Forex_Derivates text,INCOME_BALANCE_ text," + "ACCOUNT_PLANNING_ text,LIMIT_UTILIZATION text," +
            "axis_crg_tb_1 text,axis_crg_tb_2 text,axis_crg_tb_3 text,axis_crg_tb_4 text,axis_crg_tb_5 text,axis_crg_tb_6 text,axis_crg_tb_7 text,axis_crg_tb_8 text,axis_crg_tb_9 text,axis_crg_tb_10 text,axis_crg_tb_11 text,axis_crg_tb_12 text,axis_crg_tb_13 text,axis_crg_tb_14 text,axis_crg_tb_15 text,assigned_to_opp text , extracolumn1 text ,extracolumn2 text , extracolumn3 text)";

    public static final String CUSTOMER360_GROUP_TB = "customer360_group_tb";
    private static String customer360_group_tb = "create table " + CUSTOMER360_GROUP_TB + "(CUSTOMER_ID text,ACCOUNT_ID text,CUST_NAME text," +
            "TERRIOTRY text,NII text,FEE text,TREASURY text,CA_CDAB text,Salary_CDAB text,AP_IB_INCOME text,Rating text," +
            "SMA_Status text, PPC text,Forex_Derivates text,INCOME_BALANCE_ text," + "ACCOUNT_PLANNING_ text,LIMIT_UTILIZATION text," +
            "axis_crg_tb_1 text,axis_crg_tb_2 text,axis_crg_tb_3 text,axis_crg_tb_4 text,axis_crg_tb_5 text,axis_crg_tb_6 text,axis_crg_tb_7 text,axis_crg_tb_8 text,axis_crg_tb_9 text,axis_crg_tb_10 text,axis_crg_tb_11 text,axis_crg_tb_12 text,axis_crg_tb_13 text,axis_crg_tb_14 text,axis_crg_tb_15 text,assigned_to_opp text , extracolumn1 text ,extracolumn2 text , extracolumn3 text)";


    public static final String CUSTOMER_GROUP_TB = "customer_group_tb";
    private static String customer_group_tb = "create table " + CUSTOMER_GROUP_TB + "(CUSTOMER_ID text,ACCOUNT_ID text,CUST_NAME text," +
            "TERRIOTRY text,NII text,FEE text,TREASURY text,CA_CDAB text,Salary_CDAB text,AP_IB_INCOME text,Rating text," +
            "SMA_Status text, PPC text,Forex_Derivates text,INCOME_BALANCE_ text," + "ACCOUNT_PLANNING_ text,LIMIT_UTILIZATION text," +
            "axis_crg_tb_1 text,axis_crg_tb_2 text,axis_crg_tb_3 text,axis_crg_tb_4 text,axis_crg_tb_5 text,axis_crg_tb_6 text,axis_crg_tb_7 text,axis_crg_tb_8 text,axis_crg_tb_9 text,axis_crg_tb_10 text,axis_crg_tb_11 text,axis_crg_tb_12 text,axis_crg_tb_13 text,axis_crg_tb_14 text,axis_crg_tb_15 text,assigned_to_opp text , extracolumn1 text ,extracolumn2 text , extracolumn3 text )";

    public static final String REVWR_DASHBOARD_TB = "revwr_dashboard_tb";
    private static String revwr_dashboard_tb = "create table "+REVWR_DASHBOARD_TB+"(SRM_ID text,LoginID text, SAAdded text,  TotalCust text, Raroc text,A_Minus_Above text,BBB_Plus text,BBB_Below text,NoN_Rated text,Products text,PIPELINE text, LAST_UPDATED text,NetAdvances text,axis_crg_tb_1 text,axis_crg_tb_2 text,axis_crg_tb_3 text,axis_crg_tb_4 text,axis_crg_tb_5 text,axis_crg_tb_6 text,axis_crg_tb_7 text," +
            "axis_crg_tb_8 text,axis_crg_tb_9 text,axis_crg_tb_10 text,axis_crg_tb_11 text,axis_crg_tb_12 text,axis_crg_tb_13 text,axis_crg_tb_14 text,axis_crg_tb_15 text)";


    public static final String CUSTOMER_TEMP = "customer_temp";
    private static String customer_temp = "create table " + CUSTOMER_TEMP + "(CUSTOMER_ID text, CUST_NAME text, ACCOUNTKEY text, TERRORITYKEY text, AXIS_CRG_EX_1 text)";

    public static final String LIMITS_UTILIZATION_TB = "limits_utilization_tb";
    private static String limits_utilization_tb = "create table "+LIMITS_UTILIZATION_TB+" (ID text, CUSTOMER_ID1 text, CUST_NAME text, LEVELNO text, RANK text, PARENT_SUFFIX text, CHILD_SUFFIX text, LIMIT_SANCTIONED text, OUTSTANDING text, AVAILABLE_LIMIT text, FUNGIBILITY text, FACILITY text)";

    public static final String MARKET_RSS_TB = "market_rss_tb";
    private static String market_rss_tb = "create table "+MARKET_RSS_TB+"(UID text, TITLE text, DESC text, LINK text, DATE DATETIME, TYPE text)";

    public static final String PROSPECT_TB = "prospect_tb";
    private static String prospect_tb = "create table "+PROSPECT_TB+"(AccountID text, Name text, LoginID text, UserName text, axis_crg_col1 text, axis_crg_col2 text, axis_crg_col3 text, axis_crg_col4 text, axis_crg_col5 text, axis_crg_col6 text, axis_crg_col7 text, axis_crg_col8 text, axis_crg_col9 text, axis_crg_col10 text)";

    public static final String REVIEWER_TB = "reviewer_tb";
    private static String reviewer_tb = "create table "+REVIEWER_TB+"(LoginID text, Name text, Segment text, Region text, RoleName text, Parent text, axis_crg_col1 text, axis_crg_col2 text, axis_crg_col3 text, axis_crg_col4 text, axis_crg_col5 text, axis_crg_col6 text, axis_crg_col7 text, axis_crg_col8 text, axis_crg_col9 text, axis_crg_col10 text)";

    public static final String CONTACTS_TB = "contacts_tb";
    String contacts_tb = "create table "+CONTACTS_TB+"(LoginID text, EmpName text, Function text, Contact text, AttachBranch text, PostedBranch text, EmailID text, axiscrg_tb_1 text, axiscrg_tb_2 text, axiscrg_tb_3 text, axiscrg_tb_4 text, axiscrg_tb_5 text, axiscrg_tb_6 text, axiscrg_tb_7 text, axiscrg_tb_8 text, axiscrg_tb_9 text, axiscrg_tb_10 text)";

    /*
    "Cust_ID": "006114435",
    "CustName": "JAKHAU SALT COMPANY PVT LTD",
    "Facility": "RUNNING PACKING CREDIT",
    "Amount": "25000000",
    "DPD": "74"
     */
    public static final String IRREGULATY_ACCOUNTS_TB = "irregularities_accounts_tb";
    String irregularities_accounts_tb = "create table "+IRREGULATY_ACCOUNTS_TB+" (OverdueDetails text, PendingSecDetails text, axis_crg_tb_1 text, axis_crg_tb_2 text, axis_crg_tb_3 text, axis_crg_tb_4 text, axis_crg_tb_5 text, axis_crg_tb_6 text, axis_crg_tb_7 text, axis_crg_tb_8 text, axis_crg_tb_9 text, axis_crg_tb_10 text)";

    private SQLiteHelper sqLiteHelper;
    public static SQLiteDatabase sqLiteDatabase;
    private Context context;

    public SQLiteAdapter1(String db_name)
    {
        MYDATABASE_NAME = "" + db_name;
        MYDATABASE_NAME = getDBNameWithVersionNumber(MYDATABASE_NAME, MYDATABASE_VERSION);
    }

    public SQLiteAdapter1(Context cursor)
    {
        context = cursor;
        //SQLiteDatabase.loadLibs(context);
    }

    public SQLiteAdapter1(Context cursor, String db_name)
    {
        context = cursor;
        //SQLiteDatabase.loadLibs(context);
        MYDATABASE_NAME = "" + db_name;
        MYDATABASE_NAME = getDBNameWithVersionNumber(MYDATABASE_NAME, MYDATABASE_VERSION);

    }

    private String getDBNameWithVersionNumber(String db_name, int db_version)
    {
        if (db_name.contains("_"))
        {
            int index_db = db_name.indexOf(".db");
            int index_ = db_name.indexOf("_");
            String version = db_name.substring(index_, index_db).replace("_", "");
            if (version.equalsIgnoreCase("" + db_version))
            {
                return db_name;
            }
            else if (Integer.parseInt(version) < db_version)
            {
                return db_name.replace("_" + version + ".db", "_" + db_version + ".db");
            }
            else
            {
                int index = db_name.indexOf(".db");
                return "" + db_name.substring(0, index) + "_" + db_version + ".db";
            }
        }
        else
        {
            int index = db_name.indexOf(".db");
            return "" + db_name.substring(0, index) + "_" + db_version + ".db";
        }
    }

    public boolean isDbOpen()
    {
        try
        {
            return sqLiteDatabase.isOpen();
        }
        catch (Exception e)
        {
            return false;
        }
    }

  /*  public SQLiteAdapter openToRead() throws SQLiteFullException
    {
        sqLiteHelper = new SQLiteHelper(context, MYDATABASE_NAME, null, MYDATABASE_VERSION);

        sqLiteDatabase = sqLiteHelper.getReadableDatabase("password");
        return this;
    }
    public SQLiteDatabase getReadable() throws SQLiteFullException
    {
        sqLiteHelper = new SQLiteHelper(context, MYDATABASE_NAME, null, MYDATABASE_VERSION);

        sqLiteDatabase = sqLiteHelper.getReadableDatabase("password");
        return sqLiteDatabase;
    }
    public SQLiteAdapter openToWrite() throws SQLiteFullException
    {
        sqLiteHelper = new SQLiteHelper(context, MYDATABASE_NAME, null, MYDATABASE_VERSION);

        sqLiteDatabase = sqLiteHelper.getWritableDatabase("password");
        return this;
    }*/


    public SQLiteAdapter1 openToRead() throws android.database.SQLException
    {
        sqLiteHelper = new SQLiteHelper(context, MYDATABASE_NAME, null, 1);
        sqLiteDatabase = sqLiteHelper.getReadableDatabase();
        return this;
    }

    public SQLiteDatabase getReadable() throws android.database.SQLException
    {
        sqLiteHelper = new SQLiteHelper(context, MYDATABASE_NAME, null, 1);
        sqLiteDatabase = sqLiteHelper.getReadableDatabase();
        return sqLiteDatabase;
    }

    public SQLiteAdapter1 openToWrite() throws android.database.SQLException
    {
        sqLiteHelper = new SQLiteHelper(context, MYDATABASE_NAME, null, 1);
        sqLiteDatabase = sqLiteHelper.getWritableDatabase();
        return this;
    }



    public void close()
    {
        sqLiteHelper.close();
    }

    public long insertData(String tablename, ContentValues contentvalue)
    {
        return sqLiteDatabase.insert(tablename, null, contentvalue);
    }

    public long updateData(String tablename, ContentValues contentvalue, String where, String whereArgs[])
    {
        return sqLiteDatabase.update(tablename, contentvalue, where, whereArgs);
    }

    public Cursor executeRawQuery(String pQuery)
    {
        Log.i(Constant.TAG, "executeRawQuery : " + pQuery);
        return sqLiteDatabase.rawQuery(pQuery, null);
    }

    public void deleteTable(String table)
    {
        sqLiteDatabase.delete(table, null, null);
    }

    public int delete_Customers_IF_NOT_EXISTS(String tablename, String values)
    {
        String query = "delete from " + tablename + " where customerid not in (" + values + ")";
        Cursor cursor = sqLiteDatabase.rawQuery(query, null);
        int count = cursor.getCount();
        if (!cursor.isClosed())
        {
            cursor.close();
        }
        return count;
    }

    public int deleteTaskManagerRecord(String id)
    {
        try
        {
            String query = "delete from task_manager_tb where id="+id;
            Cursor cursor = sqLiteDatabase.rawQuery(query, null);
            int count = cursor.getCount();
            if (!cursor.isClosed())
            {
                cursor.close();
            }
            return count;
        }
        catch (Exception e)
        {
            Log.e(Constant.TAG_SQLITE, "Caught exception", e);
            return 0;
        }
    }

    public int delete_Customers_IF_NOT_EXISTS_for_temptable(String tablename, String values)
    {
        String query = "delete from " + tablename + " where CUSTOMER_ID not in (" + values + ")";
        Log.i(Constant.TAG, "DELETE CUSTOMERS QUERY for_temptable [" + query + "]");
        Cursor cursor = sqLiteDatabase.rawQuery(query, null);
        int count = cursor.getCount();
        if (!cursor.isClosed())
        {
            cursor.close();
        }
        return count;
    }

    public int delete_Customers_IF_NOT_EXISTS_for_temptable_limit(String tablename, String values)
    {
        String query = "delete from " + tablename + " where ID not in (" + values + ")";
        Cursor cursor = sqLiteDatabase.rawQuery(query, null);
        int count = cursor.getCount();
        if (!cursor.isClosed())
        {
            cursor.close();
        }
        return count;
    }

    public int delete_Customers_IF_NOT_EXISTS_for_prospectable(String tablename, String values)
    {
        String query = "delete from " + tablename + " where AccountID not in (" + values + ")";
        Log.i("CUSTOMER", "DELETE CUSTOMERS QUERY for_temptable [" + query + "]");
        Cursor cursor = sqLiteDatabase.rawQuery(query, null);
        int count = cursor.getCount();
        if (!cursor.isClosed())
        {
            cursor.close();
        }
        return count;
    }

    public int delete_Customers_IF_NOT_EXISTS_for_ContactDetails(String tablename, String values)
    {
        String query = "delete from " + tablename + " where LoginID not in (" + values + ")";
        Cursor cursor = sqLiteDatabase.rawQuery(query, null);
        int count = cursor.getCount();
        if (!cursor.isClosed())
        {
            cursor.close();
        }
        return count;
    }

    public int delete_UID_IF_NOT_EXISTS_for_temptable(String tablename, String values)
    {
        String query = "delete from " + tablename + " where UID not in (" + values + ")";
        Cursor cursor = sqLiteDatabase.rawQuery(query, null);
        int count = cursor.getCount();
        if (!cursor.isClosed())
        {
            cursor.close();
        }
        return count;
    }

    public int delete_Task_IF_NOT_EXISTS(String tablename, String values)
    {
        String query = "delete from " + tablename + " where id not in (" + values + ")";
        Cursor cursor = sqLiteDatabase.rawQuery(query, null);
        int count = cursor.getCount();
        if (!cursor.isClosed())
        {
            cursor.close();
        }
        return count;
    }

    public int delete_records_which_doesnt_exists(String tablename, String column, String values)
    {
        String query = "delete from " + tablename + " where "+column+" not in (" + values + ")";
        Cursor cursor = sqLiteDatabase.rawQuery(query, null);
        int count = cursor.getCount();
        if (!cursor.isClosed())
        {
            cursor.close();
        }
        return count;
    }


    /**
     * This will check if values of particular id exists in the database.
     *
     * @param fieldValue - The value to check for existence
     */
    public boolean CheckIfDataAlreadyExistsInDBorNot(String TableName, String columnName, String fieldValue)
    {
        String Query = "Select * from " + TableName + " where " + columnName + " = '" + fieldValue + "'";
        Log.i(Constant.TAG_SQLITE, "Query : "+Query);
        Cursor cursor = sqLiteDatabase.rawQuery(Query, null);
        if (cursor.moveToFirst())
        {
            if (cursor.getCount() <= 0)
            {
                if (!cursor.isClosed())
                {
                    cursor.close();
                }
                return false;
            }
        }
        else
        {
            if (!cursor.isClosed())
            {
                cursor.close();
            }
            return false;
        }
        if (!cursor.isClosed())
        {
            cursor.close();
        }
        return true;
    }

    public boolean CheckIdDataAlreadyExistsInDbOrNot(String column1, String column2, String text1, String text2)
    {
        String Query = "Select * from customer360_tb where " + column1 + " = '" + text1 + "' and "+column2+" = '"+text2+"'";
        Log.i(Constant.TAG_SQLITE, "Query : "+Query);
        Cursor cursor = sqLiteDatabase.rawQuery(Query, null);
        if (cursor.moveToFirst())
        {
            if (cursor.getCount() <= 0)
            {
                if (!cursor.isClosed())
                {
                    cursor.close();
                }
                return false;
            }
        }
        else
        {
            if (!cursor.isClosed())
            {
                cursor.close();
            }
            return false;
        }
        if (!cursor.isClosed())
        {
            cursor.close();
        }
        return true;
    }

    public boolean CheckIfDataAlreadyExistsInDBorNot_1(String TableName, String columnName, String fieldValue)
    {
        String Query = "Select * from " + TableName + " where " + columnName + " = '" + fieldValue + "'";
        Log.i(Constant.TAG_SQLITE, "SQlite Query : "+Query);
        Cursor cursor = sqLiteDatabase.rawQuery(Query, null);
        if (cursor.moveToFirst())
        {
            if (cursor.getCount() <= 0)
            {
                if (!cursor.isClosed())
                {
                    cursor.close();
                }
                return false;
            }
        }
        else
        {
            if (!cursor.isClosed())
            {
                cursor.close();
            }
            return false;
        }
        if (!cursor.isClosed())
        {
            cursor.close();
        }
        return true;
    }

    public static String flagged_val1 = "";
    public static String flagged_val2 = "";


    public boolean Check_Id_Exists(String tablename, String ids)
    {
        String Query = "Select * from " + tablename + " where id = '" + ids + "'";
        Cursor cursor = sqLiteDatabase.rawQuery(Query, null);

        if (cursor.moveToFirst())
        {
            if (cursor.getCount() <= 0)
            {
                if (cursor != null && !cursor.isClosed())
                {
                    cursor.close();
                }

                return false;
            }
            else
            {
                flagged_val1 = cursor.getString(4);
                if (cursor != null && !cursor.isClosed()) {
                    cursor.close();
                }
            }
        }
        else {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            return false;
        }

        if (cursor != null && !cursor.isClosed()) {
            cursor.close();
        }

        return true;
    }

    public boolean Check_Id_Exists1(String tablename, String ids)
    {

        String Query = "Select * from " + tablename + " where id = '" + ids + "'";
        Cursor cursor = sqLiteDatabase.rawQuery(Query, null);

        if (cursor.moveToFirst()) {
            if (cursor.getCount() <= 0) {
                if (cursor != null && !cursor.isClosed()) {
                    cursor.close();
                }

                return false;
            }
            else {
                flagged_val2 = cursor.getString(4);

                if (cursor != null && !cursor.isClosed()) {
                    cursor.close();
                }

            }
        }
        else {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }

            return false;
        }

        if (cursor != null && !cursor.isClosed()) {
            cursor.close();
        }
        return true;
    }


    public void remove_flagged_content(String tablename, String id)
    {
        sqLiteDatabase.delete(tablename, "id=" + id, null);
    }

    public void Add_Remove_Favourites(String tablename, String id)
    {
        sqLiteDatabase.delete(tablename, "flagged=" + id, null);
    }

    public Vector<String> getMeetingId()
    {
        Vector<String> meetingid = new Vector<>();
        String Query = "Select " + MEETING_ID + " from " + MEETING_DATA_TB;
        Cursor cursor = sqLiteDatabase.rawQuery(Query, null);
        try
        {
            if (cursor != null && cursor.getCount() != 0)
            {
                while (cursor.moveToNext())
                {
                    meetingid.add(cursor.getString(0));
                }
            }
        }
        catch (Exception e)
        {
            Log.e(Constant.TAG_SQLITE, "Caught exception while returning meeting id's", e);
        }
        finally
        {
            if (cursor != null && !cursor.isClosed())
            {
                cursor.close();
            }
        }
        return meetingid;
    }


    public String getCustAccId(String custid)
    {

        String accid = "";

        String Query = "Select ACCOUNT_ID from " + CUSTOMER_DETAILS_TB + " where customerid='" + custid + "'";
        Cursor cursor = sqLiteDatabase.rawQuery(Query, null);

        try {
            if (cursor != null && cursor.getCount() != 0) {
                if (cursor.moveToFirst()) {
                    accid = cursor.getString(0);
                }
            }
        }
        catch (Exception e) {
            System.out.println("Exception lllllllll : " + e);
        }
        finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
        }

        return accid;
    }


    public Vector<String> Retrieve_OnlyIDS(String tablename)
    {

        Vector<String> ids = new Vector<String>();
        ids.removeAllElements();
        String Query = "select id from " + tablename;
        Cursor cursor = sqLiteDatabase.rawQuery(Query, null);
        try {
            if (cursor != null && cursor.getCount() != 0) {
                while (cursor.moveToNext()) {
                    //					if(cursor.getColumnCount()==5)
                    //					{
                    ids.add(cursor.getString(0));
                    //					}
                }
            }
        }
        catch (Exception e) {
            System.out.println("Exception lllllllll : " + e);
        }
        finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
        }

        return ids;
    }


    public Vector<String> getOnlyCustomerNamesFromDb(String tablename, String text, int specific_Filter)
    {
        Vector<String> customer = new Vector<>();
        String Query = "Select * from " + tablename + " where CUST_NAME like '%" + text + "%' ORDER BY CUST_NAME ASC";
        Cursor cursor = sqLiteDatabase.rawQuery(Query, null);

        try
        {
            if (cursor != null && cursor.getCount() != 0)
            {

                if (specific_Filter == 0)
                {
                    while (cursor.moveToNext())
                    {
                        String Cust_Id = cursor.getString(0);

                        Pattern p = Pattern.compile("(^[\\d]*$)");
                        boolean IsNumeric = StringUtils.isNumeric(Cust_Id); // Common Apachie check
                        boolean isNumeric = p.matcher(Cust_Id).find(); //Regex Check
                        //Log.i(Constant.TAG, "IsAlphaNumeric : " + IsNumeric + " " + isNumeric);
                        if (IsNumeric) {

                            customer.add(cursor.getString(2));
                        }
                    }
                }
                else
                {
                    while (cursor.moveToNext())
                    {
                        customer.add(cursor.getString(2));
                    }
                }
            }
        }
        catch (Exception e)
        {
            Log.e(Constant.TAG, "Caught exception in getOnlyCustomerNamesFromDb", e);
        }
        finally
        {
            if (cursor != null && !cursor.isClosed())
            {
                cursor.close();
            }
        }

        return customer;
    }

    public Vector<String> getOnlyCustomerNamesFromDbNTB(String tablename, String text)
    {
        Vector<String> customer = new Vector<>();
        String Query = "Select * from " + tablename + " where Name like '" + text + "%' ORDER BY Name ASC";
        Cursor cursor = sqLiteDatabase.rawQuery(Query, null);

        try
        {
            if (cursor != null && cursor.getCount() != 0)
            {
                while (cursor.moveToNext())
                {
                    customer.add(cursor.getString(1));
                }
            }
        }
        catch (Exception e)
        {
            Log.e(Constant.TAG, "Caught exception in getOnlyCustomerNamesFromDb NTB", e);
        }
        finally
        {
            if (cursor != null && !cursor.isClosed())
            {
                cursor.close();
            }
        }

        return customer;
    }


    public boolean CheckIsDataAlreadyInDBorNot(String TableName, String fieldValue)
    {

        String Query = "Select * from " + TableName + " where id = '" + fieldValue + "'";
        Cursor cursor = sqLiteDatabase.rawQuery(Query, null);
        if (cursor.getCount() <= 0)
        {
            if (!cursor.isClosed())
            {
                cursor.close();
            }
            return false;
        }

        if (!cursor.isClosed())
        {
            cursor.close();
        }

        return true;
    }





    // LEO ; DO NOT MODIFY
    private static int SQLLITE_DATABASE_VERSION = 1;


    // Ends Here..
    public class SQLiteHelper extends SQLiteOpenHelper
    {
        public SQLiteHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version)
        {
            super(context,  Constant.SDCARD_BASEPATH + name, factory, SQLLITE_DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db)
        {
            db.execSQL(market_news_tb);
            db.execSQL(market_news_data_tb);
            db.execSQL(meeting_data_tb);
            db.execSQL(customer_tb);
            db.execSQL(opportunity_tb);
            db.execSQL(flagged_tb);
            db.execSQL(portfolio_tb);
            db.execSQL(task_manager_tb);
            db.execSQL(dashboard_tb);
            db.execSQL(customer360_tb);
            db.execSQL(customer360_group_tb);
            db.execSQL(customer_temp);
            db.execSQL(limits_utilization_tb);
            db.execSQL(market_rss_tb);
            db.execSQL(prospect_tb);
            db.execSQL(reviewer_tb);
            db.execSQL(revwr_dashboard_tb);
            db.execSQL(contacts_tb);
            db.execSQL(customer_group_tb);
            db.execSQL(irregularities_accounts_tb);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
        {
            /*
            switch(oldVersion)
            {
                case 1:
                {
                    // ADD COLUMN FOR CUSTOMER TABLE 19 - FEB - 2016
                    String altertablequery1 = "ALTER TABLE " + CUSTOMER_DETAILS_TB + " ADD COLUMN Assigned_To_Opp TEXT;";
                    String altertablequery2 = "ALTER TABLE " + CUSTOMER_TEMP + " ADD COLUMN Assigned_To_Opp TEXT;";

                    db.execSQL(altertablequery1);
                    db.execSQL(altertablequery2);
                }

                default:
                {
                    // DO NOTHING
                }
            }*/
        }
    }

    public int delete_Table_IF_ID_NOT_IN(String tablename, String values, String date)
    {
        Cursor cursor = sqLiteDatabase.rawQuery("delete from " + tablename + " where ( id not in (" + values + ") and date like '" + date + "%' )", null);
        int count = cursor.getCount();
        if (!cursor.isClosed())
        {
            cursor.close();
        }
        return count;
    }


    public static String returnPipeline(String mTableName)
    {
        String mPipeLine = "";
        String Query = "Select * from " + mTableName;
        Cursor cursor = sqLiteDatabase.rawQuery(Query, null);

        try
        {
            if (cursor != null && cursor.getCount() != 0)
            {
                if(cursor.moveToFirst())
                {
                    mPipeLine = cursor.getString(cursor.getColumnIndex("axis_crg_tb_1"));
                }
            }
        }
        catch (Exception e)
        {
            Log.e(Constant.TAG, "Caught exception", e);
        }
        finally
        {
            if (cursor != null && !cursor.isClosed())
            {
                cursor.close();
            }
        }
        return mPipeLine;
    }

    public static String returnPipeline_Reviewer(String mTableName)
    {
        String mPipeLine = "";
        String Query = "Select * from " + mTableName;
        Cursor cursor = sqLiteDatabase.rawQuery(Query, null);

        try
        {
            if (cursor != null && cursor.getCount() != 0)
            {
                if(cursor.moveToFirst())
                {
                    mPipeLine = cursor.getString(10);
                }
            }
        }
        catch (Exception e)
        {
            Log.e(Constant.TAG, "Caught exception", e);
        }
        finally
        {
            if (cursor != null && !cursor.isClosed())
            {
                cursor.close();
            }
        }

        return mPipeLine;
    }

    public static String returnLastUpadte(String mTableName)
    {
        String mLastUpadte = "";
        String Query = "Select * from " + mTableName;
        Cursor cursor = sqLiteDatabase.rawQuery(Query, null);

        try
        {
            if (cursor != null && cursor.getCount() != 0)
            {
                if(cursor.moveToFirst())
                {
                    mLastUpadte = cursor.getString(53);
                }
            }
        }
        catch (Exception e)
        {
            Log.e(Constant.TAG, "Caught exception", e);
        }
        finally
        {
            if (cursor != null && !cursor.isClosed())
            {
                cursor.close();
            }
        }

        return mLastUpadte;
    }

    public static String returnLastUpadte_Reviewer(String mTableName)
    {
        String mLastUpadte = "";
        String Query = "Select * from " + mTableName;
        Cursor cursor = sqLiteDatabase.rawQuery(Query, null);

        try
        {
            if (cursor != null && cursor.getCount() != 0)
            {
                if(cursor.moveToFirst())
                {
                    mLastUpadte = cursor.getString(11);
                }
            }
        }
        catch (Exception e)
        {
            Log.e(Constant.TAG, "Caught exception", e);
        }
        finally
        {
            if (cursor != null && !cursor.isClosed())
            {
                cursor.close();
            }
        }

        return mLastUpadte;
    }

    // ============================================================================================================
    // AddUp Code
    // ============================================================================================================

    public static final String MEETING_DATA_TB = "meeting_data_tb";
    public static final String MEETING_ID = "id";
    public static final String MEETING_TITLE = "title";
    public static final String MEETING_DATE = "date1";
    public static final String MEETING_DURATION = "duration";
    public static final String MEETING_TYPE = "appointment_type";
    public static final String MEETING_TIME = "meeting_time";
    public static final String MEETING_JSON = "meeting_json";
    public static final String MEETING_USERID = "meeting_userid";
    public static final String MEETING_RELATED_ACC_KEY = "meeting_related_acc_key";
    public static final String MEETING_RELATED_TO_ID = "meeting_related_to_id";
    public static final String MEETING_SUBJECT = "meeting_subject";
    public static final String MEETING_STATUS_KEY = "meeting_status_key";
    public static final String MEETING_RELATEDTOTYPE = "meeting_relatedtotype";
    public static final String MEETING_APPROVAL = "meeting_approval";
    public static final String MEETING_REMARKS_DETAILS = "meeting_remarks_details";
    public static final String MEETING_NOTIFY = "meeting_notify";
    public static final String MEETING_CREATED_BY = "created_by";
    public static final String MEETING_REMARKS = "remarks";
    public static final String MEETING_CREATED_BY_USERID = "created_by_user_id";
    public static final String MEETING_INVITEES = "meeting_invitees";
    public static final String MEETING_RELATED_TO_OPP = "related_to_opp";
    public static final String MEETING_OPP_TAG_VALUE = "opp_tag_value";

    // id time title date duration type
    // id  meeting_time  title  date1  duration  appointment_type

    private static String meeting_data_tb = "create table " + MEETING_DATA_TB + "(" + MEETING_ID + " TEXT," + MEETING_TIME + " TEXT," + MEETING_TITLE + " TEXT," + MEETING_DATE + " TEXT," + MEETING_DURATION + " TEXT," + MEETING_TYPE + " TEXT," + MEETING_JSON + " TEXT," + MEETING_USERID + " TEXT," + MEETING_RELATED_ACC_KEY + " TEXT," + MEETING_RELATED_TO_ID + " TEXT," + MEETING_SUBJECT + " TEXT," + MEETING_STATUS_KEY + " TEXT," + MEETING_RELATEDTOTYPE + " TEXT," + MEETING_APPROVAL + " TEXT," + MEETING_REMARKS_DETAILS + " TEXT," + MEETING_NOTIFY + " TEXT,"+MEETING_CREATED_BY+ " TEXT," + MEETING_REMARKS + " TEXT,"+MEETING_CREATED_BY_USERID + " TEXT, "+MEETING_INVITEES +" TEXT, "+MEETING_RELATED_TO_OPP+" TEXT, "+MEETING_OPP_TAG_VALUE+" TEXT)";

    public boolean addMeeting(String meeting_id, String pTitle, String pDate, String pDuration, String pAppointmentType, String pTime, String json, String userid, String related_to_acc_key, String related_to_id, String subject, String status_key, String relatedtotype, String approval, String remarks_details, String notify, String createdBy, String remarks, String createdByUserId, String invitees)
    {
        ContentValues contentValues = new ContentValues();
        contentValues.put(MEETING_ID, meeting_id);
        contentValues.put(MEETING_TITLE, pTitle);
        contentValues.put(MEETING_DATE, pDate);
        contentValues.put(MEETING_DURATION, pDuration);
        contentValues.put(MEETING_TYPE, pAppointmentType);
        contentValues.put(MEETING_TIME, pTime);
        contentValues.put(MEETING_JSON, json);
        contentValues.put(MEETING_USERID, userid);
        contentValues.put(MEETING_RELATED_ACC_KEY, related_to_acc_key);
        contentValues.put(MEETING_RELATED_TO_ID, related_to_id);
        contentValues.put(MEETING_SUBJECT, subject);
        contentValues.put(MEETING_STATUS_KEY, status_key);
        contentValues.put(MEETING_RELATEDTOTYPE, relatedtotype);
        contentValues.put(MEETING_APPROVAL, approval);
        contentValues.put(MEETING_REMARKS_DETAILS, remarks_details);
        contentValues.put(MEETING_NOTIFY, notify);
        contentValues.put(MEETING_CREATED_BY, createdBy);
        contentValues.put(MEETING_REMARKS, remarks);
        contentValues.put(MEETING_CREATED_BY_USERID, createdByUserId);
        contentValues.put(MEETING_INVITEES, invitees);
        long result = sqLiteDatabase.insert(MEETING_DATA_TB, null, contentValues);
        return result != -1;
    }

    /*public Vector<Data> getMeetingsForDay(String tablename, String date, int id)
    {
        Vector<Data> result = new Vector<>();
        try
        {

            String last_date = "";
            if (!date.equalsIgnoreCase(""))
            {
                SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
                Date date1 = sdf.parse(date);
                Calendar calendar = Calendar.getInstance();
                calendar.setTime(date1);

                int dt = calendar.get(Calendar.DATE);
                int lastdate = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
                int mnth = calendar.get(Calendar.MONTH);
                int yr = calendar.get(Calendar.YEAR);

                last_date = yr+"-"+ Constant.pad(mnth+1)+"-"+ Constant.pad(lastdate);
            }

            Log.i(Constant.TAG,"date filter "+date+" "+last_date);
            String query = "";
            if (id == 0)
            {
                if (date.equalsIgnoreCase(""))
                {
                    query = "select * from " + tablename + " where  date1 >= date('now','localtime') order by datetime(date1) ASC";
                }
                else
                {
                    //query = "select * from " + tablename + " where  date1 >= date('now','localtime') order by datetime(date1) ASC";
                    query = "select * from " + tablename + " where  date1 >= date('now','localtime') and date1 <= '"+last_date+"' order by datetime(date1) ASC";
                }
            }
            else if (id == 1)
                query = "select * from " + tablename + " where " + MEETING_DATE + "='" + date + "' order by datetime(date1) ASC";

            Log.i(Constant.TAG, "Query : "+query);
            Cursor cursor = sqLiteDatabase.rawQuery(query, null);
            if (cursor != null && cursor.getCount() != 0)
            {
                while (cursor.moveToNext())
                {
                    result.add(new Data(cursor.getString(0), cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4), cursor.getString(5), cursor.getString(6), cursor.getString(7), cursor.getString(8), cursor.getString(9), cursor.getString(10), cursor.getString(11), cursor.getString(12), cursor.getString(13), cursor.getString(14), cursor.getString(15), cursor.getString(16), cursor.getString(17), cursor.getString(18), cursor.getString(19), cursor.getString(20), cursor.getString(21)));
                }
            }
            if (cursor != null && !cursor.isClosed())
            {
                cursor.close();
            }
        }
        catch (Exception e)
        {
            Log.e(Constant.TAG_REVIEWER,"getMeetingsForDay_Exception",e);
        }
        return result;
    }*/



    public ArrayList<Data> getMeetingsForDay(String tablename, String date, int id)
    {
        ArrayList<Data> result = new ArrayList<>();
        try
        {

            String fistdate =  "",last_date = "";
            //if (!date.equalsIgnoreCase(""))
            //if(id == 0 || id == 1)

                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM");

                Date date1 = null;
                if(id == 2)
                {
                    date1 = sdf1.parse(date);
                }
                else
                {
                    date1 = sdf.parse(date);
                }

                Calendar calendar = Calendar.getInstance();
                calendar.setTime(date1);

                int dt = calendar.get(Calendar.DATE);
                int lastdate = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
                int mnth = calendar.get(Calendar.MONTH);
                int yr = calendar.get(Calendar.YEAR);
                fistdate = yr+"-"+Constant.pad(mnth+1)+"-"+"01"+" 00:00:00 AM";
                last_date = yr+"-"+ Constant.pad(mnth+1)+"-"+ Constant.pad(lastdate)+" 12:00:00 PM";



            Log.i(Constant.TAG,"date filter "+date+" "+last_date);
            String query = "";

            if (id == 0) // For meeting from current date to last date of month
            {
                //query = "select * from " + tablename + " where  date1 >= date('now','localtime') order by datetime(date1) ASC";
                query = "select * from " + tablename + " where  date1 >= date('now','localtime') and date1 <= '" + last_date + "' and meeting_status_key != '5' order by datetime(date1) ASC";
            }
            else if (id == 1)// For perticular Date Meetings
            {
                String date11 = date+" 00:00:00 AM";
                String date22 = date+" 12:00:00 PM";
                query = "select * from " + tablename + " where  date1 >= '"+date11+"' and date1 <= '" + date22 + "' and meeting_status_key != '5' order by datetime(date1) ASC";
                //query = "select * from " + tablename + " where " + MEETING_DATE + "='"+date +"' and meeting_status_key != '5' order by datetime(date1) ASC";
            }
            else if (id == 2) // For Meeting of perticular Month
            {
                String CurrentDate = DateUtils.returnTodayDate("yyyy-MM");
                Date currentdatemonth = sdf1.parse(CurrentDate);
                if(date1.after(currentdatemonth) || date1.equals(currentdatemonth))
                {
                    query = "select * from " + tablename + " where  date1 >= '" + fistdate + "' and date1 <= '" + last_date + "' and meeting_status_key != '5' order by datetime(date1) ASC";
                }
                /*else
                {
                    query = "select * from " + tablename + " where  date1 >=  date('now','localtime')  and date1 <= '" + last_date + "' and meeting_status_key != '5' order by datetime(date1) ASC";
                }*/


            }


            Log.i(Constant.TAG, "Query : "+query);
            Cursor cursor = sqLiteDatabase.rawQuery(query, null);
            if (cursor != null && cursor.getCount() != 0)
            {
                while (cursor.moveToNext())
                {
                    Log.i(Constant.TAG,"cursor meetng name "+cursor.getString(2));
                    result.add(new Data(cursor.getString(0), cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4), cursor.getString(5), cursor.getString(6), cursor.getString(7), cursor.getString(8), cursor.getString(9), cursor.getString(10), cursor.getString(11), cursor.getString(12), cursor.getString(13), cursor.getString(14), cursor.getString(15), cursor.getString(16), cursor.getString(17), cursor.getString(18), cursor.getString(19), cursor.getString(20), cursor.getString(21)));
                }
            }
            if (cursor != null && !cursor.isClosed())
            {
                cursor.close();
            }
        }
        catch (Exception e)
        {
            Log.e(Constant.TAG,"getMeetingsForDay_Exception",e);
        }
        return result;
    }




    public boolean CheckIsPortfolioAlreadyInDBorNot2(String TableName, String fieldValue)
    {
        String Query = "Select * from " + TableName + " where id = '" + fieldValue + "'";
        Cursor cursor = sqLiteDatabase.rawQuery(Query, null);
        if (cursor.moveToFirst())
        {
            if (cursor.getCount() <= 0)
            {
                if (!cursor.isClosed())
                {
                    cursor.close();
                }
                return false;
            }
            else
            {
                if (!cursor.isClosed())
                {
                    cursor.close();
                }
            }
        }
        else
        {
            if (!cursor.isClosed())
            {
                cursor.close();
            }
            return false;
        }
        if (!cursor.isClosed())
        {
            cursor.close();
        }
        return true;
    }

    /*public static ClassHolder returnCustomer360Array(String mTableName)
    {
        ArrayList<Customer360Wrapper> mCustomer360ArrayList = new ArrayList<>();
        ArrayList<Character> characters =  new ArrayList<>();

        String Query = "Select * from " + mTableName + " ORDER BY CUST_NAME ASC";
        Cursor cursor = sqLiteDatabase.rawQuery(Query, null);
        try
        {
            if (cursor != null && cursor.getCount() != 0)
            {
                while (cursor.moveToNext())
                {
                    mCustomer360ArrayList.add(new Customer360Wrapper(cursor.getString(0), cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4), cursor.getString(5), cursor.getString(6), cursor.getString(7), cursor.getString(8), cursor.getString(9), cursor.getString(10), cursor.getString(11), cursor.getString(12), cursor.getString(13), cursor.getString(14), cursor.getString(15), cursor.getString(16), cursor.getString(17), cursor.getString(18), cursor.getString(19), cursor.getString(20), cursor.getString(21), cursor.getString(22), cursor.getString(23), cursor.getString(24), cursor.getString(25), cursor.getString(26), cursor.getString(27), cursor.getString(28), cursor.getString(29), cursor.getString(30), cursor.getString(31), cursor.getString(32), cursor.getString(33), cursor.getString(34), cursor.getString(35), cursor.getString(36), cursor.getString(37), cursor.getString(38), cursor.getString(39), cursor.getString(40), cursor.getString(41), cursor.getString(42), cursor.getString(43), cursor.getString(44), cursor.getString(45), cursor.getString(46), cursor.getString(47), cursor.getString(48), cursor.getString(49), cursor.getString(50), cursor.getString(51), cursor.getString(52), cursor.getString(53), cursor.getString(54), cursor.getString(55), cursor.getString(56), cursor.getString(57), cursor.getString(58), cursor.getString(59), cursor.getString(60), cursor.getString(61), cursor.getString(62), cursor.getString(63), cursor.getString(64), cursor.getString(65), cursor.getString(66)));

                    String name = cursor.getString(1);
                    if(name.length() > 0 && !characters.contains(new Character(name.charAt(0))))
                    {
                        characters.add(name.charAt(0));
                    }
                }
            }
        }
        catch (Exception e)
        {
            Log.e(Constant.TAG, "Caught exception while reading data from db [CUSTOMER TABLE] in ascneding order : " + e);
        }
        finally
        {
            if (cursor != null && !cursor.isClosed())
            {
                cursor.close();
            }
        }
        return new ClassHolder(characters, mCustomer360ArrayList);
    }*/

    /*public static ArrayList<Customer360Wrapper> returnTableData(String mTableName,String column_name, String column_value)
    {
        ArrayList<Customer360Wrapper> mreturnTableData = new ArrayList<>();
        String Query = "Select * from " + mTableName + " where "+column_name+" = '"+column_value+"' ORDER BY CUSTOMER_ID DESC";
        Cursor cursor = sqLiteDatabase.rawQuery(Query, null);
        try
        {
            if (cursor != null && cursor.getCount() != 0)
            {
                while (cursor.moveToNext())
                {
                    mreturnTableData.add(new Customer360Wrapper(cursor.getString(0), cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4), cursor.getString(5), cursor.getString(6), cursor.getString(7),
                            cursor.getString(8), cursor.getString(9), cursor.getString(10), cursor.getString(11), cursor.getString(12), cursor.getString(13), cursor.getString(14), cursor.getString(15),cursor.getString(16), cursor.getString(17),
                            cursor.getString(18), cursor.getString(19), cursor.getString(20), cursor.getString(21), cursor.getString(22), cursor.getString(23),cursor.getString(24), cursor.getString(25), cursor.getString(26), cursor.getString(27),
                            cursor.getString(28), cursor.getString(29), cursor.getString(30), cursor.getString(31),
                            cursor.getString(32), cursor.getString(33), cursor.getString(34), cursor.getString(35), cursor.getString(36), cursor.getString(37), cursor.getString(38), cursor.getString(39),
                            cursor.getString(40), cursor.getString(41), cursor.getString(42), cursor.getString(43), cursor.getString(44), cursor.getString(45), cursor.getString(46), cursor.getString(47),
                            cursor.getString(48), cursor.getString(49), cursor.getString(50), cursor.getString(51), cursor.getString(52), cursor.getString(53), cursor.getString(54), cursor.getString(55),
                            cursor.getString(56), cursor.getString(57), cursor.getString(58), cursor.getString(59), cursor.getString(60), cursor.getString(61), cursor.getString(62), cursor.getString(63),
                            cursor.getString(64), cursor.getString(65), cursor.getString(66)));
                }
            }
        }
        catch (Exception e)
        {
            Log.e(Constant.TAG, "Caught exception while reading data from db [CUSTOMER TABLE] in ascneding order : " + e);
        }
        finally
        {
            if (cursor != null && !cursor.isClosed())
            {
                cursor.close();
            }
        }
        return mreturnTableData;
    }*/

    public static String[] returnOnlyAccountKeyAndCustomerIdFromDB(String mTablename, String custid)
    {
        String[] details = new String[2];
        String Query = "Select * from " + mTablename + " where CUSTOMER_ID = '"+custid+"'";
        Cursor cursor = sqLiteDatabase.rawQuery(Query, null);

        try
        {
            if (cursor != null && cursor.getCount() != 0)
            {
                while (cursor.moveToNext())
                {
                    details[0] = cursor.getString(2);
                    details[1] = cursor.getString(1);
                }
            }
        }
        catch (Exception e)
        {
            Log.e(Constant.TAG, "Caught exception" , e);
        }
        finally
        {
            if (cursor != null && !cursor.isClosed())
            {
                cursor.close();
            }
        }

        return details;
    }











   /* public DataHolder getMeetingIdList()
    {
        DataHolder holder = new DataHolder();
        Vector meetingid = new Vector();
        ArrayList<String> dates = new ArrayList<>();
        *//*String Query = "Select "+MEETING_ID+","+MEETING_DATE+" from " + MEETING_DATA_TB+ " where strftime('%j',date1) >= strftime('%j','now') order by date1";*//*
        String Query = "Select "+MEETING_ID+","+MEETING_DATE+", meeting_subject from " + MEETING_DATA_TB;



        Cursor cursor = sqLiteDatabase.rawQuery(Query, null);
        try
        {
            if(cursor!=null && cursor.getCount()!=0)
            {
                while(cursor.moveToNext())
                {
                    *//*String sub = cursor.getString(2);
                    Log.i("Check", "Subject : "+sub);*//*
                    if (!cursor.getString(2).equals("Call Report"))
                    {
                        meetingid.add(cursor.getString(0));
                        String date = cursor.getString(cursor.getColumnIndex("date1"));
                        String datesarray[] = date.split("-");
                        date = Integer.parseInt(datesarray[2])+"-"+Constant.pad(Integer.parseInt(datesarray[1]))+"-"+Integer.parseInt(datesarray[0]);

                        Log.i("Check", "The date in SQL : "+date);

                        if(!dates.contains(date))
                        {
                            dates.add(date);
                        }
                    }
                }
            }
        }
        catch(Exception e)
        {
            Log.e(Constant.TAG, "Caught exception", e);
        }
        finally
        {
            if(cursor!= null && !cursor.isClosed())
            {
                cursor.close();
            }
        }
        holder.setDates(dates);
        holder.setVector(meetingid);
        return holder;
    }
*/
    public DataHolder getMeetingIdList()
    {
        DataHolder holder = new DataHolder();
        Vector meetingid = new Vector();
        ArrayList<String> dates = new ArrayList<>();
        /*String Query = "Select "+MEETING_ID+","+MEETING_DATE+" from " + MEETING_DATA_TB+ " where strftime('%j',date1) >= strftime('%j','now') order by date1";*/
        String Query = "Select "+MEETING_ID+","+MEETING_DATE+", meeting_subject from " + MEETING_DATA_TB+" where meeting_status_key != '5' ";



        Cursor cursor = sqLiteDatabase.rawQuery(Query, null);
        try
        {
            if(cursor!=null && cursor.getCount()!=0)
            {
                while(cursor.moveToNext())
                {
                    /*String sub = cursor.getString(2);
                    Log.i("Check", "Subject : "+sub);*/
                    if (!cursor.getString(2).equals("Call Report"))
                    {
                        meetingid.add(cursor.getString(0));
                        String date = cursor.getString(cursor.getColumnIndex("date1"));

                        String date_arr = date.split(" ")[0];
                        String datesarray[] = date_arr.split("-");
                        date = Integer.parseInt(datesarray[2])+"-"+ Constant.pad(Integer.parseInt(datesarray[1]))+"-"+ Integer.parseInt(datesarray[0]);

                       /* String dateformate1 = "yyyy-MM-dd hh:mm:ss a";
                        String dateformate2 = "dd-MM-yyyy";
                        date = DateUtils.mReturnFormattedDate(date,dateformate1,dateformate2);*/

                        Log.i("Check", "The date in SQL : "+date);

                        if(!dates.contains(date))
                        {
                            dates.add(date);
                        }
                    }
                }
            }
        }
        catch(Exception e)
        {
            Log.e(Constant.TAG, "Caught exception", e);
        }
        finally
        {
            if(cursor!= null && !cursor.isClosed())
            {
                cursor.close();
            }
        }
        holder.setDates(dates);
        holder.setVector(meetingid);
        return holder;
    }




    public static int returnCountOfChildSuffix(String child_suffix)
    {
        int total_Cnt = 0;
        String Query = "Select * from limits_utilization_tb where PARENT_SUFFIX='"+child_suffix+"'";
        Log.i(Constant.TAG, "Query : "+Query);

        Cursor cursor = sqLiteDatabase.rawQuery(Query, null);

        try
        {
            if(!cursor.isClosed() && cursor != null)
            {
                Log.i(Constant.TAG, "Count : "+cursor.getCount());
                total_Cnt = cursor.getCount();
            }
        }
        catch (Exception e)
        {
            Log.e(Constant.TAG, "Caught exception in SQLiteAdapter : "+e);
            return total_Cnt;
        }
        finally
        {
            if(cursor!= null && !cursor.isClosed())
            {
                cursor.close();
            }
        }
        return total_Cnt;
    }





    public static String[] returnArrayOfSegmentsForRM(String loginID)
    {
        String[] array = new String[0];
        String Query = "Select * from reviewer_tb where Parent='Root' and LoginID='" + loginID + "'";
        Cursor cursor = sqLiteDatabase.rawQuery(Query, null);
        try
        {
            if (cursor != null && cursor.getCount() != 0)
            {
                array = new String[cursor.getCount()];
                int i = 0;
                while (cursor.moveToNext())
                {
                    String segment = cursor.getString(2);
                    if(segment.trim().length() > 0)
                    {
                        array[i] = segment;
                        i++;
                    }
                }
            }
        }
        catch (Exception e)
        {
            Log.e(Constant.TAG, "Caught exception while returning reviewer details : ", e);
        }
        finally
        {
            if (cursor != null && !cursor.isClosed())
            {
                cursor.close();
            }
        }
        return array;
    }

    public static String[] returnAllUniqueRegionsForReviewer()
    {
        String[] array = new String[0];
        String Query = "Select distinct(Region) from reviewer_tb";
        Cursor cursor = sqLiteDatabase.rawQuery(Query, null);
        try
        {
            if (cursor != null && cursor.getCount() != 0)
            {
                array = new String[cursor.getCount()];
                int i = 0;
                while (cursor.moveToNext())
                //if(cursor.moveToFirst())
                {
                    String segment = cursor.getString(0);
                    if(segment.trim().length() > 0)
                    {
                        array[i] = segment;
                        i++;
                    }
                }
            }
        }
        catch (Exception e)
        {
            Log.e(Constant.TAG, "Caught exception while returning unique reviewer details : ", e);
        }
        finally
        {
            if (cursor != null && !cursor.isClosed())
            {
                cursor.close();
            }
        }
        return array;
    }



    public static String returnRMTypeAccordingToLoginID(String mLoginId)
    {
        String mRM_Type = "";
        String Query = "Select RoleName from reviewer_tb where LoginID='"+mLoginId+"'";
        Cursor cursor = sqLiteDatabase.rawQuery(Query, null);
        try
        {
            if (cursor != null && cursor.getCount() != 0)
            {
                while (cursor.moveToNext())
                {
                    mRM_Type = cursor.getString(0);
                }
            }
        }
        catch (Exception e)
        {
            mRM_Type = "";
            Log.e(Constant.TAG_SQLITE, "Caught exception while returning rm type for login id", e);
        }
        finally
        {
            if (cursor != null && !cursor.isClosed())
            {
                cursor.close();
            }
        }
        return mRM_Type;
    }

    public static String returnRMTypeAccordingToLoginID_Reviewer(String mRM_Name)
    {
        String mRM_Type = "";
        String Query = "Select LoginID from reviewer_tb where Name='"+mRM_Name+"'";
        Cursor cursor = sqLiteDatabase.rawQuery(Query, null);
        try
        {
            if (cursor != null && cursor.getCount() != 0)
            {
                while (cursor.moveToNext())
                {
                    mRM_Type = cursor.getString(0);
                }
            }
        }
        catch (Exception e)
        {
            mRM_Type = "";
            Log.e(Constant.TAG_SQLITE, "Caught exception while returning rm type for login id", e);
        }
        finally
        {
            if (cursor != null && !cursor.isClosed())
            {
                cursor.close();
            }
        }
        return mRM_Type;
    }

    public static String returnRegionHead(String mLoginId)
    {
        String mRM_Type = "";
        String Query = "Select RoleName from reviewer_tb where LoginID='"+mLoginId+"'";
        Cursor cursor = sqLiteDatabase.rawQuery(Query, null);
        try
        {
            if (cursor != null && cursor.getCount() != 0)
            {
                while (cursor.moveToNext())
                {
                    mRM_Type = cursor.getString(0);
                }
            }
        }
        catch (Exception e)
        {
            mRM_Type = "";
            Log.e(Constant.TAG_SQLITE, "Caught exception while returning rm type for login id", e);
        }
        finally
        {
            if (cursor != null && !cursor.isClosed())
            {
                cursor.close();
            }
        }
        return mRM_Type;
    }

    public static ArrayList<String> returnAllEmailContactDetailsFromContactTable()
    {
        ArrayList<String> arrayList = new ArrayList<>();
        String Query = "Select EmailID from contacts_tb";
        Cursor cursor = sqLiteDatabase.rawQuery(Query, null);
        try
        {
            if (cursor != null && cursor.getCount() != 0)
            {
                while(cursor.moveToNext())
                {
                    //arrayList.add(new EmailWrapper(cursor.getString(0)));
                    arrayList.add(cursor.getString(0));
                }
            }
        }
        catch (Exception e)
        {
            Log.e(Constant.TAG_SQLITE, "Caught exception", e);
        }
        finally
        {
            if (cursor != null && !cursor.isClosed())
            {
                cursor.close();
            }
        }
        return arrayList;
    }

    public static String returnAllPhoneContactDetailsFromContactTable(String LoginID)
    {
        String response = "";
        String Query = "Select Contact from contacts_tb where LoginID='"+LoginID+"'";
        Cursor cursor = sqLiteDatabase.rawQuery(Query, null);
        try
        {
            if (cursor != null && cursor.getCount() != 0)
            {
                while(cursor.moveToNext())
                {
                    response = cursor.getString(0);
                }
            }
        }
        catch (Exception e)
        {
            response = "";
            Log.e(Constant.TAG_SQLITE, "Caught exception", e);
        }
        finally
        {
            if (cursor != null && !cursor.isClosed())
            {
                cursor.close();
            }
        }
        return response;
    }


    public static String returnCustomerIDForAccountKey(String mAccountKey)
    {
        String mPipeLine = "";
        String Query = "Select * from customer360_tb where ACCOUNT_ID='" + mAccountKey+"'";
        Cursor cursor = sqLiteDatabase.rawQuery(Query, null);

        try
        {
            if (cursor != null && cursor.getCount() != 0)
            {
                if(cursor.moveToFirst())
                {
                    mPipeLine = cursor.getString(0);
                }
            }
        }
        catch (Exception e)
        {
            Log.e(Constant.TAG, "Caught exception", e);
        }
        finally
        {
            if (cursor != null && !cursor.isClosed())
            {
                cursor.close();
            }
        }

        return mPipeLine;
    }

    public boolean checkIfDataExistsInIrregularAccountsTable()
    {
        boolean b = true;
        String Query = "Select * from irregularities_accounts_tb";
        Cursor cursor = sqLiteDatabase.rawQuery(Query, null);
        try
        {
            b = cursor.getCount() > 0;
        }
        catch (Exception e)
        {
            Log.e(Constant.TAG_SQLITE, "Caught exception", e);
        }
        finally
        {
            if (cursor != null && !cursor.isClosed())
            {
                cursor.close();
            }
        }
        return b;
    }

    public static boolean checkIfDataExistsInCustomerTable(String mCustId)
    {
        boolean b = true;
        String Query = "Select * from customer360_tb where ACCOUNT_ID ='"+mCustId+"'";
        Cursor cursor = sqLiteDatabase.rawQuery(Query, null);
        try
        {
            b = cursor.getCount() > 0;
        }
        catch (Exception e)
        {
            Log.e(Constant.TAG_SQLITE, "Caught exception", e);
        }
        finally
        {
            if (cursor != null && !cursor.isClosed())
            {
                cursor.close();
            }
        }
        return b;
    }

    public static String returnCustomerContactDetails(String customerID)
    {
        String mGroupId = "";
        String Query = "Select * from customer360_tb where ACCOUNT_ID='" + customerID+"'";
        Cursor cursor = sqLiteDatabase.rawQuery(Query, null);
        try
        {
            if (cursor != null && cursor.getCount() != 0)
            {
                if (cursor.moveToFirst())
                {
                    mGroupId = cursor.getString(17);
                }
            }
        }
        catch (Exception e)
        {
            Log.e(Constant.TAG, "Caught exception", e);
        }
        finally
        {
            if (cursor != null && !cursor.isClosed())
            {
                cursor.close();
            }
        }
        return mGroupId;
    }

    public static String returnAppropriateGroupIdForCustomerID(String customerID)
    {
        String mGroupId = "";
        String Query = "Select * from customer_group_tb where CUSTOMER_ID='" + customerID+"'";
        Cursor cursor = sqLiteDatabase.rawQuery(Query, null);
        try
        {
            if (cursor != null && cursor.getCount() != 0)
            {
                if (cursor.moveToFirst())
                {
                    mGroupId = cursor.getString(19);
                }
            }
        }
        catch (Exception e)
        {
            Log.e(Constant.TAG, "Caught exception", e);
        }
        finally
        {
            if (cursor != null && !cursor.isClosed())
            {
                cursor.close();
            }
        }
        return mGroupId;
    }

    public static String returnAppropriateGroupIdForCustomerID_Reviewer(String customerID)
    {
        String mGroupId = "";
        String Query = "Select * from customer360_group_tb where CUSTOMER_ID='" + customerID+"'";
        Cursor cursor = sqLiteDatabase.rawQuery(Query, null);
        try
        {
            if (cursor != null && cursor.getCount() != 0)
            {
                if (cursor.moveToFirst())
                {
                    int mGroupId_index = cursor.getColumnIndex("extracolumn3");
                    mGroupId = cursor.getString(mGroupId_index);
                }
            }
        }
        catch (Exception e)
        {
            Log.e(Constant.TAG, "Caught exception", e);
        }
        finally
        {
            if (cursor != null && !cursor.isClosed())
            {
                cursor.close();
            }
        }
        return mGroupId;
    }

    public static String returnCustPipelineDetails(String mCustomerId)
    {
        String mCustPipeline = "";
        String Query = "Select * from customer360_tb where CUSTOMER_ID='" + mCustomerId+"'";
        Cursor cursor = sqLiteDatabase.rawQuery(Query, null);
        try
        {
            if (cursor != null && cursor.getCount() != 0)
            {
                if (cursor.moveToFirst())
                {
                    mCustPipeline = cursor.getString(25);
                }
            }
        }
        catch (Exception e)
        {
            Log.e(Constant.TAG, "Caught exception", e);
        }
        finally
        {
            if (cursor != null && !cursor.isClosed())
            {
                cursor.close();
            }
        }
        return mCustPipeline;
    }
}
