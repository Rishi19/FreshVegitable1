package com.freshvegitable.utils;

/**
 * Created by Rishi sahu on 3/29/2017.
 */

import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;

public class RootUtil
{
    static String rootedPackages[]=
            {"com.noshufou.android.su",
                    "com.thirdparty.superuser",
                    "eu.chainfire.supersu",
                    "com.koushikdutta.superuser",
                    "com.zachspong.temprootremovejb",
                    "com.ramdroid.appquarantine",
                    "com.devadvance.rootcloakplus",
                    "com.devadvance.rootcloak2",
                    "de.robv.android.xposed.installer"
            };
    public static boolean isDeviceRooted(Context context)
    {
        return checkRootMethod1() || checkRootMethod2() || checkRootMethod3() || checkRootMethod4() || checkRootMethod5(context);
    }

    /*
     * HAD PROBLEMS IN MMX PHONE
     */
    private static boolean checkRootMethod1()
    {
        String buildTags = Build.TAGS;
        return buildTags != null && buildTags.contains("test-keys");
    }

    private static boolean checkRootMethod2()
    {
        String[] paths = { "/system/app/Superuser.apk", "/sbin/su", "/system/bin/su", "/system/xbin/su", "/data/local/xbin/su", "/data/local/bin/su", "/system/sd/xbin/su",
                "/system/bin/failsafe/su", "/data/local/su",
                "/system/xbin/daemonsu",
                "/system/xbin/sugote",
                "/system/xbin/sugote-mksh"};
        for (String path : paths) {
            if (new File(path).exists()) return true;
        }
        return false;
    }

    private static boolean checkRootMethod3()
    {
        Process process = null;
        try {
            process = Runtime.getRuntime().exec(new String[] { "/system/xbin/which", "su" });
            BufferedReader in = new BufferedReader(new InputStreamReader(process.getInputStream()));
            return in.readLine() != null;
        } catch (Throwable t) {
            return false;
        } finally {
            if (process != null) process.destroy();
        }
    }


    public static boolean checkRootMethod4()
    {
        String commandToExecute = "su";
        boolean res= executeShellCommand(commandToExecute);
        return  res;
    }
    public static boolean checkRootMethod5(Context context)
    {
        boolean res=false;
        for(int i=0;i<rootedPackages.length;i++)
        {
            res=   appInstalledOrNot(rootedPackages[i],context);
            if(res)return true;
        }

        return false;
    }

    private static boolean executeShellCommand(String command)
    {
        Process process = null;
        try{
            process = Runtime.getRuntime().exec(command);
            return true;
        } catch (Exception e) {
            return false;
        } finally{
            if(process != null){
                try{
                    process.destroy();
                }catch (Exception e) {
                }
            }
        }
    }

    public  static boolean appInstalledOrNot(String uri, Context context)
    {
        PackageManager pm = context.getPackageManager();
        boolean app_installed = false;
        try {
            pm.getPackageInfo(uri, PackageManager.GET_ACTIVITIES);
            app_installed = true;
        }
        catch (PackageManager.NameNotFoundException e) {
            app_installed = false;
        }
        return app_installed ;
    }
    public static boolean isAndroidEmulator()
    {
        String model = Build.MODEL;
        // ////Log.d(TAG, "model=" + model);
        String product = Build.PRODUCT;
        // ////Log.d(TAG, "product=" + product);
        boolean isEmulator = false;
        if (product != null) {
            isEmulator = product.equals("sdk") || product.contains("_sdk") || product.contains("sdk_");
        }
        // ////Log.d(TAG, "isEmulator=" + isEmulator);
        return isEmulator;
    }

    public static boolean isRooted()
    {

        // get from build info
        String buildTags = Build.TAGS;
        if (buildTags != null && buildTags.contains("test-keys")) {
            return true;
        }

        // check if /system/app/Superuser.apk is present
        try
        {
            File file = new File("/system/app/SuperSU.apk");
            if (file.exists())
            {
                return true;
            }
        }
        catch (Exception e1)
        {
            // ignore
        }

        // try executing commands
        return //canExecuteCommand("/system/xbin/which su")
//	        || canExecuteCommand("/system/bin/which su")
//	        || canExecuteCommand("which su")
                //   ||
                canExecuteCommand("/sbin/su")
                        || canExecuteCommand("/system/su")
                        || canExecuteCommand("/system/xbin/mu")
                        || canExecuteCommand("/system/bin/.ext/.su")
                        ||canExecuteCommand("/system/usr/we-need-root/su-backup");
    }
    private static boolean canExecuteCommand(String command)
    {
        boolean executedSuccesfully;
        try
        {
            Runtime.getRuntime().exec(command);
            executedSuccesfully = true;
        }
        catch (Exception e)
        {
            executedSuccesfully = false;
        }

        return executedSuccesfully;
    }
    public static boolean noRootSVP()
    {
        return false;
    }
}

