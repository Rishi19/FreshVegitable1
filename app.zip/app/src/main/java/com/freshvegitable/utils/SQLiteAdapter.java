package com.freshvegitable.utils;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;


import com.freshvegitable.MainActivity;

import java.io.File;


/**
 * Created by Rishi on 12/17/2015.
 */
public  class SQLiteAdapter {

    public static String MYDATABASE_NAME = "aadhaar.db";
    public static final int MYDATABASE_VERSION = 11;

    public static final String SCANNED_TB = "scanned_tb";
    private static String scanned_tb = "create table "+SCANNED_TB+"(LoginID text,customer_tb_c1 text,customer_tb_c2 text,customer_tb_c3 text,customer_tb_c4 text,customer_tb_c5 text,customer_tb_c6 text,customer_tb_c7 text," +
            "customer_tb_c8 text,customer_tb_c9 text,customer_tb_c10 text,customer_tb_c11 text,customer_tb_c12 text,customer_tb_c13 text,customer_tb_c14 text,customer_tb_c15 text,customer_tb_c16 text," +
            "customer_tb_c17 text,customer_tb_c18 text,customer_tb_c19 text,customer_tb_c20 text,customer_tb_c21 text,customer_tb_c22 text,customer_tb_c23 text)";


    private SQLiteHelper sqLiteHelper;
    public static SQLiteDatabase sqLiteDatabase;
    private Context context;

    public SQLiteAdapter(String db_name)
    {
        MYDATABASE_NAME = "" + db_name;
        MYDATABASE_NAME = getDBNameWithVersionNumber(MYDATABASE_NAME, MYDATABASE_VERSION);
    }

    public SQLiteAdapter(Context cursor)
    {
        context = cursor;
    }

    public SQLiteAdapter(Context cursor, String db_name)
    {
        MYDATABASE_NAME = "" + db_name;
        MYDATABASE_NAME = getDBNameWithVersionNumber(MYDATABASE_NAME, MYDATABASE_VERSION);
        context = cursor;
    }

    private String getDBNameWithVersionNumber(String db_name, int db_version)
    {
        if (db_name.contains("_"))
        {
            int index_db = db_name.indexOf(".db");
            int index_ = db_name.indexOf("_");
            String version = db_name.substring(index_, index_db).replace("_", "");
            if (version.equalsIgnoreCase("" + db_version)) {
                return db_name;
            } else if (Integer.parseInt(version) < db_version) {
                return db_name.replace("_" + version + ".db", "_" + db_version + ".db");
            } else {
                int index = db_name.indexOf(".db");
                return "" + db_name.substring(0, index) + "_" + db_version + ".db";
            }
        }
        else
        {
            int index = db_name.indexOf(".db");
            return "" + db_name.substring(0, index) + "_" + db_version + ".db";
        }
    }

    public boolean isDbOpen() {
        try {
            return sqLiteDatabase.isOpen();

        } catch (Exception e) {
            return false;
        }
    }

    public SQLiteAdapter openToRead() throws android.database.SQLException {
        sqLiteHelper = new SQLiteHelper(context, MYDATABASE_NAME, null, 1);
        sqLiteDatabase = sqLiteHelper.getReadableDatabase();
        return this;
    }

    public SQLiteDatabase getReadable() throws android.database.SQLException {
        sqLiteHelper = new SQLiteHelper(context, MYDATABASE_NAME, null, 1);
        sqLiteDatabase = sqLiteHelper.getReadableDatabase();
        return sqLiteDatabase;
    }

    public SQLiteAdapter openToWrite() throws android.database.SQLException {
        sqLiteHelper = new SQLiteHelper(context, MYDATABASE_NAME, null, 1);
        sqLiteDatabase = sqLiteHelper.getWritableDatabase();
        return this;
    }

    public void close() {
        sqLiteHelper.close();
    }

    public long insertData(String tablename, ContentValues contentvalue) {
        return sqLiteDatabase.insertOrThrow(tablename, null, contentvalue);
    }

    public long updateData(String tablename, ContentValues contentvalue, String where, String whereArgs[]) {
        return sqLiteDatabase.update(tablename, contentvalue, where, whereArgs);
    }

    public Cursor executeRawQuery(String pQuery) {
        Log.i(Constant.TAG, "executeRawQuery : " + pQuery);
        return sqLiteDatabase.rawQuery(pQuery, null);
    }

    public void deleteTable(String table)
    {
        sqLiteDatabase.delete(table, null, null);
    }

    public boolean delete(String DATABASE_TABLE, String KEY_NAME, String name)
    {
        return sqLiteDatabase.delete(DATABASE_TABLE, KEY_NAME + "='" + name + "'", null) > 0;
    }

    public Cursor getData(String query)
    {
        //String select = "Select *,rowid from "+tablename;
        Cursor c = sqLiteDatabase.rawQuery(query, null);
        return c;
    }


    public   static class SQLiteHelper extends SQLiteOpenHelper
    {
        public SQLiteHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version)
        {
            super(context, Constant.FilePath + File.separator+name, factory, version);
        }

        @Override
        public void onCreate(SQLiteDatabase db)
        {
            db.execSQL(scanned_tb);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
        {

        }
    }


    public boolean deleteFromTable(String tablename, String columnName, String fieldValue, SQLiteAdapter mSqlAdapter)
    {

        String Query = "delete  from " + tablename +" where " + columnName + " = '" + fieldValue + "'";
        sqLiteDatabase.rawQuery(Query, null);
        return  true;
    }

}

