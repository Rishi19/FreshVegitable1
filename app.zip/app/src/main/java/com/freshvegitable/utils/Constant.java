package com.freshvegitable.utils;

import android.app.Activity;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Environment;
import android.os.Vibrator;
import android.util.Log;
import android.widget.Toast;

import com.freshvegitable.ApplicationObj;

import java.io.BufferedReader;
import java.io.Closeable;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

/**
 * Created by Rishi Sahu on 7/13/2017.
 */

public class Constant {

   public static  String TAG = "Fresh";
   public static final String TAG_SQLITE = "SQLITE";
   public static  int NORMAL = 100;
   public static  int EXIT = 100;
   public static Toast mToast;

   public static final int FOLDER_VERSION = 1;
   public static String VERSION = "4.3";
   public static String BASE_URL = "";
   public static String BASE_URL_NEWS = "";
   public static String SALES_GUIDE_VERSION = "1.0.0";
   public static String SDCARD_BASEPATH = "/sdcard/TestLive"+FOLDER_VERSION+"/";;
   public static final String SDCARD_FOLDERNAME = "/TestLive"+FOLDER_VERSION;
   public static int SQLITE_VERSION = 5;
   public static final int OLD_SQLITE_VERSION = 4;


   public static String pad(int c)
   {
      if (c >= 10)
         return String.valueOf(c);
      else
         return "0" + String.valueOf(c);
   }

   public static String FilePath = Environment.getExternalStorageDirectory() + File.separator + "MyAdhaar";

   public static boolean showToastShort(Context pContext, String pMessage)
   {

      if (mToast != null) {
         mToast.cancel();
      }
      mToast = Toast.makeText(ApplicationObj.getAppContext(), pMessage, Toast.LENGTH_SHORT);
      mToast.show();
      return false;
   }

   public static boolean showToastLong(Context pContext, String pMessage)
   {

      if (mToast != null) {
         mToast.cancel();
      }
      mToast = Toast.makeText(ApplicationObj.getAppContext(), pMessage, Toast.LENGTH_LONG);
      mToast.show();
      return false;
   }

   public static boolean isNetworkAvailable(Activity activity)
   {

      boolean value = false;
      try
      {
         ConnectivityManager manager = (ConnectivityManager) activity.getSystemService(Context.CONNECTIVITY_SERVICE);
         NetworkInfo info = manager.getActiveNetworkInfo();
         if (info != null && info.isAvailable())
         {
            value = true;
         }
         return value;
      }
      catch (Exception e)
      {
         Log.i(Constant.TAG, "exception " + e);
         return value;
      }
   }

   public static String readTextFile(Context ctx, int resId)
   {
      String mResult = "NA";
      InputStream inputStream = ctx.getResources().openRawResource(resId);
      InputStreamReader inputreader = new InputStreamReader(inputStream);
      BufferedReader bufferedreader = new BufferedReader(inputreader);
      String line;
      StringBuilder stringBuilder = new StringBuilder();

      try
      {
         while ((line = bufferedreader.readLine()) != null)
         {
            stringBuilder.append(line);
            stringBuilder.append('\n');
         }
         mResult = stringBuilder.toString();
      }
      catch (Exception e)
      {
         return mResult;
      }
      finally
      {
         closeStream(bufferedreader);
      }
      return mResult;
   }

   public static String readFromTextFile(String pFilePath)
   {
      File file = new File(pFilePath);
      StringBuilder text = new StringBuilder();
      BufferedReader br = null;
      try
      {
         br = new BufferedReader(new FileReader(file));
         String line;
         while ((line = br.readLine()) != null)
         {
            text.append(line);
            text.append('\n');
         }
         return text.toString();
      }
      catch (IOException e)
      {
         return "NA";
      }
      finally
      {
         closeStream(br);
      }
   }

   public static void closeStream(Closeable s)
   {
      try
      {
         if (s != null)
            s.close();
      }
      catch (IOException e)
      {
         Log.w(Constant.TAG, "Unable to Close Stream");
      }
   }

   public static void vibrate(Context context) {
      // Get instance of Vibrator from current Context and Vibrate for 400
      // milliseconds
      ((Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE))
              .vibrate(100);
   }


}
