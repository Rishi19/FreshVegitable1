package com.freshvegitable.fragments;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.freshvegitable.Adapter.OrderHistoryRecyclerAdapter;
import com.freshvegitable.activities.OrderHistoryActivity;
import com.freshvegitable.R;
import com.freshvegitable.Wrappers.AddressWrapper;
import com.freshvegitable.Wrappers.OrderDetails_Wrapper;
import com.freshvegitable.interfaces.OnFragmentInteractionListener;
import com.freshvegitable.utils.Constant;
import com.freshvegitable.utils.SimpleDividerItemDecoration;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.LinkedHashMap;


public class OrderHistoryListFragment extends BaseFragment implements OnFragmentInteractionListener {


    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;

    OrderHistoryRecyclerAdapter adapter;
    RecyclerView mRecyclerview;
    private OnFragmentInteractionListener mListener;
    Context context;
    OrderHistoryActivity activity;

    public OrderHistoryListFragment() {

    }

    View inflateview;


    public static OrderHistoryListFragment newInstance(String param1, String param2) {
        OrderHistoryListFragment fragment = new OrderHistoryListFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        inflateview = inflater.inflate(R.layout.fragment_orderhistory_list, container, false);
        context  = getContext();
        activity = (OrderHistoryActivity)getActivity();

        initViews();
        setToViews();
        clickToViews();
        setRecyclerAdapter();

        return inflateview;
    }

    @Override
    public void initViews() {
        super.initViews();


        mRecyclerview = (RecyclerView)inflateview.findViewById(R.id.mRecyclerview);
    }

    @Override
    public void setToViews() {
        super.setToViews();


    }

    @Override
    public void clickToViews() {
        super.clickToViews();



    }

    public void setRecyclerAdapter()
    {


        adapter = new OrderHistoryRecyclerAdapter(context,parseJsonData(R.raw.order_history), mListener);

        LinearLayoutManager mLayoutManager = new LinearLayoutManager(context);
        mRecyclerview.setLayoutManager(mLayoutManager);
        mRecyclerview.addItemDecoration(new SimpleDividerItemDecoration(context));
        mRecyclerview.setAdapter(adapter);

        adapter.notifyDataSetChanged();

        adapter.SetOnItemClickListener(new OrderHistoryRecyclerAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {

                Log.v(Constant.TAG,"onClick Called");
                ((OrderHistoryActivity)context).setFragment(1,adapter.getWrapper(position));

                /*Intent intent = new Intent(context,OrderDetailActivity.class);
                Bundle bundle = new Bundle();
                bundle.putParcelable("orderdetail",adapter.getWrapper(position));
                intent.putExtras(bundle);
                activity.startActivityForResult(intent,Constant.NORMAL);*/
            }
        });



    }


    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {

        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onFragmentInteraction(Uri uri) {

    }



    public LinkedHashMap parseJsonData(int resourceid)
    {
        LinkedHashMap linkedHashMap = new LinkedHashMap();


        String Json_String = null;
        try {

            Json_String = Constant.readTextFile(context,resourceid);

            JSONObject jsonObject = new JSONObject(Json_String);
            String status = jsonObject.getString("status");
            if(status.equalsIgnoreCase("success"))
            {
                JSONArray jsonArray = jsonObject.getJSONArray("data");

                for(int i=0;i <jsonArray.length();i++)
                {
                    JSONObject arr_object = jsonArray.getJSONObject(i);

                    String group_id = arr_object.getString("group_id");
                    String itemid = arr_object.getString("item_id");
                    String unique_id = group_id+"_"+itemid;

                    OrderDetails_Wrapper wrapper = new OrderDetails_Wrapper();
                    wrapper.setGroup_id(arr_object.getString("group_id"));
                    wrapper.setItem_id(itemid);
                    wrapper.setGroup_name(arr_object.getString("group_name"));
                    wrapper.setProductName(arr_object.getString("productName"));
                    wrapper.setDescription(arr_object.getString("description"));
                    wrapper.setImageUrl(arr_object.getString("imageUrl"));
                    wrapper.setQuantity_type(arr_object.getString("quantity_type"));
                    wrapper.setMaximum_order(arr_object.getString("maximum_order_limit"));
                    wrapper.setLongDescription(arr_object.getString("longDescription"));
                    wrapper.setMrp(arr_object.getString("mrp"));
                    wrapper.setDiscount(arr_object.getString("discount"));
                    wrapper.setSalePrice(arr_object.getString("salePrice"));
                    wrapper.setOrderQty(arr_object.getString("orderQty"));
                    wrapper.setProductId(arr_object.getString("productId"));
                    wrapper.setDeliveredDate(arr_object.getString("deliveredDate"));
                    wrapper.setDeliveryStatus(arr_object.getString("deliveryStatus"));

                    JSONArray jsonArray1 = arr_object.getJSONArray("addressdetail");
                    JSONObject jsonObject1  = jsonArray1.getJSONObject(0);
                    AddressWrapper addressWrapper = new AddressWrapper();

                    addressWrapper.setId(jsonObject1.getInt("id"));
                    addressWrapper.setName(jsonObject1.getString("name"));
                    addressWrapper.setMobile_no(jsonObject1.getString("mobile_no"));
                    addressWrapper.setAddress1(jsonObject1.getString("address1"));
                    addressWrapper.setAddress2(jsonObject1.getString("address2"));
                    addressWrapper.setAddress3(jsonObject1.getString("address3"));
                    addressWrapper.setPincode(jsonObject1.getString("pincode"));
                    addressWrapper.setCity(jsonObject1.getString("city"));
                    addressWrapper.setState(jsonObject1.getString("state"));
                    addressWrapper.setCountry(jsonObject1.getString("country"));

                    wrapper.setAddressdetail(addressWrapper);


                    linkedHashMap.put(unique_id,wrapper);


                }
            }


        } catch (Exception e) {
            Log.e(Constant.TAG,"Exception",e);
        }

        Log.v(Constant.TAG,"lonkhashmap size "+linkedHashMap);
        return linkedHashMap;
    }

}