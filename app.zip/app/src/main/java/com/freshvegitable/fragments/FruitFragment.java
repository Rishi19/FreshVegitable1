package com.freshvegitable.fragments;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.freshvegitable.R;
import com.freshvegitable.Wrappers.VegiWrapper;
import com.freshvegitable.Wrappers.Vegitable_Wrapper;
import com.freshvegitable.activities.ProductDetailActivity;
import com.freshvegitable.interfaces.OnListFragmentInteractionListener;
import com.freshvegitable.utils.Constant;
import com.freshvegitable.utils.SimpleDividerItemDecoration;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.LinkedHashMap;


public class FruitFragment extends Fragment {


    private static final String ARG_COLUMN_COUNT = "column-count";
    private int mColumnCount = 1;
    private OnListFragmentInteractionListener mListener;
    View view;
    String FILE_PATH = "";
    FruitRecyclerViewAdapter adapter;
    RecyclerView mRecyclerview;

    public FruitFragment()
    {
    }


    @SuppressWarnings("unused")
    public static FruitFragment newInstance(int columnCount) {
        FruitFragment fragment = new FruitFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_COLUMN_COUNT, columnCount);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null)
        {
            mColumnCount = getArguments().getInt(ARG_COLUMN_COUNT);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fruit_fragment_list, container, false);

        mRecyclerview = (RecyclerView)view.findViewById(R.id.mRecyclerview);

        setRecyclerAdapter();


        return view;
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnListFragmentInteractionListener) {
            mListener = (OnListFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnListFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }


   public LinkedHashMap parseJsonData(int resourceid)
   {
       LinkedHashMap linkedHashMap = new LinkedHashMap();


       String Json_String = null;
       try {

           Json_String = Constant.readTextFile(getActivity(),resourceid);

           JSONObject jsonObject = new JSONObject(Json_String);
           String status = jsonObject.getString("status");
           if(status.equalsIgnoreCase("success"))
           {
               JSONArray jsonArray = jsonObject.getJSONArray("data");

               for(int i=0;i <jsonArray.length();i++)
               {
                   JSONObject arr_object = jsonArray.getJSONObject(i);

                   String group_id = arr_object.getString("group_id");
                   String itemid = arr_object.getString("item_id");
                   String unique_id = group_id+"_"+itemid;

                   Vegitable_Wrapper wrapper = new Vegitable_Wrapper();
                   wrapper.setGroup_id(arr_object.getString("group_id"));
                   wrapper.setItem_id(itemid);
                   wrapper.setGroup_name(arr_object.getString("group_name"));
                   wrapper.setItem_name(arr_object.getString("name"));
                   wrapper.setDescription(arr_object.getString("description"));
                   wrapper.setIcon(arr_object.getString("icon"));
                   wrapper.setPrice(arr_object.getString("price"));
                   wrapper.setQuentity_type(arr_object.getString("quentity_type"));
                   wrapper.setMaximum_order(arr_object.getString("maximum_order_limit"));

                   linkedHashMap.put(unique_id,wrapper);

               }
           }


       } catch (Exception e) {
           Log.e(Constant.TAG,"Exception",e);
       }

       return linkedHashMap;
   }


   public void setRecyclerAdapter()
   {

       adapter = new FruitRecyclerViewAdapter(getActivity(),parseJsonData(R.raw.vegitable_data),mListener);

       LinearLayoutManager  mLayoutManager = new LinearLayoutManager(getActivity());
       mRecyclerview.setLayoutManager(mLayoutManager);
       mRecyclerview.addItemDecoration(new SimpleDividerItemDecoration(getActivity()));
       mRecyclerview.setAdapter(adapter);

       adapter.notifyDataSetChanged();

       adapter.SetOnItemClickListener(new FruitRecyclerViewAdapter.OnItemClickListener() {
           @Override
           public void onItemClick(View view, int position) {

               Log.v(Constant.TAG,"onClick Called");
               Intent intent = new Intent(getActivity(), ProductDetailActivity.class);
               startActivityForResult(intent,Constant.NORMAL);
           }
       });



   }



}
