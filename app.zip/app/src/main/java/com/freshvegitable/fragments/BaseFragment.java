package com.freshvegitable.fragments;

import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.SslErrorHandler;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;


import com.freshvegitable.R;
import com.freshvegitable.interfaces.FragmentViews;
import com.freshvegitable.utils.Constant;

import adrViews.AdrTextView;


public class BaseFragment extends Fragment implements FragmentViews {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    public View rootView;
    FrameLayout frame_container;


    public BaseFragment()
    {

    }


    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        if (getArguments() != null)
        {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        RelativeLayout mRelativeLayout = (RelativeLayout) inflater.inflate(R.layout.fragment_base, container, false);
        frame_container = (FrameLayout) mRelativeLayout.findViewById(R.id.frame_container);
        super.onCreateView(inflater,  mRelativeLayout, savedInstanceState);

        return mRelativeLayout;
    }


    public void onButtonPressed(Uri uri)
    {

    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onAttach(Context context)
    {
        super.onAttach(context);

    }

    @Override
    public void onDetach()
    {
        super.onDetach();

    }

    @Override
    public void initViews() {

    }

    @Override
    public void setToViews() {

    }

    @Override
    public void clickToViews() {

    }

    @Override
    public void setwebView(WebView mWebView, final ProgressBar probressbar, String URL) {

        Log.v(Constant.TAG,"url----"+URL);
        probressbar.setProgress(0);
        probressbar.setMax(100);
        WebSettings mWebSettings = mWebView.getSettings();
        mWebView.setWebViewClient(new WebViewClient());
        mWebSettings.setAppCacheMaxSize( 5 * 1024 * 1024 ); // 5MB
        mWebSettings.setBuiltInZoomControls(true);
        mWebSettings.setLoadWithOverviewMode(true);
        mWebSettings.setUseWideViewPort(true);
        mWebSettings.setJavaScriptEnabled(true);
        mWebSettings.setSaveFormData(true);
        mWebSettings.setJavaScriptCanOpenWindowsAutomatically(true);
        mWebSettings.setLoadWithOverviewMode(true);
        mWebSettings.setLayoutAlgorithm(WebSettings.LayoutAlgorithm.NORMAL);
        mWebSettings.setBuiltInZoomControls(true);
        mWebSettings.setAppCachePath( getActivity().getApplicationContext().getCacheDir().getAbsolutePath() );
        mWebSettings.setAllowFileAccess( true );
        mWebSettings.setAppCacheEnabled( true );
        mWebSettings.setJavaScriptEnabled( true );
        mWebSettings.setCacheMode( WebSettings.LOAD_DEFAULT );

        mWebView.loadUrl(URL+"");
        mWebView.setWebViewClient(new MyWebViewClient()
        {
            public void onPageStarted(WebView view, String url, Bitmap favicon)
            {
                super.onPageStarted(view, url, favicon);
                probressbar.setVisibility(View.VISIBLE);
            }

            public void onPageFinished(WebView view, String url)
            {
                super.onPageFinished(view, url);
                probressbar.setVisibility(View.GONE);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView webView, String url) {

                webView.loadUrl(url);
                return true;
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                handler.proceed();
                handler.cancel();
               //showSSLError(handler,error);
            }

            @Override
        public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
            super.onReceivedError(view, request, error);

                Log.v(Constant.TAG,"onRecieveError "+error);
           /* if (Constant.isNetworkAvailable(getActivity()))
            {
                rootView.findViewById(R.id.inc_webview).setVisibility(View.INVISIBLE);
                rootView.findViewById(R.id.retry_LL).setVisibility(View.VISIBLE);
                ((AdrTextView)rootView.findViewById(R.id.retry_txt)).setText(Constant.SERVER_ERROR);
            }
            else
            {
                rootView.findViewById(R.id.inc_webview).setVisibility(View.INVISIBLE);
                rootView.findViewById(R.id.retry_LL).setVisibility(View.VISIBLE);
                ((AdrTextView)rootView.findViewById(R.id.retry_txt)).setText(Constant.NO_NETWORK);
            }*/

        }

            @Override
            public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse errorResponse) {
                super.onReceivedHttpError(view, request, errorResponse);

                /*Log.v(Constant.TAG,"WebResourceResponse "+errorResponse);
                if (Constant.isNetworkAvailable(getActivity()))
                {
                    rootView.findViewById(R.id.inc_webview).setVisibility(View.INVISIBLE);
                    rootView.findViewById(R.id.retry_LL).setVisibility(View.VISIBLE);
                    ((AdrTextView)rootView.findViewById(R.id.retry_txt)).setText(Constant.SERVER_ERROR);
                }
                else
                {
                    rootView.findViewById(R.id.inc_webview).setVisibility(View.INVISIBLE);
                    rootView.findViewById(R.id.retry_LL).setVisibility(View.VISIBLE);
                    ((AdrTextView)rootView.findViewById(R.id.retry_txt)).setText(Constant.NO_NETWORK);
                }*/

            }
        });

        if (Build.VERSION.SDK_INT > 11)
        {
            mWebView.getSettings().setDisplayZoomControls(false);
        }
    }

    public void showSSLError(final SslErrorHandler handler, SslError error)
    {
        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        String message = "SSL Certificate error.";
        switch (error.getPrimaryError()) {
            case SslError.SSL_UNTRUSTED:
                message = "The certificate authority is not trusted.";
                break;
            case SslError.SSL_EXPIRED:
                message = "The certificate has expired.";
                break;
            case SslError.SSL_IDMISMATCH:
                message = "The certificate Hostname mismatch.";
                break;
            case SslError.SSL_NOTYETVALID:
                message = "The certificate is not yet valid.";
                break;
        }
        message += " Do you want to continue anyway?";

        builder.setTitle("SSL Certificate Error");
        builder.setMessage(message);
        builder.setPositiveButton("continue", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                handler.proceed();
            }
        });
        builder.setNegativeButton("cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                handler.cancel();
            }
        });

        final AlertDialog dialog = builder.create();
        dialog.show();
    }


}
