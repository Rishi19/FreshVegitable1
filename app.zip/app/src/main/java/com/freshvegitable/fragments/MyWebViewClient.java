package com.freshvegitable.fragments;

import android.net.http.SslError;
import android.webkit.SslErrorHandler;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/**
 * Created by Rishi sahu on 3/2/2017.
 */

public class MyWebViewClient extends WebViewClient {

    public MyWebViewClient() {
    }

    public boolean shouldOverrideUrlLoading(WebView view, String url) {
        view.loadUrl(url);
        return true;
    }

    public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
        handler.proceed();
        handler.cancel();
    }
}
