package com.freshvegitable.fragments;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.freshvegitable.Adapter.PriceRecyclerAdapter;
import com.freshvegitable.R;
import com.freshvegitable.Wrappers.OrderDetails_Wrapper;
import com.freshvegitable.interfaces.OnFragmentInteractionListener;


public class OrderHistorydetailfragment extends BaseFragment implements OnFragmentInteractionListener {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";


    private String mParam1;
    private OrderDetails_Wrapper mParam2;
    RecyclerView price_recyclerView;
    PriceRecyclerAdapter adapter;
    private OnFragmentInteractionListener mListener;

    public OrderHistorydetailfragment() {


    }

    View inflateview;

    public static OrderHistorydetailfragment newInstance(String param1, OrderDetails_Wrapper orderDetails_wrapper) {

        OrderHistorydetailfragment fragment = new OrderHistorydetailfragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putParcelable(ARG_PARAM2, orderDetails_wrapper);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getParcelable(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        inflateview = inflater.inflate(R.layout.fragment_order_historydetail, container, false);

        initViews();
        setToViews();
        clickToViews();
        setRecyclerAdapter();

        return inflateview;
    }

    @Override
    public void initViews() {
        super.initViews();

        price_recyclerView = (RecyclerView)inflateview.findViewById(R.id.price_recyclerview);

    }

    @Override
    public void setToViews() {
        super.setToViews();
    }

    @Override
    public void clickToViews() {
        super.clickToViews();
    }


    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();
    }



    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {

        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }


    @Override
    public void onFragmentInteraction(Uri uri) {

    }

    public void setRecyclerAdapter()
    {

        /*adapter = new PriceRecyclerAdapter(getContext(),parseJsonData(R.raw.order_history), mListener);

        LinearLayoutManager mLayoutManager = new LinearLayoutManager(context);
        price_recyclerView.setLayoutManager(mLayoutManager);
        price_recyclerView.addItemDecoration(new SimpleDividerItemDecoration(context));
        price_recyclerView.setAdapter(adapter);

        adapter.notifyDataSetChanged();

        adapter.SetOnItemClickListener(new PriceRecyclerAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {

                Log.v(Constant.TAG,"onClick Called");
            }
        });*/



    }
}
