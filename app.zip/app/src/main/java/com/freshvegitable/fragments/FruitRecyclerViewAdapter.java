package com.freshvegitable.fragments;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import com.freshvegitable.Adapter.CustomArrayAdapter;
import com.freshvegitable.R;

import com.freshvegitable.Wrappers.Vegitable_Wrapper;
import com.freshvegitable.activities.VegitableActivity;
import com.freshvegitable.interfaces.ItemTouchHelperAdapter;
import com.freshvegitable.interfaces.OnListFragmentInteractionListener;
import com.freshvegitable.model.CenterRepository;
import com.freshvegitable.model.entities.Product;
import com.freshvegitable.utils.Constant;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;


public class FruitRecyclerViewAdapter extends RecyclerView.Adapter<FruitRecyclerViewAdapter.ViewHolder> implements ItemTouchHelperAdapter{

    private  ArrayList<Vegitable_Wrapper> mValues;
    private  ArrayList<String> mValues_id;
    LinkedHashMap linkedHashMap;
    private final OnListFragmentInteractionListener mListener;
    String numberArr [] = new String[]{"1","2","3","4","5","6","7","8","9"};
    Context context;
    boolean isCartlist = false;

    private OnItemClickListener clickListener;
    private List<Product> productList = new ArrayList<Product>();

    @Override
    public boolean onItemMove(int fromPosition, int toPosition) {
        return false;
    }

    @Override
    public void onItemDismiss(int position) {

    }

    public interface OnItemClickListener {
        public void onItemClick(View view, int position);
    }

    public void SetOnItemClickListener(final OnItemClickListener itemClickListener) {
        this.clickListener = itemClickListener;
    }

    public FruitRecyclerViewAdapter(Context context,LinkedHashMap linkedHashMap,String subcategoryKey , OnListFragmentInteractionListener listener) {
        this.context =context;
        this.linkedHashMap = linkedHashMap;
        mListener = listener;
        mValues = new ArrayList<Vegitable_Wrapper>(linkedHashMap.values());
        mValues_id = new ArrayList<String>(linkedHashMap.keySet());

        if (isCartlist) {

            productList = CenterRepository.getCenterRepository().getListOfProductsInShoppingList();

        } else {

            productList = CenterRepository.getCenterRepository().getMapOfProductsInCategory().get(subcategoryKey);
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.fruit_fragment, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {


       // holder.mItem = mValues.get(position);
        final Product tempObj = productList.get(position);
        Product product = productList.get(position);
        holder.name.setText(product.getItemName());
        holder.mContentDescription.setText(product.getItemDetail());
        holder.price.setText(product.getSellMRP());

        //_SQLITE.openToRead();


        ArrayAdapter<String> segmentAdapter = new CustomArrayAdapter(context, R.layout.spinner_layout, numberArr);
        segmentAdapter.setDropDownViewResource(R.layout.spinner_dropdown_layout);
        holder.spinner.setAdapter(segmentAdapter);


      /*  holder.mView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (null != mListener) {

                    mListener.onListFragmentInteraction(holder.mItem);
                }
            }
        });*/


        holder.add_btn.setOnClickListener(
                new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {


                        //current object



                        //if current object is lready in shopping list
                        if (CenterRepository.getCenterRepository().getListOfProductsInShoppingList().contains(tempObj))
                        {


                            //get position of current item in shopping list
                            int indexOfTempInShopingList = CenterRepository.getCenterRepository().getListOfProductsInShoppingList()
                                    .indexOf(tempObj);

                            // increase quantity of current item in shopping list
                          /*  if (Integer.parseInt(tempObj.getQuantity()) == 0)
                            {

                                ((VegitableActivity) getContext()).updateItemCount(true);

                            }*/


                            String quentity_str = (String)holder.spinner.getSelectedItem();
                            int quentity = Integer.parseInt(quentity_str);
                            Log.v(Constant.TAG,"quentity "+quentity);

                            // update quanity in shopping list
                            CenterRepository
                                    .getCenterRepository()
                                    .getListOfProductsInShoppingList()
                                    .get(indexOfTempInShopingList)
                                    .setQuantity(
                                            String.valueOf(Integer
                                                    .valueOf(tempObj
                                                            .getQuantity()) + quentity));


                            //update checkout amount
                            /*((VegitableActivity) getContext()).updateCheckOutAmount(BigDecimal.valueOf(Long
                                    .valueOf(tempObj.getSellMRP())), quentity, true);

                            ((VegitableActivity) getContext()).updateItemCount(quentity,true);
*/
                            ((VegitableActivity) getContext()).updateCart();

                            // update current item quanitity
                            //holder.quanitity.setText(tempObj.getQuantity());

                        } else {


                            String quentity_str = (String)holder.spinner.getSelectedItem();
                            int quentity = Integer.parseInt(quentity_str);



                            tempObj.setQuantity(String.valueOf(quentity));

                           // holder.quanitity.setText(tempObj.getQuantity());

                            CenterRepository.getCenterRepository()
                                    .getListOfProductsInShoppingList().add(tempObj);


                            ((VegitableActivity) getContext()).updateCart();

                            /*((VegitableActivity) getContext()).updateCheckOutAmount(
                                    BigDecimal
                                            .valueOf(Long
                                                    .valueOf(productList
                                                            .get(position)
                                                            .getSellMRP())), quentity ,
                                    true);

                            ((VegitableActivity) getContext()).updateItemCount(quentity,true);*/

                        }

                        Constant.vibrate(getContext());

                    }
                });

/*
        holder.removeItem.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {

                Product tempObj = (productList).get(position);

                if (CenterRepository.getCenterRepository().getListOfProductsInShoppingList()
                        .contains(tempObj)) {

                    int indexOfTempInShopingList = CenterRepository
                            .getCenterRepository().getListOfProductsInShoppingList()
                            .indexOf(tempObj);

                    if (Integer.valueOf(tempObj.getQuantity()) != 0) {

                        CenterRepository
                                .getCenterRepository()
                                .getListOfProductsInShoppingList()
                                .get(indexOfTempInShopingList)
                                .setQuantity(
                                        String.valueOf(Integer.valueOf(tempObj
                                                .getQuantity()) - 1));

                        ((VegitableActivity) getContext()).updateCheckOutAmount(
                                BigDecimal.valueOf(Long.valueOf(productList
                                        .get(position).getSellMRP())),
                                false);

                        holder.quanitity.setText(CenterRepository
                                .getCenterRepository().getListOfProductsInShoppingList()
                                .get(indexOfTempInShopingList).getQuantity());

                        Constant.vibrate(getContext());

                        if (Integer.valueOf(CenterRepository
                                .getCenterRepository().getListOfProductsInShoppingList()
                                .get(indexOfTempInShopingList).getQuantity()) == 0) {

                            CenterRepository.getCenterRepository()
                                    .getListOfProductsInShoppingList()
                                    .remove(indexOfTempInShopingList);

                            notifyDataSetChanged();

                            ((VegitableActivity) getContext()).updateItemCount(false);

                        }

                    }

                } else {

                }

            }

        });
*/

    }

    @Override
    public int getItemCount() {

        //return mValues.size();
        return productList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        public final View mView;
        public  TextView name;
        public  TextView mContentDescription;
        public Spinner spinner;
        public TextView price;
        public  Button add_btn;
        public Vegitable_Wrapper mItem;

        public ViewHolder(View view) {
            super(view);
            mView = view;


            name = (TextView) view.findViewById(R.id.name);
            mContentDescription = (TextView) view.findViewById(R.id.content_description);
            spinner = (Spinner) view.findViewById(R.id.spinner);
            price = (TextView) view.findViewById(R.id.price);
            add_btn = (Button) view.findViewById(R.id.add_btn);

            mView.setOnClickListener(this);

        }

        @Override
        public String toString() {
            return super.toString() + " '" + mContentDescription.getText() + "'";
        }


        @Override
        public void onClick(View v) {

            clickListener.onItemClick(v, getPosition());
        }
    }




    private VegitableActivity getContext() {
        // TODO Auto-generated method stub
        return (VegitableActivity) context;
    }

}

