package com.freshvegitable.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.freshvegitable.BaseActivity;
import com.freshvegitable.R;

public class FeedbackActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);

        initViews();
        setToViews();
        clickToViews();


    }

    @Override
    public void initViews() {
        super.initViews();



    }

    @Override
    public void setToViews() {
        super.setToViews();



    }

    @Override
    public void clickToViews() {
        super.clickToViews();




    }
}
