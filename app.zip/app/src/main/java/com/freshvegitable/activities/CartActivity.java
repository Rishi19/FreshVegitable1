package com.freshvegitable.activities;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.freshvegitable.Adapter.CartRecyclerViewAdapter;
import com.freshvegitable.BaseActivity;
import com.freshvegitable.BaseActivity1;
import com.freshvegitable.R;
import com.freshvegitable.fragments.FruitRecyclerViewAdapter;
import com.freshvegitable.interfaces.OnListFragmentInteractionListener;
import com.freshvegitable.model.CenterRepository;
import com.freshvegitable.model.entities.Money;
import com.freshvegitable.model.entities.Product;
import com.freshvegitable.utils.Constant;
import com.freshvegitable.utils.FButton;
import com.freshvegitable.utils.SimpleDividerItemDecoration;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;

import adrViews.AdrTextViewMed;

public class CartActivity extends BaseActivity1 {


    CartRecyclerViewAdapter adapter;
    RecyclerView mRecyclerview;
    Context context;
    FButton checkout_btn;
    AdrTextViewMed cart_value;
    int itemCount_cart = 0;
    BigDecimal total_cart_amount ;
    //private BigDecimal checkoutAmount = new BigDecimal(BigInteger.ZERO);
    private OnListFragmentInteractionListener mListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_cart);
        context = getBaseContext();

        initViews();
        setToViews();
        clickToViews();
        setRecyclerAdapter();

    }

    @Override
    public void onResume() {
        super.onResume();

        updateCart();
        changeCartValue();

    }

    @Override
    public void initViews() {
        super.initViews();

        mRecyclerview = (RecyclerView)findViewById(R.id.mRecyclerview);
        checkout_btn = (FButton)findViewById(R.id.checkout_btn);
        cart_value = (AdrTextViewMed)findViewById(R.id.cart_value);
    }

    @Override
    public void setToViews() {
        super.setToViews();

    }

    @Override
    public void clickToViews() {
        super.clickToViews();

        checkout_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(itemCount_cart > 0)
                {
                    Intent intent = new Intent(CartActivity.this,CheckoutActivity.class);
                    Bundle bundle = new Bundle();
                    bundle.putInt("cart_count",itemCount_cart);
                    bundle.putString("total_cart_amount",""+total_cart_amount);
                    intent.putExtras(bundle);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivityForResult(intent,Constant.NORMAL);
                }

            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


    }

    public void setRecyclerAdapter()
    {


        adapter = new CartRecyclerViewAdapter(CartActivity.this, mListener);

        LinearLayoutManager mLayoutManager = new LinearLayoutManager(context);
        mRecyclerview.setLayoutManager(mLayoutManager);
        mRecyclerview.addItemDecoration(new SimpleDividerItemDecoration(context));
        mRecyclerview.setAdapter(adapter);

        adapter.notifyDataSetChanged();

        adapter.SetOnItemClickListener(new CartRecyclerViewAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {

                Log.v(Constant.TAG,"onClick Called");
                Intent intent = new Intent(CartActivity.this, ProductDetailActivity.class);
                startActivityForResult(intent,Constant.NORMAL);
            }
        });



    }

    public void updateItemCount(int quentity,boolean ifIncrement) {
        if (ifIncrement) {

            int itemCount  = CenterRepository.getCenterRepository().getItemCount()+quentity;
            CenterRepository.getCenterRepository().setItemCount(itemCount);
            ((TextView)findViewById(R.id.item_count)).setText(String.valueOf(itemCount));

        } else {

            if (CenterRepository.getCenterRepository().getItemCount() > 0) {
                int itemCount  = CenterRepository.getCenterRepository().getItemCount()-quentity;
                CenterRepository.getCenterRepository().setItemCount(itemCount);
                ((TextView)findViewById(R.id.item_count)).setText(String.valueOf(itemCount));
            }

            //temCountTextView.setText(String.valueOf(itemCount <= 0 ? 0: --itemCount));
        }

        toggleBannerVisibility();
    }

    public void toggleBannerVisibility() {
       /* if (itemCount == 0) {

            findViewById(R.id.checkout_item_root).setVisibility(View.GONE);
            findViewById(R.id.new_offers_banner).setVisibility(View.VISIBLE);

        } else {
            findViewById(R.id.checkout_item_root).setVisibility(View.VISIBLE);
            findViewById(R.id.new_offers_banner).setVisibility(View.GONE);
        }*/
    }

    public void updateCheckOutAmount(BigDecimal amount, int quentity , boolean increment) {

        BigDecimal checkoutAmount = CenterRepository.getCenterRepository().getCheckoutAmount();
        if (increment) {

            checkoutAmount = checkoutAmount.add(amount.multiply(new BigDecimal(quentity)));

        } else {

            //if (checkoutAmount.signum() == 1)
            if(checkoutAmount.compareTo(new BigDecimal(BigInteger.ZERO)) == 1)
                checkoutAmount = checkoutAmount.subtract(amount);
        }

        CenterRepository.getCenterRepository().setCheckoutAmount(checkoutAmount);
        ((AdrTextViewMed)findViewById(R.id.text)).setText(Money.rupees(checkoutAmount).toString());
    }

    public void checkOut()
    {

    }


    public void changeCartValue()
    {
       new CartCalculation().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
    }

    class CartCalculation extends AsyncTask<String,Void,String>
    {
        BigDecimal total_amt = new BigDecimal(BigInteger.ZERO);
        int itemCount = 0;
        List<Product> productList =  CenterRepository.getCenterRepository().getListOfProductsInShoppingList();

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... params) {

            productList =  CenterRepository.getCenterRepository().getListOfProductsInShoppingList();


            for(Product product : productList)
            {
                int product_amt = Integer.parseInt(product.getSellMRP())*Integer.parseInt(product.getQuantity());
                total_amt = total_amt.add(new BigDecimal(product_amt));
                itemCount = itemCount + Integer.parseInt(product.getQuantity());
                itemCount_cart = itemCount;
                total_cart_amount = total_amt;
            }
            if(productList.size() == 0)
            {
                itemCount = 0;
                itemCount_cart = itemCount;
                total_cart_amount = total_amt;
            }

            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            Log.v(Constant.TAG,"itemCount_cart "+itemCount_cart +" productList "+productList.size());

            if(itemCount_cart <= 0)
            {
                checkout_btn.setButtonColor(getResources().getColor(R.color.light_gray));
            }

            cart_value.setText("Cart Subtotal ("+itemCount+" item): "+getResources().getString(R.string.Rs)+" "+total_amt);
        }
    }

}
