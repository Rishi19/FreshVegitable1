package com.freshvegitable.activities;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;

import com.freshvegitable.Adapter.CartRecyclerViewAdapter;
import com.freshvegitable.Adapter.CustomArrayAdapter;
import com.freshvegitable.Adapter.SelectAddressRecyclerAdapter;
import com.freshvegitable.BaseActivity;
import com.freshvegitable.R;
import com.freshvegitable.Wrappers.AddressWrapper;
import com.freshvegitable.interfaces.OnFragmentInteractionListener;
import com.freshvegitable.utils.Constant;
import com.freshvegitable.utils.SimpleDividerItemDecoration;

import org.json.JSONArray;
import org.json.JSONObject;

import java.math.BigDecimal;
import java.util.LinkedHashMap;

public class CheckoutActivity extends BaseActivity {

    RecyclerView mRecyclerview_select_address;
    SelectAddressRecyclerAdapter adapter;

    OnFragmentInteractionListener mListener;
    //private static LinkedHashMap<Integer,AddressWrapper> linkedHashMap = new LinkedHashMap<>();
    public int itemCount_cart = 0;
    public String total_cart_amount ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);

        Bundle bundle = getIntent().getExtras();
        if(bundle != null)
        {
            itemCount_cart = bundle.getInt("cart_count");
            total_cart_amount =  bundle.getString("total_cart_amount");
        }

        initViews();
        setToViews();
        clickToViews();
        //linkedHashMap =  parseJsonData(R.raw.address);

        if(Constant.linkedHashMap.size() > 0)
        {
            setRecyclerAdapter();
        }
        else
        {
            Intent intent = new Intent(this, AddressBookAcitvity.class);
            Bundle bundle1 = new Bundle();
            bundle1.putInt("cart_count",itemCount_cart);
            bundle1.putBoolean("isNewAddress",true);
            bundle1.putString("total_cart_amount",total_cart_amount);
            intent.putExtras(bundle1);
            startActivityForResult(intent,Constant.NORMAL);
        }


    }

    @Override
    public void initViews() {
        super.initViews();

        mRecyclerview_select_address = (RecyclerView)findViewById(R.id.mRecyclerview_select_address);


    }

    @Override
    public void setToViews() {
        super.setToViews();


    }

    @Override
    public void clickToViews() {
        super.clickToViews();


    }

    public void setRecyclerAdapter()
    {


        adapter = new SelectAddressRecyclerAdapter(CheckoutActivity.this,Constant.linkedHashMap, mListener);

        LinearLayoutManager mLayoutManager = new LinearLayoutManager(getBaseContext());
        mRecyclerview_select_address.setLayoutManager(mLayoutManager);
        mRecyclerview_select_address.addItemDecoration(new SimpleDividerItemDecoration(getBaseContext()));
        mRecyclerview_select_address.setAdapter(adapter);

        adapter.notifyDataSetChanged();

        adapter.SetOnItemClickListener(new SelectAddressRecyclerAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {


                Log.v(Constant.TAG,"onClick Called");
                Intent intent = new Intent(CheckoutActivity.this, ProductDetailActivity.class);
                startActivityForResult(intent,Constant.NORMAL);
            }
        });



    }

    public LinkedHashMap parseJsonData(int resourceid)
    {
        LinkedHashMap linkedHashMap = new LinkedHashMap();


        String Json_String = null;
        try {

            Json_String = Constant.readTextFile(CheckoutActivity.this,resourceid);

            JSONObject jsonObject = new JSONObject(Json_String);
            String status = jsonObject.getString("status");
            if(status.equalsIgnoreCase("success"))
            {
                JSONArray jsonArray = jsonObject.getJSONArray("data");

                for(int i=0;i <jsonArray.length();i++)
                {
                    JSONObject arr_object = jsonArray.getJSONObject(i);

                    //String group_id = arr_object.getString("group_id");
                    //String itemid = arr_object.getString("item_id");
                    //String unique_id = group_id+"_"+itemid;

                    AddressWrapper wrapper = new AddressWrapper();
                    int Id = (arr_object.getInt("id"));
                    wrapper.setId(arr_object.getInt("id"));
                    wrapper.setName(arr_object.getString("name"));
                    wrapper.setMobile_no(arr_object.getString("mobile_no"));
                    wrapper.setAddress1(arr_object.getString("address1"));
                    wrapper.setAddress2(arr_object.getString("address2"));
                    wrapper.setAddress3(arr_object.getString("address3"));
                    wrapper.setPincode(arr_object.getString("pincode"));
                    wrapper.setCity(arr_object.getString("city"));
                    wrapper.setState(arr_object.getString("state"));
                    wrapper.setCountry(arr_object.getString("country"));

                    linkedHashMap.put(Id,wrapper);

                }
            }


        } catch (Exception e) {
            Log.e(Constant.TAG,"Exception",e);
        }

        return linkedHashMap;
    }

    public void EditAddress(Bundle bundle)
    {

        Intent intent = new Intent(CheckoutActivity.this,AddressBookAcitvity.class);
        intent.putExtras(bundle);
        startActivityForResult(intent,Constant.NORMAL);

    }

    @Override
    public void onBackPressed() {

        super.onBackPressed();



    }

    public static String[] toStringArray(JSONArray array) {
        if(array==null)
            return null;

        String[] arr=new String[array.length()];
        for(int i=0; i<arr.length; i++) {
            arr[i]=array.optString(i);
        }
        return arr;
    }

    public void deleteAddress(AddressWrapper wrapper)
    {
        int indexOfTempInShopingList = (wrapper.getId());
        Constant.linkedHashMap.remove(indexOfTempInShopingList);

        setRecyclerAdapter();
    }



}
