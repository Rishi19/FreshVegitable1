package com.freshvegitable.activities;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.freshvegitable.BaseActivity;
import com.freshvegitable.MainActivity;
import com.freshvegitable.R;
import com.freshvegitable.SweetAlert.SweetAlertDialog;
import com.freshvegitable.Wrappers.AddressWrapper;
import com.freshvegitable.model.CenterRepository;
import com.freshvegitable.utils.Constant;
import com.freshvegitable.utils.FButton;

import adrViews.AdrBoldTextView;
import adrViews.AdrTextView;

public class ConfirmOrderActivty extends BaseActivity {


    int itemCount_cart = 0;
    String total_cart_amount1 ;
    AdrTextView total_rupees,address1,address2,address3,mobile_no,confirm_item_count;
    FButton confirm_order_btn;
    public AdrBoldTextView name;
    public AddressWrapper addressWrapper;
    SweetAlertDialog sweetAlertDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm_order);

        Bundle bundle = this.getIntent().getExtras();
        if(bundle != null)
        {
            itemCount_cart = bundle.getInt("cart_count");
            total_cart_amount1 =  bundle.getString("total_cart_amount");
            this.addressWrapper =  bundle.getParcelable("selected_address");
            Log.v(Constant.TAG,"itemCount_cart "+itemCount_cart);
            Log.v(Constant.TAG,"total_cart_amount1 "+total_cart_amount1);
            Log.v(Constant.TAG,"addressWrapper address2 "+addressWrapper.getAddress2());
            Log.v(Constant.TAG,"addressWrapper confirm_order "+addressWrapper.getCity());
            Log.v(Constant.TAG,"addressWrapper confirm_order "+addressWrapper.getMobile_no());
        }

        Log.v(Constant.TAG,"initViews called on oncrete---");
        if(savedInstanceState == null){

            initViews();
            setToViews();
            clickToViews();
        }




    }

    @Override
    public void onResume() {
        super.onResume();


    }

    @Override
    public void initViews() {
        super.initViews();

        confirm_item_count = (AdrTextView)findViewById(R.id.confirm_item_count);
        total_rupees = (AdrTextView)findViewById(R.id.total_rupees);
        confirm_order_btn = (FButton)findViewById(R.id.confirm_order_btn);

        name = (AdrBoldTextView)findViewById(R.id.name);
        address1 = (AdrTextView)findViewById(R.id.address1);
        address2 = (AdrTextView)findViewById(R.id.address2);
        address3 = (AdrTextView)findViewById(R.id.address3);
        mobile_no = (AdrTextView)findViewById(R.id.mobile_no);

    }

    @Override
    public void setToViews() {
        super.setToViews();

        Log.v(Constant.TAG,"setToView called in ConfirmOrder ");

        confirm_item_count.setText(""+itemCount_cart);
        total_rupees.setText(""+total_cart_amount1);

        if (addressWrapper != null) {

            name.setText(""+addressWrapper.getName());
            address1.setText(""+addressWrapper.getAddress1());
            address2.setText(""+addressWrapper.getAddress2());
            String address3_str = addressWrapper.getCity()+", "+addressWrapper.getState()+" "+addressWrapper.getPincode();
            address3.setText(address3_str);
            mobile_no.setText("Mobile no. "+addressWrapper.getMobile_no());
        }


    }

    @Override
    public void clickToViews() {
        super.clickToViews();

        confirm_order_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //new confirmOrderAsync().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);

                ((ImageView)findViewById(R.id.bg_transparent_black)).setVisibility(View.VISIBLE);

                try
                {
                    if (sweetAlertDialog != null && sweetAlertDialog.isShowing())
                    {
                        sweetAlertDialog.dismiss();
                    }
                }
                catch (final Exception e){}
                sweetAlertDialog = new SweetAlertDialog(ConfirmOrderActivty.this, SweetAlertDialog.SUCCESS_TYPE).setTitleText("Your Order Placed");
                sweetAlertDialog.setCancelable(false);
                //sweetAlertDialog.setTitleText("gjgigig");

                sweetAlertDialog.setCanceledOnTouchOutside(false);
                sweetAlertDialog.getProgressHelper().setBarColor(getBaseContext().getResources().getColor(R.color.blue_btn_bg_color));
                sweetAlertDialog.show();
                sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                    @Override
                    public void onClick(SweetAlertDialog sweetAlertDialog) {


                        ((ImageView)findViewById(R.id.bg_transparent_black)).setVisibility(View.VISIBLE);
                        sweetAlertDialog.dismiss();

                        CenterRepository.getCenterRepository().getListOfProductsInShoppingList().clear();
                        Intent intent = new Intent(ConfirmOrderActivty.this,MainActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP );
                        startActivityForResult(intent, Constant.NORMAL);
                        finish();

                    }
                });

            }
        });

    }

    public class confirmOrderAsync extends AsyncTask<String,Void,String>
    {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... params) {


            return "success";
        }


        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            if(result.equalsIgnoreCase("success"))
            {
                showSuccessDilaog();
            }

        }
    }


    public void showSuccessDilaog()
    {
        final Dialog dialog = new Dialog(ConfirmOrderActivty.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);
        dialog.setContentView(R.layout.confirm_order_dialog);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialog.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
        lp.gravity = Gravity.CENTER;

        dialog.getWindow().setAttributes(lp);

        Button ok_button = (Button) dialog.findViewById(R.id.ok_button);
        ok_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                    Toast.makeText(getApplicationContext(),"Cancel" ,Toast.LENGTH_SHORT).show();
                dialog.dismiss();

                CenterRepository.getCenterRepository().getListOfProductsInShoppingList().clear();
                Intent intent = new Intent(ConfirmOrderActivty.this,MainActivity.class);
                //intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP );
                startActivityForResult(intent, Constant.NORMAL);
            }
        });

        dialog.show();
    }
}
