package com.freshvegitable.activities;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.content.Loader;
import android.support.v4.view.ViewPager;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.freshvegitable.Adapter.VegiPagerAdapter;
import com.freshvegitable.BaseActivity;

import com.freshvegitable.R;
import com.freshvegitable.fragments.DemoFragment;
import com.freshvegitable.fragments.FruitFragment;
import com.freshvegitable.fragments.VegiFragment;
import com.freshvegitable.Wrappers.Vegitable_Wrapper;
import com.freshvegitable.interfaces.OnListFragmentInteractionListener;
import com.freshvegitable.model.CenterRepository;
import com.freshvegitable.model.entities.Money;
import com.freshvegitable.model.entities.Product;
import com.freshvegitable.pagerAdapterLib.v4.FragmentPagerItem;
import com.freshvegitable.pagerAdapterLib.v4.FragmentPagerItemAdapter;
import com.freshvegitable.pagerAdapterLib.v4.FragmentPagerItems;
import com.freshvegitable.utils.Constant;
import com.freshvegitable.utils.PagerSlidingTabStrip;

import com.freshvegitable.utils.PreferenceHelper;
import com.freshvegitable.utils.TinyDB;
import com.ogaclejapan.smarttablayout.SmartTabLayout;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import adrViews.AdrTextViewMed;


public class VegitableActivity extends BaseActivity implements OnListFragmentInteractionListener,SmartTabLayout.OnTabClickListener {

    VegiPagerAdapter vegiPagerAdapter;
    ViewPager mViewPager;
    PagerSlidingTabStrip fragment_pagertabstrip;
    SmartTabLayout viewPagerTab;
    int pagerTabNumber = 0;
    private int itemCount = 0;
    private ProgressBar progressBar;
    private BigDecimal checkoutAmount = new BigDecimal(BigInteger.ZERO);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vegitable);



        Bundle extras = getIntent().getExtras();

        if (extras != null) {
            pagerTabNumber = extras.getInt("pagerTabNumber");
            Log.v(Constant.TAG,"pageNumber "+pagerTabNumber);
            // and get whatever type user account id is
        }

        CenterRepository.getCenterRepository().setListOfProductsInShoppingList(
                new TinyDB(getApplicationContext()).getListObject(PreferenceHelper.MY_CART_LIST_LOCAL, Product.class));

        itemCount = CenterRepository.getCenterRepository().getListOfProductsInShoppingList().size();

        initViews();
        setToViews();
        clickToViews();
        //setViewPager();

    }

    @Override
    public void initViews() {
        super.initViews();

        ViewGroup tab = (ViewGroup) findViewById(R.id.tab);
        tab.addView(LayoutInflater.from(this).inflate(R.layout.demo_custom_tab_text, tab, false));

        mViewPager   = (ViewPager) findViewById(R.id.viewpager);
        viewPagerTab = (SmartTabLayout) findViewById(R.id.viewpagertab);
        //fragment_pagertabstrip   = (PagerSlidingTabStrip) findViewById(R.id.fragment_pagertabstrip);

        FragmentPagerItems pages = new FragmentPagerItems(this);

        int TitleArr[] = tabs();
        //for (int titleResId : tabs())
        {
            pages.add(FragmentPagerItem.of(getString(TitleArr[0]), FruitFragment.class));
            pages.add(FragmentPagerItem.of(getString(TitleArr[1]), FruitFragment.class));
            pages.add(FragmentPagerItem.of(getString(TitleArr[2]), DemoFragment.class));
            pages.add(FragmentPagerItem.of(getString(TitleArr[3]), VegiFragment.class));
            pages.add(FragmentPagerItem.of(getString(TitleArr[4]), DemoFragment.class));

        }

        FragmentPagerItemAdapter adapter = new FragmentPagerItemAdapter(getSupportFragmentManager(), pages);

        mViewPager.setAdapter(adapter);
        mViewPager.setCurrentItem(pagerTabNumber);
        viewPagerTab.setViewPager(mViewPager);


    }

    @Override
    public void setToViews() {
        super.setToViews();


    }

    @Override
    public void clickToViews() {
        super.clickToViews();



    }



    private void setViewPager()
    {
        try
        {
            vegiPagerAdapter = new VegiPagerAdapter(getSupportFragmentManager(), VegitableActivity.this,getFragments());
            vegiPagerAdapter.notifyDataSetChanged();
            mViewPager.setAdapter(vegiPagerAdapter);
            //mViewPager.setCurrentItem(0);
            viewPagerTab.setViewPager(mViewPager);
            //fragment_pagertabstrip.setShouldExpand(true);

/*
            fragment_pagertabstrip.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
                @Override
                public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels)
                {

                }

                @Override
                public void onPageSelected(int position)
                {
                    switch (position)
                    {
                        case 0:

                           */
/* Achievement_txt.setBackgroundResource(R.drawable.slide_tab_bg_select);
                            Achievement_txt.setTextColor(Color.parseColor("#FFFFFF"));
                            pipeline_txt.setBackgroundResource(R.drawable.slide_tab_bg_unselect);
                            pipeline_txt.setTextColor(Color.parseColor("#b7b7b7"));
                            shareIcon.setVisibility(View.GONE);*//*



                            break;
                        case 1:

                            */
/*Achievement_txt.setBackgroundResource(R.drawable.slide_tab_bg_unselect);
                            Achievement_txt.setTextColor(Color.parseColor("#b7b7b7"));
                            pipeline_txt.setBackgroundResource(R.drawable.slide_tab_bg_select);
                            pipeline_txt.setTextColor(Color.parseColor("#FFFFFF"));
                            shareIcon.setVisibility(View.VISIBLE);*//*


                            break;
                    }
                }

                @Override
                public void onPageScrollStateChanged(int state)
                {

                }
            });
*/
        }
        catch (Exception e)
        {
            Log.e(Constant.TAG, "Caught exception", e);
        }
    }


    private List<Fragment> getFragments()
    {
        List<Fragment> fList = new ArrayList<>();
        fList.add(VegiFragment.newInstance("Vegitable", "0"));
        fList.add(VegiFragment.newInstance("Exotic_Vegitable", "1"));
        return fList;
    }

    @Override
    public void onListFragmentInteraction(Vegitable_Wrapper item) {

    }

    @Override
    public void onFragmentInteraction(Uri uri) {

    }

    public int[] tabs() {
        return tab10();
    }

    public static int[] tab10() {
        return new int[] {
                R.string.demo_tab_1,
                R.string.demo_tab_2,
                R.string.demo_tab_3,
                R.string.demo_tab_4,
                R.string.demo_tab_5
        };
    }


    @Override
    public void onTabClicked(int position) {

    }

    public int getItemCount() {
        return itemCount;
    }

/*
    public void showPurchaseDialog() {

        AlertDialog.Builder exitScreenDialog = new AlertDialog.Builder(VegitableActivity.this, R.style.PauseDialog);

        exitScreenDialog.setTitle("Order Confirmation")
                .setMessage("Would you like to place this order ?");
        exitScreenDialog.setCancelable(true);

        exitScreenDialog.setPositiveButton(
                "Place Order",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        //finish();
                        dialog.cancel();

                        ArrayList<String> productId = new ArrayList<String>();

                        for (Product productFromShoppingList : CenterRepository.getCenterRepository().getListOfProductsInShoppingList()) {

                            //add product ids to array
                            productId.add(productFromShoppingList.getProductId());
                        }

                        //pass product id array to Apriori ALGO
                        CenterRepository.getCenterRepository()
                                .addToItemSetList(new HashSet<>(productId));

                        //Do Minning
                        FrequentItemsetData<String> data = generator.generate(
                                CenterRepository.getCenterRepository().getItemSetList()
                                , MINIMUM_SUPPORT);

                        for (Set<String> itemset : data.getFrequentItemsetList()) {
                            Log.e("APriori", "Item Set : " +
                                    itemset + "Support : " +
                                    data.getSupport(itemset));
                        }

                        //clear all list item
                        CenterRepository.getCenterRepository().getListOfProductsInShoppingList().clear();

                        toggleBannerVisibility();

                        itemCount = 0;
                        itemCountTextView.setText(String.valueOf(0));
                        checkoutAmount = new BigDecimal(BigInteger.ZERO);
                        checkOutAmount.setText(Money.rupees(checkoutAmount).toString());

                    }
                });

        exitScreenDialog.setNegativeButton(
                "Cancel",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });

        exitScreenDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                Snackbar.make(ECartHomeActivity.this.getWindow().getDecorView().findViewById(android.R.id.content)
                        , "Order Placed Successfully, Happy Shopping !!", Snackbar.LENGTH_LONG)
                        .setAction("View Apriori Output", new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                startActivity(new Intent(ECartHomeActivity.this, APrioriResultActivity.class));
                            }
                        }).show();
            }
        });

        AlertDialog alert11 = exitScreenDialog.create();
        alert11.show();

    }
*/

    public void updateItemCount(int quentity,boolean ifIncrement) {
        if (ifIncrement) {

            itemCount = itemCount+quentity;
            ((TextView)findViewById(R.id.item_count)).setText(String.valueOf(itemCount));

        } else {
            itemCount = itemCount-quentity;
            ((TextView)findViewById(R.id.item_count)).setText(String.valueOf(itemCount));
        }

        toggleBannerVisibility();
    }

    public void toggleBannerVisibility() {
       /* if (itemCount == 0) {

            findViewById(R.id.checkout_item_root).setVisibility(View.GONE);
            findViewById(R.id.new_offers_banner).setVisibility(View.VISIBLE);

        } else {
            findViewById(R.id.checkout_item_root).setVisibility(View.VISIBLE);
            findViewById(R.id.new_offers_banner).setVisibility(View.GONE);
        }*/
    }

    public void updateCheckOutAmount(BigDecimal amount,int quentity , boolean increment) {

        if (increment) {
            checkoutAmount = checkoutAmount.add(amount.multiply(new BigDecimal(quentity)));

        } else {

            if (checkoutAmount.signum() == 1)
                checkoutAmount = checkoutAmount.subtract(amount);
        }

        ((AdrTextViewMed)findViewById(R.id.text)).setText(Money.rupees(checkoutAmount).toString());
        //checkOutAmount.setText(Money.rupees(checkoutAmount).toString());
    }

    public ProgressBar getProgressBar() {
        return progressBar;
    }

}
