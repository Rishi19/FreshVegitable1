package com.freshvegitable.activities;

import android.net.Uri;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.freshvegitable.Adapter.VegiPagerAdapter;
import com.freshvegitable.BaseActivity;

import com.freshvegitable.R;
import com.freshvegitable.fragments.DemoFragment;
import com.freshvegitable.fragments.FruitFragment;
import com.freshvegitable.fragments.VegiFragment;
import com.freshvegitable.Wrappers.Vegitable_Wrapper;
import com.freshvegitable.interfaces.OnListFragmentInteractionListener;
import com.freshvegitable.pagerAdapterLib.v4.FragmentPagerItem;
import com.freshvegitable.pagerAdapterLib.v4.FragmentPagerItemAdapter;
import com.freshvegitable.pagerAdapterLib.v4.FragmentPagerItems;
import com.freshvegitable.utils.Constant;
import com.freshvegitable.utils.PagerSlidingTabStrip;

import com.ogaclejapan.smarttablayout.SmartTabLayout;

import java.util.ArrayList;
import java.util.List;


public class VegitableActivity extends BaseActivity implements OnListFragmentInteractionListener,SmartTabLayout.OnTabClickListener {

    VegiPagerAdapter vegiPagerAdapter;
    ViewPager mViewPager;
    PagerSlidingTabStrip fragment_pagertabstrip;
    SmartTabLayout viewPagerTab;
    int pagerTabNumber = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vegitable);

        Bundle extras = getIntent().getExtras();

        if (extras != null) {
            pagerTabNumber = extras.getInt("pagerTabNumber");
            Log.v(Constant.TAG,"pageNumber "+pagerTabNumber);
            // and get whatever type user account id is
        }


        initViews();
        setToViews();
        clickToViews();
        //setViewPager();

    }

    @Override
    public void initViews() {
        super.initViews();

        ViewGroup tab = (ViewGroup) findViewById(R.id.tab);
        tab.addView(LayoutInflater.from(this).inflate(R.layout.demo_custom_tab_text, tab, false));

        mViewPager   = (ViewPager) findViewById(R.id.viewpager);
        viewPagerTab = (SmartTabLayout) findViewById(R.id.viewpagertab);
        //fragment_pagertabstrip   = (PagerSlidingTabStrip) findViewById(R.id.fragment_pagertabstrip);

        FragmentPagerItems pages = new FragmentPagerItems(this);

        int TitleArr[] = tabs();
        //for (int titleResId : tabs())
        {
            pages.add(FragmentPagerItem.of(getString(TitleArr[0]), FruitFragment.class));
            pages.add(FragmentPagerItem.of(getString(TitleArr[1]), FruitFragment.class));
            pages.add(FragmentPagerItem.of(getString(TitleArr[2]), DemoFragment.class));
            pages.add(FragmentPagerItem.of(getString(TitleArr[3]), VegiFragment.class));
            pages.add(FragmentPagerItem.of(getString(TitleArr[4]), DemoFragment.class));

        }

        FragmentPagerItemAdapter adapter = new FragmentPagerItemAdapter(getSupportFragmentManager(), pages);

        mViewPager.setAdapter(adapter);
        mViewPager.setCurrentItem(pagerTabNumber);
        viewPagerTab.setViewPager(mViewPager);


    }

    @Override
    public void setToViews() {
        super.setToViews();


    }

    @Override
    public void clickToViews() {
        super.clickToViews();



    }



    private void setViewPager()
    {
        try
        {
            vegiPagerAdapter = new VegiPagerAdapter(getSupportFragmentManager(), VegitableActivity.this,getFragments());
            vegiPagerAdapter.notifyDataSetChanged();
            mViewPager.setAdapter(vegiPagerAdapter);
            //mViewPager.setCurrentItem(0);
            viewPagerTab.setViewPager(mViewPager);
            //fragment_pagertabstrip.setShouldExpand(true);

/*
            fragment_pagertabstrip.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
                @Override
                public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels)
                {

                }

                @Override
                public void onPageSelected(int position)
                {
                    switch (position)
                    {
                        case 0:

                           */
/* Achievement_txt.setBackgroundResource(R.drawable.slide_tab_bg_select);
                            Achievement_txt.setTextColor(Color.parseColor("#FFFFFF"));
                            pipeline_txt.setBackgroundResource(R.drawable.slide_tab_bg_unselect);
                            pipeline_txt.setTextColor(Color.parseColor("#b7b7b7"));
                            shareIcon.setVisibility(View.GONE);*//*



                            break;
                        case 1:

                            */
/*Achievement_txt.setBackgroundResource(R.drawable.slide_tab_bg_unselect);
                            Achievement_txt.setTextColor(Color.parseColor("#b7b7b7"));
                            pipeline_txt.setBackgroundResource(R.drawable.slide_tab_bg_select);
                            pipeline_txt.setTextColor(Color.parseColor("#FFFFFF"));
                            shareIcon.setVisibility(View.VISIBLE);*//*


                            break;
                    }
                }

                @Override
                public void onPageScrollStateChanged(int state)
                {

                }
            });
*/
        }
        catch (Exception e)
        {
            Log.e(Constant.TAG, "Caught exception", e);
        }
    }


    private List<Fragment> getFragments()
    {
        List<Fragment> fList = new ArrayList<>();
        fList.add(VegiFragment.newInstance("Vegitable", "0"));
        fList.add(VegiFragment.newInstance("Exotic_Vegitable", "1"));
        return fList;
    }

    @Override
    public void onListFragmentInteraction(Vegitable_Wrapper item) {

    }

    @Override
    public void onFragmentInteraction(Uri uri) {

    }

    public int[] tabs() {
        return tab10();
    }

    public static int[] tab10() {
        return new int[] {
                R.string.demo_tab_1,
                R.string.demo_tab_2,
                R.string.demo_tab_3,
                R.string.demo_tab_4,
                R.string.demo_tab_5
        };
    }


    @Override
    public void onTabClicked(int position) {

    }
}
