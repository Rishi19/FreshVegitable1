package com.freshvegitable.activities;

import android.content.Intent;
import android.support.v4.widget.NestedScrollView;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.CheckBox;
import android.widget.RelativeLayout;
import android.widget.Spinner;

import com.freshvegitable.Adapter.AddressRecyclerViewAdapter;
import com.freshvegitable.Adapter.CustomArrayAdapter;
import com.freshvegitable.BaseActivity;
import com.freshvegitable.BaseActivity1;
import com.freshvegitable.R;
import com.freshvegitable.Wrappers.AddressWrapper;
import com.freshvegitable.Wrappers.Vegitable_Wrapper;
import com.freshvegitable.fragments.FruitRecyclerViewAdapter;
import com.freshvegitable.interfaces.OnListFragmentInteractionListener;
import com.freshvegitable.model.CenterRepository;
import com.freshvegitable.model.entities.Product;
import com.freshvegitable.utils.Constant;
import com.freshvegitable.utils.FButton;
import com.freshvegitable.utils.SimpleDividerItemDecoration;

import org.apache.commons.lang3.RandomUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;

import adrViews.AdrBoldTextView;
import adrViews.AdrEditText;
import adrViews.AdrTextView;

import static com.freshvegitable.utils.Constant.linkedHashMap;

public class AddressBookAcitvity extends BaseActivity {

    AddressRecyclerViewAdapter adapter;
    private OnListFragmentInteractionListener mListener;
    String country_arr [] = new String[]{"India"};
    String state_arr [] = new String[]{"India"};
    String city_arr [];
    RecyclerView mRecyclerview;
    RelativeLayout show_address_RL , add_new_address_RL ,  add_new_address_btn_RL;
    AdrEditText edt_name , edt_mobile_no , edt_pincode , edt_address1 , edt_address2 , edt_address3 , edt_city;
    public Spinner county_spinner , state_spinner;
    AutoCompleteTextView auto_city;
    FButton add_btn;
    NestedScrollView nested_scroll_show_address;
    //private static List<AddressWrapper> listOfAddress = Collections.synchronizedList(new ArrayList<AddressWrapper>());
    //public static LinkedHashMap<Integer,AddressWrapper> linkedHashMap = new LinkedHashMap<>();
    AdrTextView address_id;
    AddressWrapper addressWrapper;
    boolean ischeckout = false,isNewAddress = false;
    int cart_count;
    String total_cart_amount;
    CheckBox saveforlater_chkbox;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_address_book);

        Bundle bundle = this.getIntent().getExtras();
        if(bundle != null)
        {
            ischeckout = bundle.getBoolean("ischeckout",false);

            if(ischeckout)
            {
                isNewAddress = bundle.getBoolean("isNewAddress",false);
                cart_count = bundle.getInt("cart_count");
                total_cart_amount = bundle.getString("total_cart_amount");

                if (!isNewAddress) {

                    addressWrapper =  bundle.getParcelable("edit_address");
                    Log.v(Constant.TAG,"addressbook addressWrapper "+addressWrapper.getName());
                }


            }

        }



        initViews();
        setToViews();
        clickToViews();
        setRecyclerAdapter();

        if(addressWrapper != null && !isNewAddress && ischeckout)
        {
            show_address_RL.setVisibility(View.GONE);
            add_new_address_RL.setVisibility(View.VISIBLE);
            add_btn.setText("Submit");
            EditAddress(addressWrapper,ischeckout);
        }
        else if(ischeckout && isNewAddress)
        {
            show_address_RL.setVisibility(View.GONE);
            add_new_address_RL.setVisibility(View.VISIBLE);
            add_btn.setText("Select address");
        }
        else
        {
            saveforlater_chkbox.setVisibility(View.GONE);
        }

    }

    @Override
    public void initViews() {
        super.initViews();

        mRecyclerview = (RecyclerView) findViewById(R.id.mRecyclerview);
        show_address_RL = (RelativeLayout) findViewById(R.id.show_address_RL);
        add_new_address_RL = (RelativeLayout) findViewById(R.id.add_new_address_RL);
        add_new_address_btn_RL = (RelativeLayout) findViewById(R.id.add_new_address_btn_RL);


        county_spinner = (Spinner) findViewById(R.id.county_spinner);
        state_spinner = (Spinner) findViewById(R.id.state_spinner);



        address_id = (AdrTextView) findViewById(R.id.address_id);
        edt_name = (AdrEditText) findViewById(R.id.edt_name);
        edt_mobile_no = (AdrEditText) findViewById(R.id.edt_mobile_no);
        edt_pincode = (AdrEditText) findViewById(R.id.edt_pincode);
        edt_address1 = (AdrEditText) findViewById(R.id.edt_address1);
        edt_address2 = (AdrEditText) findViewById(R.id.edt_address2);
        edt_address3 = (AdrEditText) findViewById(R.id.edt_address3);
        auto_city = (AutoCompleteTextView) findViewById(R.id.auto_city);
        saveforlater_chkbox = (CheckBox) findViewById(R.id.saveforlater_chkbox);

        add_btn = (FButton) findViewById(R.id.add_btn);



        //mRecyclerview.setNestedScrollingEnabled(false);
    }

    @Override
    public void setToViews() {
        super.setToViews();

        ArrayAdapter<String> countryAdapter = new CustomArrayAdapter(AddressBookAcitvity.this, R.layout.spinner_layout, country_arr);
        countryAdapter.setDropDownViewResource(R.layout.spinner_dropdown_layout);
        county_spinner.setAdapter(countryAdapter);

        ArrayAdapter<String> stateAdapter = new CustomArrayAdapter(AddressBookAcitvity.this, R.layout.spinner_layout, getResources().getStringArray(R.array.india_states));
        stateAdapter.setDropDownViewResource(R.layout.spinner_dropdown_layout);
        state_spinner.setAdapter(stateAdapter);

       String city_str = Constant.readTextFile(AddressBookAcitvity.this,R.raw.cities_name_list);
        try {


            JSONArray jsonArray = new JSONArray(city_str);
             city_arr = toStringArray(jsonArray);


        } catch (Exception e) {
            Log.e(Constant.TAG,"Exception "+e);
        }

        ArrayAdapter<String> cityAdapter = new CustomArrayAdapter(AddressBookAcitvity.this, R.layout.spinner_layout, city_arr);
        auto_city.setAdapter(cityAdapter);

    }


    @Override
    public void clickToViews() {
        super.clickToViews();

        add_new_address_btn_RL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!ischeckout) {

                    show_address_RL.setVisibility(View.GONE);
                    add_new_address_RL.setVisibility(View.VISIBLE);
                    isNewAddress = true;

                } else
                {
                   finish();
                }

            }
        });

        add_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

               if(isNewAddress && ischeckout)
               {


                   int address_id_int = Integer.parseInt(address_id.getText().toString());
                   String name = edt_name.getText().toString();
                   String mobile_no = edt_mobile_no.getText().toString();
                   String address1 = edt_address1.getText().toString();
                   String address2 = edt_address2.getText().toString();
                   String address3 = "";//edt_address3.getText().toString();
                   String city = auto_city.getText().toString();
                   String state = state_spinner.getSelectedItem().toString();
                   String country = county_spinner.getSelectedItem().toString();
                   String pincode = edt_pincode.getText().toString();


                   AddressWrapper wrapper = new AddressWrapper();

                   wrapper.setId(address_id_int);
                   wrapper.setName(name);
                   wrapper.setMobile_no(mobile_no);
                   wrapper.setAddress1(address1);
                   wrapper.setAddress2(address2);
                   wrapper.setAddress3(address3);
                   wrapper.setPincode(pincode);
                   wrapper.setCity(city);
                   wrapper.setState(state);
                   wrapper.setCountry(country);


                   Intent intent = new Intent(AddressBookAcitvity.this, ConfirmOrderActivty.class);
                   Bundle bundle = new Bundle();
                   if (saveforlater_chkbox.isChecked()) {

                       int theLastKey = new ArrayList<>(linkedHashMap.keySet()).get(linkedHashMap.size() - 1);
                       linkedHashMap.put(theLastKey+1,wrapper);
                       bundle.putParcelable("selected_address",wrapper);
                       Log.v(Constant.TAG,"ADDRESS DATA "+wrapper.getName());
                   }
                   else
                   {

                   }
                   bundle.putInt("cart_count",cart_count);
                   bundle.putString("total_cart_amount",total_cart_amount);
                   intent.putExtras(bundle);
                   startActivityForResult(intent,Constant.NORMAL);
                   finish();



               }
               else  if(isNewAddress && !ischeckout)
               {
                   int address_id_int = Integer.parseInt(address_id.getText().toString());
                   String name = edt_name.getText().toString();
                   String mobile_no = edt_mobile_no.getText().toString();
                   String address1 = edt_address1.getText().toString();
                   String address2 = edt_address2.getText().toString();
                   String address3 = "";//edt_address3.getText().toString();
                   String city = auto_city.getText().toString();
                   String state = state_spinner.getSelectedItem().toString();
                   String country = county_spinner.getSelectedItem().toString();
                   String pincode = edt_pincode.getText().toString();


                   AddressWrapper wrapper = new AddressWrapper();

                   wrapper.setId(address_id_int);
                   wrapper.setName(name);
                   wrapper.setMobile_no(mobile_no);
                   wrapper.setAddress1(address1);
                   wrapper.setAddress2(address2);
                   wrapper.setAddress3(address3);
                   wrapper.setPincode(pincode);
                   wrapper.setCity(city);
                   wrapper.setState(state);
                   wrapper.setCountry(country);



                   int theLastKey = new ArrayList<>(linkedHashMap.keySet()).get(linkedHashMap.size() - 1);
                   linkedHashMap.put(theLastKey+1,wrapper);


                   show_address_RL.setVisibility(View.VISIBLE);
                   add_new_address_RL.setVisibility(View.GONE);
                   setRecyclerAdapter();
               }
               else if(!isNewAddress && ischeckout)
               {

                   int address_id_int = Integer.parseInt(address_id.getText().toString());
                   String name = edt_name.getText().toString();
                   String mobile_no = edt_mobile_no.getText().toString();
                   String address1 = edt_address1.getText().toString();
                   String address2 = edt_address2.getText().toString();
                   String address3 = "";//edt_address3.getText().toString();
                   String city = auto_city.getText().toString();
                   String state = state_spinner.getSelectedItem().toString();
                   String country = county_spinner.getSelectedItem().toString();
                   String pincode = edt_pincode.getText().toString();


                 AddressWrapper wrapper = new AddressWrapper();

                   wrapper.setId(address_id_int);
                   wrapper.setName(name);
                   wrapper.setMobile_no(mobile_no);
                   wrapper.setAddress1(address1);
                   wrapper.setAddress2(address2);
                   wrapper.setAddress3(address3);
                   wrapper.setPincode(pincode);
                   wrapper.setCity(city);
                   wrapper.setState(state);
                   wrapper.setCountry(country);

                   linkedHashMap.put(address_id_int,wrapper);


                   if(ischeckout)
                   {

                       Intent intent = new Intent(AddressBookAcitvity.this,CheckoutActivity.class);
                       Bundle bundle = new Bundle();
                       bundle.putInt("cart_count",cart_count);
                       bundle.putString("total_cart_amount",""+total_cart_amount);
                       intent.putExtras(bundle);
                       intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                       startActivityForResult(intent,Constant.NORMAL);
                       finish();
                   }
                   else
                   {
                       show_address_RL.setVisibility(View.VISIBLE);
                       add_new_address_RL.setVisibility(View.GONE);
                       setRecyclerAdapter();
                   }

               }


             //finish();

            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }

    public void setRecyclerAdapter()
    {


        adapter = new AddressRecyclerViewAdapter(AddressBookAcitvity.this,linkedHashMap, mListener);

        LinearLayoutManager mLayoutManager = new LinearLayoutManager(AddressBookAcitvity.this);
        mRecyclerview.setLayoutManager(mLayoutManager);
        mRecyclerview.addItemDecoration(new SimpleDividerItemDecoration(AddressBookAcitvity.this));
        mRecyclerview.setAdapter(adapter);

        adapter.notifyDataSetChanged();


        mRecyclerview.addOnItemTouchListener(new RecyclerView.OnItemTouchListener() {
            @Override
            public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {
                int action = e.getAction();
                switch (action) {
                    case MotionEvent.ACTION_MOVE:
                        rv.getParent().requestDisallowInterceptTouchEvent(true);
                        break;
                }
                return false;
            }

            @Override
            public void onTouchEvent(RecyclerView rv, MotionEvent e) {

            }

            @Override
            public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

            }
        });

        /*adapter.SetOnItemClickListener(new AddressRecyclerViewAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {

                Log.v(Constant.TAG,"onClick Called");
                Intent intent = new Intent(AddressBookAcitvity.this, ProductDetailActivity.class);
                startActivityForResult(intent,Constant.NORMAL);
            }
        });*/



    }

    public LinkedHashMap parseJsonData(int resourceid)
    {
        LinkedHashMap linkedHashMap = new LinkedHashMap();


        String Json_String = null;
        try {

            Json_String = Constant.readTextFile(AddressBookAcitvity.this,resourceid);

            JSONObject jsonObject = new JSONObject(Json_String);
            String status = jsonObject.getString("status");
            if(status.equalsIgnoreCase("success"))
            {
                JSONArray jsonArray = jsonObject.getJSONArray("data");

                for(int i=0;i <jsonArray.length();i++)
                {
                    JSONObject arr_object = jsonArray.getJSONObject(i);

                    //String group_id = arr_object.getString("group_id");
                    //String itemid = arr_object.getString("item_id");
                    //String unique_id = group_id+"_"+itemid;

                    AddressWrapper wrapper = new AddressWrapper();
                    int Id = (arr_object.getInt("id"));
                    wrapper.setId(arr_object.getInt("id"));
                    wrapper.setName(arr_object.getString("name"));
                    wrapper.setMobile_no(arr_object.getString("mobile_no"));
                    wrapper.setAddress1(arr_object.getString("address1"));
                    wrapper.setAddress2(arr_object.getString("address2"));
                    wrapper.setAddress3(arr_object.getString("address3"));
                    wrapper.setPincode(arr_object.getString("pincode"));
                    wrapper.setCity(arr_object.getString("city"));
                    wrapper.setState(arr_object.getString("state"));
                    wrapper.setCountry(arr_object.getString("country"));

                    linkedHashMap.put(Id,wrapper);

                }
            }


        } catch (Exception e) {
            Log.e(Constant.TAG,"Exception",e);
        }

        return linkedHashMap;
    }

    public void EditAddress(AddressWrapper addressWrapper,boolean ischeckout)
    {
        show_address_RL.setVisibility(View.GONE);
        add_new_address_RL.setVisibility(View.VISIBLE);


        ArrayAdapter<String> countryAdapter = new CustomArrayAdapter(AddressBookAcitvity.this, R.layout.spinner_layout, country_arr);
        countryAdapter.setDropDownViewResource(R.layout.spinner_dropdown_layout);
        county_spinner.setAdapter(countryAdapter);

        ArrayAdapter<String> stateAdapter = new CustomArrayAdapter(AddressBookAcitvity.this, R.layout.spinner_layout, getResources().getStringArray(R.array.india_states));
        stateAdapter.setDropDownViewResource(R.layout.spinner_dropdown_layout);
        state_spinner.setAdapter(stateAdapter);


        String compareValue = addressWrapper.getState();
        int spinnerPosition = stateAdapter.getPosition(compareValue);
        state_spinner.setSelection(spinnerPosition);

        address_id.setText(""+addressWrapper.getId());
        edt_name.setText(addressWrapper.getName());
        edt_mobile_no.setText(addressWrapper.getMobile_no());
        edt_address1.setText(addressWrapper.getAddress1());
        edt_address2.setText(addressWrapper.getAddress2());
        edt_address3.setText(addressWrapper.getAddress3());
        edt_pincode.setText(addressWrapper.getPincode());
        auto_city.setText(addressWrapper.getCity());


    }

    @Override
    public void onBackPressed() {

        if(add_new_address_RL.getVisibility() == View.VISIBLE)
        {
            show_address_RL.setVisibility(View.VISIBLE);
            add_new_address_RL.setVisibility(View.GONE);
        }
        else
        super.onBackPressed();
    }

    public static String[] toStringArray(JSONArray array) {
        if(array==null)
            return null;

        String[] arr=new String[array.length()];
        for(int i=0; i<arr.length; i++) {
            arr[i]=array.optString(i);
        }
        return arr;
    }

    public void deleteAddress(AddressWrapper wrapper)
    {
        int indexOfTempInShopingList = (wrapper.getId());
        linkedHashMap.remove(indexOfTempInShopingList);

        setRecyclerAdapter();
    }


}
