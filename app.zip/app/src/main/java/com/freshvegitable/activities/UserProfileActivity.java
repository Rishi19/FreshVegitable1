package com.freshvegitable.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.freshvegitable.BaseActivity;
import com.freshvegitable.R;
import com.freshvegitable.utils.RoundedImageView;

import adrViews.AdrTextViewMed;

public class UserProfileActivity extends BaseActivity {

    RoundedImageView profile_userPhoto;
    AdrTextViewMed profile_userName, profile_userEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);


        initViews();
        setToViews();
        clickToViews();


    }

    @Override
    public void initViews() {
        super.initViews();

       /* profile_userPhoto = (RoundedImageView)findViewById(R.id.profile_userPhoto);
        profile_userName = (AdrTextViewMed) findViewById(R.id.profile_userName);
        profile_userEmail = (AdrTextViewMed) findViewById(R.id.profile_userEmail);*/


    }

    @Override
    public void setToViews() {
        super.setToViews();


    }

    @Override
    public void clickToViews() {
        super.clickToViews();


    }
}
