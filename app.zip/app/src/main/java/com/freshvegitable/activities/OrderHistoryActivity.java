package com.freshvegitable.activities;

import android.content.Context;
import android.content.Intent;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.freshvegitable.Adapter.OrderHistoryRecyclerAdapter;
import com.freshvegitable.BaseActivity;
import com.freshvegitable.R;
import com.freshvegitable.Wrappers.OrderDetails_Wrapper;
import com.freshvegitable.Wrappers.Vegitable_Wrapper;
import com.freshvegitable.fragments.OrderHistoryListFragment;
import com.freshvegitable.fragments.OrderHistorydetailfragment;
import com.freshvegitable.interfaces.OnFragmentInteractionListener;
import com.freshvegitable.model.CenterRepository;
import com.freshvegitable.model.entities.Money;
import com.freshvegitable.utils.Constant;
import com.freshvegitable.utils.SimpleDividerItemDecoration;

import org.json.JSONArray;
import org.json.JSONObject;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.LinkedHashMap;

import adrViews.AdrTextViewMed;

public class OrderHistoryActivity extends BaseActivity {

    OrderHistoryRecyclerAdapter adapter;
    RecyclerView mRecyclerview;
    Context context;
    int itemCount_cart = 0,fragmnt_position = 0;
    private OnFragmentInteractionListener mListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_order_history);
        context = getBaseContext();

        initViews();
        setToViews();
        clickToViews();
        //setRecyclerAdapter();
        setFragment(0,null);

    }

    @Override
    public void onResume() {
        super.onResume();

        updateCart();

    }

    @Override
    public void initViews() {
        super.initViews();


    }

    @Override
    public void setToViews() {
        super.setToViews();

    }

    @Override
    public void clickToViews() {
        super.clickToViews();



    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


    }

    public void setRecyclerAdapter()
    {


        adapter = new OrderHistoryRecyclerAdapter(OrderHistoryActivity.this,parseJsonData(R.raw.order_history), mListener);

        LinearLayoutManager mLayoutManager = new LinearLayoutManager(context);
        mRecyclerview.setLayoutManager(mLayoutManager);
        mRecyclerview.addItemDecoration(new SimpleDividerItemDecoration(context));
        mRecyclerview.setAdapter(adapter);

        adapter.notifyDataSetChanged();

        adapter.SetOnItemClickListener(new OrderHistoryRecyclerAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {

                Log.v(Constant.TAG,"onClick Called");
                setFragment(1,adapter.getWrapper(position));

            }
        });



    }

    public void updateItemCount(int quentity,boolean ifIncrement) {
        if (ifIncrement) {

            int itemCount  = CenterRepository.getCenterRepository().getItemCount()+quentity;
            CenterRepository.getCenterRepository().setItemCount(itemCount);
            ((TextView)findViewById(R.id.item_count)).setText(String.valueOf(itemCount));

        } else {

            if (CenterRepository.getCenterRepository().getItemCount() > 0) {
                int itemCount  = CenterRepository.getCenterRepository().getItemCount()-quentity;
                CenterRepository.getCenterRepository().setItemCount(itemCount);
                ((TextView)findViewById(R.id.item_count)).setText(String.valueOf(itemCount));
            }

            //temCountTextView.setText(String.valueOf(itemCount <= 0 ? 0: --itemCount));
        }

        toggleBannerVisibility();
    }

    public void toggleBannerVisibility() {
       /* if (itemCount == 0) {

            findViewById(R.id.checkout_item_root).setVisibility(View.GONE);
            findViewById(R.id.new_offers_banner).setVisibility(View.VISIBLE);

        } else {
            findViewById(R.id.checkout_item_root).setVisibility(View.VISIBLE);
            findViewById(R.id.new_offers_banner).setVisibility(View.GONE);
        }*/
    }

    public void updateCheckOutAmount(BigDecimal amount, int quentity , boolean increment) {

        BigDecimal checkoutAmount = CenterRepository.getCenterRepository().getCheckoutAmount();
        if (increment) {

            checkoutAmount = checkoutAmount.add(amount.multiply(new BigDecimal(quentity)));

        } else {

            //if (checkoutAmount.signum() == 1)
            if(checkoutAmount.compareTo(new BigDecimal(BigInteger.ZERO)) == 1)
                checkoutAmount = checkoutAmount.subtract(amount);
        }

        CenterRepository.getCenterRepository().setCheckoutAmount(checkoutAmount);
        ((AdrTextViewMed)findViewById(R.id.text)).setText(Money.rupees(checkoutAmount).toString());
    }

    public void checkOut()
    {

    }




    public LinkedHashMap parseJsonData(int resourceid)
    {
        LinkedHashMap linkedHashMap = new LinkedHashMap();


        String Json_String = null;
        try {

            Json_String = Constant.readTextFile(OrderHistoryActivity.this,resourceid);

            JSONObject jsonObject = new JSONObject(Json_String);
            String status = jsonObject.getString("status");
            if(status.equalsIgnoreCase("success"))
            {
                JSONArray jsonArray = jsonObject.getJSONArray("data");

                for(int i=0;i <jsonArray.length();i++)
                {
                    JSONObject arr_object = jsonArray.getJSONObject(i);

                    String group_id = arr_object.getString("group_id");
                    String itemid = arr_object.getString("item_id");
                    String unique_id = group_id+"_"+itemid;

                    Vegitable_Wrapper wrapper = new Vegitable_Wrapper();
                    wrapper.setGroup_id(arr_object.getString("group_id"));
                    wrapper.setItem_id(itemid);
                    wrapper.setGroup_name(arr_object.getString("group_name"));
                    wrapper.setItem_name(arr_object.getString("name"));
                    wrapper.setDescription(arr_object.getString("description"));
                    wrapper.setIcon(arr_object.getString("icon"));
                    wrapper.setPrice(arr_object.getString("price"));
                    wrapper.setQuentity_type(arr_object.getString("quentity_type"));
                    wrapper.setMaximum_order(arr_object.getString("maximum_order_limit"));

                    linkedHashMap.put(unique_id,wrapper);

                }
            }


        } catch (Exception e) {
            Log.e(Constant.TAG,"Exception",e);
        }

        return linkedHashMap;
    }
    public Fragment getCurrentFragment()
    {
        Fragment f = null;
        f = getSupportFragmentManager().findFragmentById(R.id.container);

        return f;
    }

    public void setFragment(int fragment_number, OrderDetails_Wrapper wrapper)
    {
        Fragment mFragment = null;
        FragmentManager mFragmentManager = getSupportFragmentManager();
        Fragment currentFragment = getCurrentFragment();
        String tag = "0";
        if (currentFragment != null) {
            tag = currentFragment.getTag();
        }


        if (fragment_number == 0)
            mFragment = OrderHistoryListFragment.newInstance(""+fragment_number,"");
        else
            mFragment = OrderHistorydetailfragment.newInstance(""+fragment_number,wrapper);


        if (mFragment != null)

        {
            if (fragment_number == 0) {
                mFragmentManager.beginTransaction().add(R.id.container, mFragment, ""+fragment_number)/*.addToBackStack("Home_Fragmemt")*/.commit();
            } else
                mFragmentManager.beginTransaction().replace(R.id.container, mFragment, ""+fragment_number).addToBackStack("my_fragment").commit();


            fragmnt_position = fragment_number;
        }
    }

    @Override
    public void onBackPressed() {

        FragmentManager fm = getSupportFragmentManager();
        int count = fm.getBackStackEntryCount();
        if (count > 0)
        {
            fm.popBackStack();
        }
        else
        super.onBackPressed();


    }
}
