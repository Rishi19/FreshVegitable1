package com.freshvegitable.activities;

import android.graphics.Color;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.freshvegitable.Adapter.CustomArrayAdapter;
import com.freshvegitable.Adapter.ExamplePagerAdapter;
import com.freshvegitable.BaseActivity;
import com.freshvegitable.R;
import com.freshvegitable.ViewPagerIndicator.MagicIndicator;
import com.freshvegitable.ViewPagerIndicator.ViewPagerHelper;
import com.freshvegitable.ViewPagerIndicator.autoscroll.AutoScrollViewPager;
import com.freshvegitable.ViewPagerIndicator.circlenavigator.CircleNavigator;

import java.util.Arrays;
import java.util.List;

public class ProductDetailActivity extends BaseActivity {

    private static final String[] CHANNELS = new String[]{"CUPCAKE", "DONUT", "ECLAIR", "GINGERBREAD", "HONEYCOMB", "ICE_CREAM_SANDWICH", "JELLY_BEAN", "KITKAT", "LOLLIPOP", "M", "NOUGAT"};
    private List<String> mDataList = Arrays.asList(CHANNELS);
    private ExamplePagerAdapter mExamplePagerAdapter = new ExamplePagerAdapter(mDataList);
    ViewPager mViewPager;
    ProductDetailActivity activity;
    String numberArr [] = new String[]{"1","2","3","4","5","6","7","8","9"};

    Spinner spinner;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_detail);

        initViews();
        setToViews();
        clickToViews();
        setAdapter();




    }

    @Override
    public void initViews() {
        super.initViews();

        activity = ProductDetailActivity.this;
        mViewPager = (ViewPager) findViewById(R.id.detailImage_viewpager);
        spinner = (Spinner)findViewById(R.id.spinner);
    }

    @Override
    public void setToViews() {
        super.setToViews();

        ArrayAdapter<String> segmentAdapter = new CustomArrayAdapter(activity, R.layout.spinner_layout, numberArr);
        segmentAdapter.setDropDownViewResource(R.layout.spinner_dropdown_layout);
        spinner.setAdapter(segmentAdapter);


    }

    @Override
    public void clickToViews() {
        super.clickToViews();


    }

    public void setAdapter() {
        mViewPager.setAdapter(mExamplePagerAdapter);
        initMagicIndicator1();
       // mViewPager.startAutoScroll();

        //initMagicIndicator3();
    }

    private void initMagicIndicator1() {
        MagicIndicator magicIndicator = (MagicIndicator) findViewById(R.id.magic_indicator3);
        CircleNavigator circleNavigator = new CircleNavigator(this);
        circleNavigator.setCircleCount(CHANNELS.length);
        circleNavigator.setCircleColor(Color.RED);
        circleNavigator.setCircleClickListener(new CircleNavigator.OnCircleClickListener() {
            @Override
            public void onClick(int index) {
                mViewPager.setCurrentItem(index);
            }
        });
        magicIndicator.setNavigator(circleNavigator);
        ViewPagerHelper.bind(magicIndicator, mViewPager);
    }
}
