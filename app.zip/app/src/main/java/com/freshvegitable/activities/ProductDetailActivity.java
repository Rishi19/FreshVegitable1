package com.freshvegitable.activities;

import android.content.Intent;
import android.graphics.Color;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import com.freshvegitable.Adapter.CustomArrayAdapter;
import com.freshvegitable.Adapter.ExamplePagerAdapter;
import com.freshvegitable.BaseActivity;
import com.freshvegitable.R;
import com.freshvegitable.ViewPagerIndicator.MagicIndicator;
import com.freshvegitable.ViewPagerIndicator.ViewPagerHelper;
import com.freshvegitable.ViewPagerIndicator.autoscroll.AutoScrollViewPager;
import com.freshvegitable.ViewPagerIndicator.circlenavigator.CircleNavigator;
import com.freshvegitable.model.CenterRepository;
import com.freshvegitable.model.entities.Product;
import com.freshvegitable.utils.Constant;
import com.freshvegitable.utils.FButton;

import java.util.Arrays;
import java.util.List;

public class ProductDetailActivity extends BaseActivity {

    private static final String[] CHANNELS = new String[]{"CUPCAKE", "DONUT", "ECLAIR", "GINGERBREAD", "HONEYCOMB", "ICE_CREAM_SANDWICH", "JELLY_BEAN", "KITKAT", "LOLLIPOP", "M", "NOUGAT"};
    private List<String> mDataList = Arrays.asList(CHANNELS);
    private ExamplePagerAdapter mExamplePagerAdapter = new ExamplePagerAdapter(mDataList);
    ViewPager mViewPager;
    ProductDetailActivity activity;
    String numberArr [] = new String[]{"1","2","3","4","5","6","7","8","9"};

    Spinner spinner;
    Product product_wrapper;
    TextView price;
    FButton add_btn;
    Spinner spinner_quantity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_detail);

        Bundle bundle  = getIntent().getExtras();
        if(bundle != null)
        {
            product_wrapper  = (Product) bundle.getParcelable("product_wrapper");
        }


        initViews();
        setToViews();
        clickToViews();
        setAdapter();

    }

    @Override
    public void onResume() {
        super.onResume();

        updateCart();

    }

    @Override
    public void initViews() {
        super.initViews();

        activity = ProductDetailActivity.this;
        mViewPager = (ViewPager) findViewById(R.id.detailImage_viewpager);
        spinner_quantity = (Spinner)findViewById(R.id.spinner_quantity);
        price = (TextView)findViewById(R.id.price);
        add_btn = (FButton)findViewById(R.id.add_btn);
    }

    @Override
    public void setToViews() {
        super.setToViews();

        ArrayAdapter<String> segmentAdapter = new CustomArrayAdapter(activity, R.layout.spinner_layout, numberArr);
        segmentAdapter.setDropDownViewResource(R.layout.spinner_dropdown_layout);
        spinner_quantity.setAdapter(segmentAdapter);


    }

    @Override
    public void clickToViews() {
        super.clickToViews();


        add_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                //if current object is lready in shopping list
                if (CenterRepository.getCenterRepository().getListOfProductsInShoppingList().contains(product_wrapper))
                {


                    //get position of current item in shopping list
                    int indexOfTempInShopingList = CenterRepository.getCenterRepository().getListOfProductsInShoppingList()
                            .indexOf(product_wrapper);

                    // increase quantity of current item in shopping list
                          /*  if (Integer.parseInt(tempObj.getQuantity()) == 0)
                            {

                                ((VegitableActivity) getContext()).updateItemCount(true);

                            }*/


                    String quentity_str = (String)spinner_quantity.getSelectedItem();
                    int quentity = Integer.parseInt(quentity_str);
                    Log.v(Constant.TAG,"quentity "+quentity);

                    // update quanity in shopping list
                    CenterRepository
                            .getCenterRepository()
                            .getListOfProductsInShoppingList()
                            .get(indexOfTempInShopingList)
                            .setQuantity(
                                    String.valueOf(Integer
                                            .valueOf(product_wrapper
                                                    .getQuantity()) + quentity));


                    //update checkout amount
                            /*((VegitableActivity) getContext()).updateCheckOutAmount(BigDecimal.valueOf(Long
                                    .valueOf(tempObj.getSellMRP())), quentity, true);

                            ((VegitableActivity) getContext()).updateItemCount(quentity,true);
*/
                    updateCart();

                    // update current item quanitity
                    //holder.quanitity.setText(tempObj.getQuantity());

                } else {


                    String quentity_str = (String)spinner_quantity.getSelectedItem();
                    int quentity = Integer.parseInt(quentity_str);



                    product_wrapper.setQuantity(String.valueOf(quentity));

                    // holder.quanitity.setText(tempObj.getQuantity());

                    CenterRepository.getCenterRepository()
                            .getListOfProductsInShoppingList().add(product_wrapper);


                    updateCart();

                            /*((VegitableActivity) getContext()).updateCheckOutAmount(
                                    BigDecimal
                                            .valueOf(Long
                                                    .valueOf(productList
                                                            .get(position)
                                                            .getSellMRP())), quentity ,
                                    true);

                            ((VegitableActivity) getContext()).updateItemCount(quentity,true);*/

                }

                Constant.vibrate(ProductDetailActivity.this);


            }
        });

/*
        spinner_quantity.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {


                Log.v(Constant.TAG,"position "+position);


                if (CenterRepository.getCenterRepository().getListOfProductsInShoppingList().contains(product_wrapper)) {

                    int indexOfTempInShopingList = CenterRepository
                            .getCenterRepository().getListOfProductsInShoppingList()
                            .indexOf(product_wrapper);

                    String quentity_str = (String) spinner_quantity.getSelectedItem();
                    int quentity = Integer.parseInt(quentity_str);

                    //((CartActivity) getContext()).updateItemCount(quentity, false);


                    if (Integer.valueOf(product_wrapper.getQuantity()) != 0) {

                        CenterRepository
                                .getCenterRepository()
                                .getListOfProductsInShoppingList()
                                .get(indexOfTempInShopingList)
                                .setQuantity(
                                        String.valueOf(Integer.valueOf(quentity_str)));

                       */
/* ((CartActivity) getContext()).updateCheckOutAmount(
                                BigDecimal.valueOf(Long.valueOf(product.getSellMRP())), quentity,
                                false);*//*


                        updateCart();
                        //((CartActivity) getContext()).changeCartValue();
                                          */
/*  holder.quanitity.setText(CenterRepository
                                                    .getCenterRepository().getListOfProductsInShoppingList()
                                                    .get(indexOfTempInShopingList).getQuantity());*//*


                        Constant.vibrate(ProductDetailActivity.this);

                        // Not in Use
                        if (Integer.valueOf(CenterRepository
                                .getCenterRepository().getListOfProductsInShoppingList()
                                .get(indexOfTempInShopingList).getQuantity()) == 0) {

                            CenterRepository.getCenterRepository()
                                    .getListOfProductsInShoppingList()
                                    .remove(indexOfTempInShopingList);

                           // notifyDataSetChanged();


                        }

                    }


                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
*/

    }

    public void setAdapter() {
        mViewPager.setAdapter(mExamplePagerAdapter);
        initMagicIndicator1();
       // mViewPager.startAutoScroll();

        //initMagicIndicator3();
    }

    private void initMagicIndicator1() {
        MagicIndicator magicIndicator = (MagicIndicator) findViewById(R.id.magic_indicator3);
        CircleNavigator circleNavigator = new CircleNavigator(this);
        circleNavigator.setCircleCount(CHANNELS.length);
        circleNavigator.setCircleColor(Color.RED);
        circleNavigator.setCircleClickListener(new CircleNavigator.OnCircleClickListener() {
            @Override
            public void onClick(int index) {
                mViewPager.setCurrentItem(index);
            }
        });
        magicIndicator.setNavigator(circleNavigator);
        ViewPagerHelper.bind(magicIndicator, mViewPager);
    }
}
