/**
 * 
 */
package com.freshvegitable.model.entities;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * The Class Product used as model for Products.
 *
 * @author Hitesh
 */
public class Product implements Parcelable {


	/** The item short desc. */
	private String description = "";

	/** The item detail. */
	private String longDescription = "";

	/** The mrp. */
	private String mrp;

	/** The discount. */
	private String discount;

	/** The sell mrp. */
	private String salePrice;

	/** The quantity. */
	private String orderQty;

	/** The image url. */
	private String imageUrl = "";

	/** The item name. */
	private String productName = "";

	private String productId = "";

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	/**
	 * @param itemName
	 * @param itemShortDesc
	 * @param itemDetail
	 * @param MRP
	 * @param discount
	 * @param sellMRP
	 * @param quantity
	 * @param imageURL
	 */
	public Product(String itemName, String itemShortDesc, String itemDetail,
                   String MRP, String discount, String sellMRP, String quantity,
                   String imageURL, String orderId) {
		this.productName = itemName;
		this.description = itemShortDesc;
		this.longDescription = itemDetail;
		this.mrp = MRP;
		this.discount = discount;
		this.salePrice = sellMRP;
		this.orderQty = quantity;
		this.imageUrl = imageURL;
		this.productId = orderId;
	}

	public String getItemName() {
		return productName;
	}

	public void setItemName(String itemName) {
		this.productName = itemName;
	}

	public String getItemShortDesc() {
		return description;
	}

	public void setItemShortDesc(String itemShortDesc) {
		this.description = itemShortDesc;
	}

	public String getItemDetail() {
		return longDescription;
	}

	public void setItemDetail(String itemDetail) {
		this.longDescription = itemDetail;
	}

	public String getMRP() {
		return this.mrp;
	}

	public void setMRP(String MRP) {
		this.mrp = MRP;
	}

	public String getDiscount() {
		return discount + "%";
	}

	public String getDiscountNumeric() {
		return discount;
	}

	public void setDiscount(String discount) {
		this.discount = discount;
	}

	public String getSellMRP() {
		return salePrice;
	}

	public void setSellMRP(String sellMRP) {
		this.salePrice = sellMRP;
	}

	public String getQuantity() {
		return orderQty;
	}

	public void setQuantity(String quantity) {
		this.orderQty = quantity;
	}

	public String getImageURL() {
		return imageUrl;
	}

	public void setImageURL(String imageURL) {
		this.imageUrl = imageURL;
	}

	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeString(this.description);
		dest.writeString(this.longDescription);
		dest.writeString(this.mrp);
		dest.writeString(this.discount);
		dest.writeString(this.salePrice);
		dest.writeString(this.orderQty);
		dest.writeString(this.imageUrl);
		dest.writeString(this.productName);
		dest.writeString(this.productId);
	}

	protected Product(Parcel in) {
		this.description = in.readString();
		this.longDescription = in.readString();
		this.mrp = in.readString();
		this.discount = in.readString();
		this.salePrice = in.readString();
		this.orderQty = in.readString();
		this.imageUrl = in.readString();
		this.productName = in.readString();
		this.productId = in.readString();
	}

	public static final Creator<Product> CREATOR = new Creator<Product>() {
		@Override
		public Product createFromParcel(Parcel source) {
			return new Product(source);
		}

		@Override
		public Product[] newArray(int size) {
			return new Product[size];
		}
	};
}
