package com.freshvegitable;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.support.design.internal.ScrimInsetsFrameLayout;
import android.support.design.widget.CoordinatorLayout;
import android.support.v4.app.FragmentActivity;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;


import com.freshvegitable.Wrappers.MenuDrawer_Wrapper;
import com.freshvegitable.activities.CartActivity;
import com.freshvegitable.activities.LoginActivity;
import com.freshvegitable.interfaces.Views;
import com.freshvegitable.model.CenterRepository;
import com.freshvegitable.model.entities.Money;
import com.freshvegitable.model.entities.Product;
import com.freshvegitable.utils.Constant;
import com.freshvegitable.utils.DrawerArrowDrawable;
import com.freshvegitable.utils.RootUtil;


import java.io.File;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import adrViews.AdrTextViewMed;

import static com.freshvegitable.utils.RootUtil.isRooted;

public class BaseActivity extends FragmentActivity implements Views
{
    //public RelativeLayout mRelativeLayout;
    public FrameLayout actContent;
    public ListView navList;
    LinearLayout drawer_List,menu_LL;
    TextView text_emp_name;
    public MenuDrawerAdapter menuDrawerAdapter;
    public ArrayList<MenuDrawer_Wrapper> menuDrawerList = new ArrayList<>();
    public DrawerArrowDrawable drawerArrowDrawable;
    public ImageView drawer_indicator;
    public DrawerLayout drawer_layout;
    public float offset;
    public boolean flipped;
    LinearLayout drawer_indicator_LL;
    ScrimInsetsFrameLayout scriminsetrelativeDrawer;
    CoordinatorLayout coordinatorLayout;
    Toolbar toolbar;
    AdrTextViewMed heading_txt;
    ImageView menu_icon;
    FrameLayout item_counter;

    final String[] navDrawMenuItems = {"Search" , "Edit", "Logout", "Camera" ,"Timer"};
    final int[] navDrawMenuIcons = {R.drawable.search,
            R.drawable.edit,
            R.drawable.log_icon,
            R.drawable.camera1,
            R.drawable.duration_icon,

    };

    SharedPreferences _SP;
    SharedPreferences.Editor _EDITOR;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        for (int i = 0; i < navDrawMenuItems.length; i++)
        {
            menuDrawerList.add(new MenuDrawer_Wrapper(""+i,navDrawMenuItems[i], navDrawMenuIcons[i]));
        }

        if(isRooted() || RootUtil.isDeviceRooted(this))
        {
            Constant.showToastLong(getApplicationContext(), "Device is Rooted! Please use an unrooted device");
            finish();
        }

        if(RootUtil.isAndroidEmulator())
        {
            Constant.showToastLong(getApplicationContext(), "Device is an emulator! Please use an android device");
            finish();
        }



        File dir = new File(Environment.getExternalStorageDirectory() + "/Download");
        if(dir.exists() && dir.isDirectory())
        {
            dir.mkdir();
        }

    }

    @Override
    public void setContentView(int layoutResID)

    {
        coordinatorLayout = (CoordinatorLayout) getLayoutInflater().inflate(R.layout.activity_base, null);
        actContent = (FrameLayout) coordinatorLayout.findViewById(R.id.main);
        // set the drawer dialog_view as main content view of Activity.
        setContentView(coordinatorLayout);
        // add dialog_view of BaseActivities inside framelayout.i.e. frame_container
        getLayoutInflater().inflate(layoutResID, actContent, true);

        drawer_layout = (DrawerLayout) findViewById(R.id.drawer_layout);
        // =========================================


        //text_emp_name=(TextView)findViewById(R.id.text_emp_name) ;
        _SP = getSharedPreferences(Constant.TAG, MODE_PRIVATE);

        //text_emp_name.setText(_SP.getString("empName",""));
        //scriminsetrelativeDrawer=(LinearLayout)findViewById(R.id.scriminsetrelativeDrawer);
        scriminsetrelativeDrawer=(ScrimInsetsFrameLayout) findViewById(R.id.scriminsetrelativeDrawer);
        navList = (ListView) findViewById(R.id.drawer_List1);
        menuDrawerAdapter = new MenuDrawerAdapter(BaseActivity.this, menuDrawerList);
        navList.setAdapter(menuDrawerAdapter);


        toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setContentInsetsAbsolute(0,0);
        LayoutInflater mInflater= LayoutInflater.from(this);
        View mCustomView = mInflater.inflate(R.layout.inflate_header_view, null);

        heading_txt = (AdrTextViewMed) mCustomView.findViewById(R.id.text);
        menu_LL = (LinearLayout) mCustomView.findViewById(R.id.menu_LL);
        menu_icon = (ImageView) mCustomView.findViewById(R.id.menu_icon);
        item_counter = (FrameLayout) mCustomView.findViewById(R.id.item_counter);

        final Resources resources = getResources();
        drawerArrowDrawable = new DrawerArrowDrawable(resources);

        drawer_indicator = (ImageView) mCustomView.findViewById(R.id.drawer_indicator);
        drawerArrowDrawable.setStrokeColor(resources.getColor(android.R.color.white));
        drawer_indicator.setImageDrawable(drawerArrowDrawable);

        // =========================================
        heading_txt.setText("Home");
      /*  heading_txt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                *//*showPopup(heading_txt);
                //onInviteClicked();*//*

                //Intent intent = new Intent(MainActivity.this, FireBaseDemo.class);
                //startActivity(intent);
            }
        });*/

        menu_icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                //showPopup(menu_LL);
            }
        });

        toolbar.addView(mCustomView);
// =========================================


       /* if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            try
            {
                Resources.Theme theme = this.getTheme();
                TypedArray typedArray = theme.obtainStyledAttributes(new int[]{android.R.attr.colorPrimary});
                drawer_layout.setStatusBarBackground(typedArray.getResourceId(0, 0));
            }
            catch (Exception e)
            {
                Log.e(Constant.TAG,"Exception",e);
            }

            //this.setElevationToolBar(mElevationToolBar);

        }*/

        navList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                Intent intent;
                //                Toast.makeText(getApplicationContext(),"position "+position,30).show();
                Log.i(Constant.TAG,"drawer_position: "+position);
                switch (position)
                {
                    case 0:

                        intent = new Intent(BaseActivity.this, LoginActivity.class);
                        startActivityForResult(intent,Constant.NORMAL);
                        //
                        break;

                    case 1:

                        //intent = new Intent(BaseActivity.this, SearchActivity.class);
                        //startActivityForResult(intent,Constant.NORMAL);
                        //drawer_indicator.performClick();

                        break;
                    case 2:
                        //intent = new Intent(BaseActivity.this, SearchActivity.class);
                        //startActivityForResult(intent,Constant.NORMAL);
                        //                        drawer_indicator.performClick();
                        break;

                    case 3:
                        //intent = new Intent(BaseActivity.this, SearchActivity.class);
                        //startActivityForResult(intent,Constant.NORMAL);
                        //                        drawer_indicator.performClick();
                        break;
                    case 4:
                        //intent = new Intent(BaseActivity.this, SearchActivity.class);
                        //intent.putExtra("Type","Complaints");
                        //startActivityForResult(intent,Constant.NORMAL);
                        //                        drawer_indicator.performClick();
                        break;
                    case 5:
                        //intent = new Intent(BaseActivity.this, SearchActivity.class);
                        //intent.putExtra("Type","Suggestions");
                        //startActivityForResult(intent,Constant.NORMAL);
                        break;
                    case 6:
                        //intent = new Intent(BaseActivity.this, SearchActivity.class);
                        //startActivityForResult(intent,Constant.NORMAL);
                        break;
                    case 7:

                        System.out.println("Logout clickedddddd ");
                        SharedPreferences.Editor editor = getSharedPreferences("my_pref", MODE_PRIVATE).edit();
                        editor.clear();
                        editor.commit();
                        setResult(Constant.EXIT);
                        finish();
                        break;

                    default:
                        break;
                }

            }
        });


        initViews();
        setToViews();
        clickToViews();

    }



    public void setMenuDrawer(ArrayList<MenuDrawer_Wrapper> menuDrawerList, String email)
    {
        navList = (ListView) findViewById(R.id.drawer_List1);
        menuDrawerAdapter = new MenuDrawerAdapter(BaseActivity.this, menuDrawerList);
        navList.setAdapter(menuDrawerAdapter);
    }


    public void initViews()
    {

        _SP = getSharedPreferences(Constant.TAG, MODE_PRIVATE);
        _EDITOR = _SP.edit();
        drawer_indicator_LL = (LinearLayout) findViewById(R.id.drawer_indicator_LL);

    }

    public void setToViews() {
    }

    /**
     * Take care of popping the fragment back stack or finishing the activity
     * as appropriate.
     */
    @Override
    public void onBackPressed()
    {
        super.onBackPressed();

        if (drawer_layout.isDrawerVisible(Gravity.RIGHT))
        {
            drawer_layout.closeDrawer(scriminsetrelativeDrawer);
        }
        else
        {
            finish();
        }
    }

    public void clickToViews()
    {
        item_counter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String activity_info = "";

                PackageManager packageManager = BaseActivity.this.getPackageManager();
                try {
                    ActivityInfo  info = packageManager.getActivityInfo(BaseActivity.this.getComponentName(), 0);
                    activity_info = info.toString();

                    Log.v(Constant.TAG, "Activity name:" + info.name);

                } catch (PackageManager.NameNotFoundException e) {

                }

                if(activity_info.length() > 0 && !activity_info.contains("CartActivity"))
                {
                    Intent intent = new Intent(BaseActivity.this, CartActivity.class);
                    startActivityForResult(intent, Constant.NORMAL);
                }


            }
        });


        drawer_layout.addDrawerListener(new DrawerLayout.SimpleDrawerListener()
        {
            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                offset = slideOffset;
                // Sometimes slideOffset ends up so close to but not quite 1 or 0.
                if (slideOffset >= .995)
                {
                    flipped = true;
                    drawerArrowDrawable.setFlip(flipped);
                } else if (slideOffset <= .005)
                {
                    flipped = false;
                    drawerArrowDrawable.setFlip(flipped);
                }

                drawerArrowDrawable.setParameter(offset);
            }
        });

       /* drawer_indicator.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if (drawer_layout.isDrawerVisible(Gravity.RIGHT))
                {
                    drawer_layout.closeDrawer(scriminsetrelativeDrawer);
                }
                else
                {
                    drawer_layout.openDrawer(scriminsetrelativeDrawer);
                }
            }
        });*/

        drawer_indicator_LL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (drawer_layout.isDrawerVisible(Gravity.RIGHT)) {
                    drawer_layout.closeDrawer(scriminsetrelativeDrawer);
                } else {
                    drawer_layout.openDrawer(scriminsetrelativeDrawer);
                }
            }
        });

    }


    public void NavigationPerformClick()
    {
        //drawer_indicator.performClick();
    }

    private class MenuDrawerAdapter extends BaseAdapter
    {

        ArrayList<MenuDrawer_Wrapper> menuDrawerList;
        Context context;


        public MenuDrawerAdapter(Context context, ArrayList<MenuDrawer_Wrapper> menuDrawerList)
        {
            super();
            this.context = context;
            this.menuDrawerList = menuDrawerList;


        }

        @Override
        public int getCount()
        {
            return menuDrawerList.size();
        }

        @Override
        public Object getItem(int position)
        {
            return position;
        }

        @Override
        public long getItemId(int position)
        {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent)
        {
            LayoutInflater layoutInflater = LayoutInflater.from(BaseActivity.this);
            ViewHolder viewHolder;

            if (convertView == null)
            {
                viewHolder = new ViewHolder();
                convertView = layoutInflater.inflate(R.layout.row_menu_drawer, null);

                viewHolder.Title = (TextView) convertView.findViewById(R.id.title);
                viewHolder.Icon = (ImageView) convertView.findViewById(R.id.icon);
                viewHolder.main_RL = (RelativeLayout)convertView.findViewById(R.id.main_RL);
                viewHolder.Icon.setVisibility(View.VISIBLE);
                convertView.setTag(viewHolder);
            }
            else
            {
                viewHolder = (ViewHolder) convertView.getTag();
            }

            MenuDrawer_Wrapper menuDrawerModel = menuDrawerList.get(position);
            //## Setup Data below
            String Name = menuDrawerModel.getName();
            String id = menuDrawerModel.getId();

            viewHolder.Title.setText(menuDrawerModel.getName());

            //            viewHolder.main_RL.setOnClickListener(new ClickToView(BaseActivity.this,position,id,Name));
            viewHolder.Icon.setImageResource(menuDrawerModel.getDrawable_icon());

            return convertView;

        }

        public class ViewHolder
        {
            TextView Title;
            ImageView Icon;
            RelativeLayout main_RL;
        }

    }


    protected class MenuDrawerModel
    {
        private String title;
        private int icon;
        public String Icon_url;

        public MenuDrawerModel(String title, int icon, String icon_url) {
            this.title = title;
            this.icon = icon;
            Icon_url = icon_url;
        }

        public MenuDrawerModel(String title, int icon)
        {
            super();
            this.title = title;
            this.icon = icon;
        }

        public MenuDrawerModel() {
            super();
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title)
        {
            this.title = title;
        }

        public int getIcon() {
            return icon;
        }

        public void setIcon(int icon)
        {
            this.icon = icon;
        }

    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        System.out.println("Logout onActivityResult "+resultCode);
        if(resultCode==Constant.EXIT)
        {
            setResult(Constant.EXIT);
            finish();
        }
    }

    public void updateCart()
    {

       /* BigDecimal total_amt = new BigDecimal(BigInteger.ZERO);
        int itemCount = 0;

        ((AdrTextViewMed)findViewById(R.id.text)).setText(Money.rupees(total_amt).toString());
        ((TextView)findViewById(R.id.item_count)).setText(String.valueOf(itemCount));*/

        new CartCalculation().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
    }


    class CartCalculation extends AsyncTask<String,Void,String>
    {
        BigDecimal total_amt = new BigDecimal(BigInteger.ZERO);
        int itemCount = 0;
        List<Product> productList =  CenterRepository.getCenterRepository().getListOfProductsInShoppingList();

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... params) {

            productList =  CenterRepository.getCenterRepository().getListOfProductsInShoppingList();

            for(Product product : productList)
            {
                int product_amt = Integer.parseInt(product.getSellMRP())*Integer.parseInt(product.getQuantity());
                total_amt = total_amt.add(new BigDecimal(product_amt));
                itemCount = itemCount + Integer.parseInt(product.getQuantity());
            }

            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            ((AdrTextViewMed)findViewById(R.id.text)).setText(Money.rupees(total_amt).toString());
            ((TextView)findViewById(R.id.item_count)).setText(String.valueOf(itemCount));
        }
    }
}

