package com.freshvegitable.Adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import com.freshvegitable.R;
import com.freshvegitable.Wrappers.AddressWrapper;
import com.freshvegitable.Wrappers.Vegitable_Wrapper;
import com.freshvegitable.activities.AddressBookAcitvity;
import com.freshvegitable.activities.VegitableActivity;
import com.freshvegitable.interfaces.ItemTouchHelperAdapter;
import com.freshvegitable.interfaces.OnListFragmentInteractionListener;
import com.freshvegitable.model.CenterRepository;
import com.freshvegitable.model.entities.Product;
import com.freshvegitable.utils.Constant;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import adrViews.AdrBoldTextView;
import adrViews.AdrTextView;


public class AddressRecyclerViewAdapter extends RecyclerView.Adapter<AddressRecyclerViewAdapter.ViewHolder> implements ItemTouchHelperAdapter{

    private  List<AddressWrapper> mValues;
    private  ArrayList<Integer> mValues_id;
    LinkedHashMap<Integer,AddressWrapper> linkedHashMap;
    private final OnListFragmentInteractionListener mListener;
    Context context;

    private OnItemClickListener clickListener;


    @Override
    public boolean onItemMove(int fromPosition, int toPosition) {
        return false;
    }

    @Override
    public void onItemDismiss(int position) {

    }

    public interface OnItemClickListener {
        public void onItemClick(View view, int position);
    }

    public void SetOnItemClickListener(final OnItemClickListener itemClickListener) {
        this.clickListener = itemClickListener;
    }

    public AddressRecyclerViewAdapter(Context context,LinkedHashMap<Integer,AddressWrapper> linkedHashMap, OnListFragmentInteractionListener listener) {
        this.context =context;
        this.linkedHashMap = linkedHashMap;
        mListener = listener;
        this.mValues = new ArrayList<AddressWrapper>(linkedHashMap.values());
        mValues_id = new ArrayList<Integer>(linkedHashMap.keySet());

    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.inflate_address, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {


       final AddressWrapper  addressWrapper = mValues.get(position);
        // final AddressWrapper tempObj = mValues.get(position);
        holder.name.setText(addressWrapper.getName());
        holder.address1.setText(addressWrapper.getAddress1());
        holder.address2.setText(addressWrapper.getAddress2());
        String address3_str = addressWrapper.getCity()+", "+addressWrapper.getState()+" "+addressWrapper.getPincode();
        holder.address3.setText(address3_str);
        holder.mobile_no.setText("Mobile no. "+addressWrapper.getMobile_no());


        holder.edit_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ((AddressBookAcitvity)context).EditAddress(addressWrapper,false);
            }
        });

        holder.delete_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ((AddressBookAcitvity)context).deleteAddress(addressWrapper);
            }
        });


    }

    @Override
    public int getItemCount() {
        return mValues.size();
        //return 10;
    }


    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        public final View mView;
        public  TextView name;
        public  TextView address1 , address2 , address3;
        public TextView mobile_no;
        public  Button edit_btn;
        public  Button delete_btn;
        public AddressWrapper mItem;

        public ViewHolder(View view) {
            super(view);
            mView = view;


            name = (AdrBoldTextView) view.findViewById(R.id.name);
            address1 = (AdrTextView) view.findViewById(R.id.address1);
            address2 = (AdrTextView) view.findViewById(R.id.address2);
            address3 = (AdrTextView) view.findViewById(R.id.address3);
            mobile_no = (AdrTextView) view.findViewById(R.id.mobile_no);
            edit_btn = (Button) view.findViewById(R.id.edit_btn);
            delete_btn = (Button) view.findViewById(R.id.delete_btn);

            mView.setOnClickListener(this);



        }

        @Override
        public String toString() {
            return "";//super.toString() + " '" + mContentDescription.getText() + "'";
        }


        @Override
        public void onClick(View v) {

            clickListener.onItemClick(v, getPosition());
        }
    }


}