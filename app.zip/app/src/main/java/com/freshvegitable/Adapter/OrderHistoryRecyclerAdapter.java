package com.freshvegitable.Adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import com.freshvegitable.R;
import com.freshvegitable.Wrappers.OrderDetails_Wrapper;
import com.freshvegitable.Wrappers.Vegitable_Wrapper;
import com.freshvegitable.activities.VegitableActivity;
import com.freshvegitable.fragments.OrderHistoryListFragment;
import com.freshvegitable.interfaces.ItemTouchHelperAdapter;
import com.freshvegitable.interfaces.OnFragmentInteractionListener;
import com.freshvegitable.interfaces.OnListFragmentInteractionListener;
import com.freshvegitable.model.CenterRepository;
import com.freshvegitable.model.entities.Product;
import com.freshvegitable.utils.Constant;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import adrViews.AdrTextView;


public class OrderHistoryRecyclerAdapter extends RecyclerView.Adapter<OrderHistoryRecyclerAdapter.ViewHolder> implements ItemTouchHelperAdapter{

    private  ArrayList<OrderDetails_Wrapper> mValues;
    private  ArrayList<String> mValues_id;
    LinkedHashMap linkedHashMap;
    private final OnFragmentInteractionListener mListener;
    String numberArr [] = new String[]{"1","2","3","4","5","6","7","8","9"};
    Context context;
    boolean isCartlist = false;

    private OnItemClickListener clickListener;
    private List<OrderDetails_Wrapper> orderhistoryList = new ArrayList<OrderDetails_Wrapper>();

    @Override
    public boolean onItemMove(int fromPosition, int toPosition) {
        return false;
    }

    @Override
    public void onItemDismiss(int position) {

    }

    public interface OnItemClickListener {
        public void onItemClick(View view, int position);
    }

    public void SetOnItemClickListener(final OnItemClickListener itemClickListener) {
        this.clickListener = itemClickListener;
    }

    public OrderHistoryRecyclerAdapter(Context context, LinkedHashMap linkedHashMap , OnFragmentInteractionListener listener) {
        this.context =context;
        this.linkedHashMap = linkedHashMap;
        this.mListener = listener;
        mValues = new ArrayList<OrderDetails_Wrapper>(linkedHashMap.values());
        mValues_id = new ArrayList<String>(linkedHashMap.keySet());

    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.inflate_order_history, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {


        final OrderDetails_Wrapper tempObj = mValues.get(position);


        holder.productName.setText(tempObj.getProductName());
        String status = tempObj.getDeliveryStatus();

        if(status.equalsIgnoreCase("Delivered"))
        {
            String date = tempObj.getDeliveredDate();
            String status_str = status+" on "+date;
        }
        else if(status.equalsIgnoreCase("cancelled"))
        {
            String date = tempObj.getDeliveredDate();
            String status_str = status+" on "+date;
        }
        else
        {
            holder.status.setText(tempObj.getDeliveryStatus());
        }


        //holder.productImage.setImageIcon(null);


    }

    @Override
    public int getItemCount() {

        return mValues.size();
        //return 4;//productList.size();
    }

    public OrderDetails_Wrapper getWrapper(int position)
    {
        final OrderDetails_Wrapper tempObj = mValues.get(position);
        return tempObj;
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        public final View mView;
        public AdrTextView productName,status;
        public ImageView productImage;
        public OrderDetails_Wrapper mItem;

        public ViewHolder(View view) {
            super(view);
            mView = view;


            productName = (AdrTextView) view.findViewById(R.id.productName);
            status = (AdrTextView) view.findViewById(R.id.status);
            productImage = (ImageView) view.findViewById(R.id.productImage);

            mView.setOnClickListener(this);

        }

        @Override
        public String toString() {
            return super.toString() + " '" ;//+ mContentDescription.getText() + "'";
        }


        @Override
        public void onClick(View v) {

            clickListener.onItemClick(v, getPosition());
        }
    }




    private VegitableActivity getContext() {
        // TODO Auto-generated method stub
        return (VegitableActivity) context;
    }

}

