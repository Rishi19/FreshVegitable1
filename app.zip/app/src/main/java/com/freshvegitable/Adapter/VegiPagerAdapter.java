package com.freshvegitable.Adapter;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;


import com.freshvegitable.Wrappers.VegiWrapper;
import com.freshvegitable.activities.VegitableActivity;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Rishi on 12/2/2015.
 */
public class VegiPagerAdapter extends FragmentPagerAdapter
{
    private final String[] TITLES = { "Acheivement", "Pipeline" };
    private List<Fragment> fragments;
    ArrayList<VegiWrapper> set_data_arr;
    Activity activity;

    public VegiPagerAdapter(FragmentManager fm, ArrayList set_data_arr, Activity activity)
    {
        super(fm);
        this.set_data_arr = set_data_arr;
//        this.fragments = fragments;
        this.activity = activity;
    }

    public VegiPagerAdapter(FragmentManager fm, VegitableActivity activity, List<Fragment> fragments) {
        super(fm);
        this.set_data_arr = set_data_arr;
        this.fragments = fragments;
        this.activity = activity;
    }

    @Override
    public Fragment getItem(int position)
    {

        switch (position)
        {

            case 0:
                Bundle bundle = new Bundle();
                bundle.putInt("position", position);
                Fragment fragment = fragments.get(position);
                fragment.setArguments(bundle);
                return fragment;

            case 1:
                return  fragments.get(position);

        }
        return null;
    }

    @Override
    public CharSequence getPageTitle(int position)
    {
        return TITLES[position];
    }

    @Override
    public int getCount()
    {
        return TITLES.length;
    }


}


