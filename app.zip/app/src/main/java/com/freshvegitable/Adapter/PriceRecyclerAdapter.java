package com.freshvegitable.Adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.freshvegitable.R;
import com.freshvegitable.Wrappers.OrderDetails_Wrapper;
import com.freshvegitable.Wrappers.price_wrapper;
import com.freshvegitable.activities.VegitableActivity;
import com.freshvegitable.interfaces.ItemTouchHelperAdapter;
import com.freshvegitable.interfaces.OnFragmentInteractionListener;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import adrViews.AdrTextView;


public class PriceRecyclerAdapter extends RecyclerView.Adapter<PriceRecyclerAdapter.ViewHolder> implements ItemTouchHelperAdapter{

    private  ArrayList<price_wrapper> mValues;
    private  ArrayList<String> mValues_id;
    LinkedHashMap linkedHashMap;
    private final OnFragmentInteractionListener mListener;
    Context context;


    private OnItemClickListener clickListener;
    private List<OrderDetails_Wrapper> orderhistoryList = new ArrayList<OrderDetails_Wrapper>();

    @Override
    public boolean onItemMove(int fromPosition, int toPosition) {
        return false;
    }

    @Override
    public void onItemDismiss(int position) {

    }

    public interface OnItemClickListener {
        public void onItemClick(View view, int position);
    }

    public void SetOnItemClickListener(final OnItemClickListener itemClickListener) {
        this.clickListener = itemClickListener;
    }

    public PriceRecyclerAdapter(Context context, LinkedHashMap linkedHashMap , OnFragmentInteractionListener listener) {
        this.context =context;
        this.linkedHashMap = linkedHashMap;
        this.mListener = listener;
        mValues = new ArrayList<price_wrapper>(linkedHashMap.values());
        mValues_id = new ArrayList<String>(linkedHashMap.keySet());

    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.inflate_price_list, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {


        final price_wrapper tempObj = mValues.get(position);

        holder.name.setText(tempObj.getName());
        holder.name.setText(tempObj.getValue());

    }

    @Override
    public int getItemCount() {

        return mValues.size();
        //return 4;//productList.size();
    }

    public price_wrapper getWrapper(int position)
    {
        final price_wrapper tempObj = mValues.get(position);
        return tempObj;
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        public final View mView;
        public AdrTextView name,value;

        public ViewHolder(View view) {
            super(view);
            mView = view;


            name = (AdrTextView) view.findViewById(R.id.name);
            value = (AdrTextView) view.findViewById(R.id.value);
            mView.setOnClickListener(this);

        }

        @Override
        public String toString() {
            return super.toString() + " '" ;//+ mContentDescription.getText() + "'";
        }


        @Override
        public void onClick(View v) {

            clickListener.onItemClick(v, getPosition());
        }
    }



}

