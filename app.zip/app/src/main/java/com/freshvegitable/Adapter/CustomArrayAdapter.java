package com.freshvegitable.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.freshvegitable.R;


public class CustomArrayAdapter extends ArrayAdapter<String>
{
    private String[] objects;
    private Context context;

    public CustomArrayAdapter(Context context, int resourceId, String[] objects)
    {
        super(context, resourceId, objects);
        this.objects = objects;
        this.context = context;
    }

    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent)
    {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View row = inflater.inflate(R.layout.spinner_dropdown_layout, parent, false);
        TextView label = (TextView) row.findViewById(R.id.spItem);
        label.setText(objects[position]);
        return row;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        return getCustomView(position, convertView, parent);
    }

    public View getCustomView(int position, View convertView, ViewGroup parent)
    {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View row = inflater.inflate(R.layout.spinner_layout, parent, false);
        TextView label = (TextView) row.findViewById(R.id.spItem);
        label.setText(objects[position]);
        return row;
    }

    @Override
    public void setDropDownViewResource(int resource) {
        super.setDropDownViewResource(resource);


    }

    @Override
    public int getItemViewType(int position) {
        return (position);
    }
}