package com.freshvegitable;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.RequiresApi;
import android.support.design.internal.ScrimInsetsFrameLayout;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.widget.PopupMenu;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.freshvegitable.Wrappers.MenuDrawer_Wrapper;
import com.freshvegitable.activities.AddressBookAcitvity;
import com.freshvegitable.activities.CartActivity;
import com.freshvegitable.activities.LoginActivity;
import com.freshvegitable.activities.OrderHistoryActivity;
import com.freshvegitable.activities.UserProfileActivity;
import com.freshvegitable.interfaces.Views;
import com.freshvegitable.model.CenterRepository;
import com.freshvegitable.model.entities.Money;
import com.freshvegitable.model.entities.Product;
import com.freshvegitable.utils.Constant;
import com.freshvegitable.utils.DrawerArrowDrawable;
import com.freshvegitable.utils.RootUtil;
import com.freshvegitable.utils.RoundedImageView;

import java.io.File;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import adrViews.AdrTextViewMed;

import static com.freshvegitable.utils.RootUtil.isRooted;

public class BaseActivity1 extends FragmentActivity implements Views
{
    //public RelativeLayout mRelativeLayout;
    public FrameLayout actContent;
    public ListView navList;
    LinearLayout drawer_List,menu_LL;
    TextView text_emp_name;
    public MenuDrawerAdapter menuDrawerAdapter;
    public ArrayList<MenuDrawer_Wrapper> menuDrawerList = new ArrayList<>();
    public DrawerArrowDrawable drawerArrowDrawable;
    public ImageView drawer_indicator;
    public DrawerLayout drawer_layout;
    public float offset;
    public boolean flipped;
    LinearLayout drawer_indicator_LL;
    ScrimInsetsFrameLayout scriminsetrelativeDrawer;
    CoordinatorLayout coordinatorLayout;
    Toolbar toolbar;
    AdrTextViewMed heading_txt;
    ImageView menu_icon;
    FrameLayout item_counter;
    LinearLayout linearLayout;

    //private DatabaseReference mdatabaseRef;
    public  static final int PERMISSIONS_MULTIPLE_REQUEST = 123;
    public static String FilePath = Environment.getExternalStorageDirectory() + File.separator + "MyAdhaar";


    final String[] navDrawMenuItems = {"Home" , "Login", "Order Hisotry", "Manage Address", "Feedback", "Contact Us", "Terms and Condition", "Developed By"};
    final int[] navDrawMenuIcons = {R.drawable.home_icon1,
            R.drawable.ic_account_circle_black_48dp,
            R.drawable.ic_shopping_basket_black_48dp,
            R.drawable.ic_address,
            R.drawable.ic_bulk_orders,
            R.drawable.edit,
            R.drawable.contact_icon,
            R.drawable.ic_info_dnc,
            R.drawable.ic_info_dnc

    };

    SharedPreferences _SP;
    SharedPreferences.Editor _EDITOR;


    public AdrTextViewMed userName;
    public AdrTextViewMed  userEmail;
    public RoundedImageView userPhoto;
    public ImageView userBackground;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        for (int i = 0; i < navDrawMenuItems.length; i++)
        {
            menuDrawerList.add(new MenuDrawer_Wrapper(""+i,navDrawMenuItems[i], navDrawMenuIcons[i]));
        }

       /* if(isRooted() || RootUtil.isDeviceRooted(this))
        {
            Constant.showToastLong(getApplicationContext(), "Device is Rooted! Please use an unrooted device");
            finish();
        }

        if(RootUtil.isAndroidEmulator())
        {
            Constant.showToastLong(getApplicationContext(), "Device is an emulator! Please use an android device");
            finish();
        }*/



        File dir = new File(Environment.getExternalStorageDirectory() + "/Download");
        if(dir.exists() && dir.isDirectory())
        {
            dir.mkdir();
        }

    }

    @Override
    public void onResume() {
        super.onResume();

        updateCart();

    }

    @Override
    public void setContentView(int layoutResID)

    {
        coordinatorLayout = (CoordinatorLayout) getLayoutInflater().inflate(R.layout.activity_base1, null);
        actContent = (FrameLayout) coordinatorLayout.findViewById(R.id.main);
        // set the drawer dialog_view as main content view of Activity.
        setContentView(coordinatorLayout);
        // add dialog_view of BaseActivities inside framelayout.i.e. frame_container
        getLayoutInflater().inflate(layoutResID, actContent, true);

        drawer_layout = (DrawerLayout) findViewById(R.id.drawer_layout);
        // =========================================

        if (Build.VERSION.SDK_INT >= 23)
        {
            checkPermission();
        }
        else
        {

        }


        //text_emp_name=(TextView)findViewById(R.id.text_emp_name) ;
        _SP = getSharedPreferences(Constant.TAG, MODE_PRIVATE);

        //text_emp_name.setText(_SP.getString("empName",""));
        //scriminsetrelativeDrawer=(LinearLayout)findViewById(R.id.scriminsetrelativeDrawer);
        scriminsetrelativeDrawer=(ScrimInsetsFrameLayout) findViewById(R.id.scriminsetrelativeDrawer);
        navList = (ListView) findViewById(R.id.drawer_List1);
        menuDrawerAdapter = new MenuDrawerAdapter(BaseActivity1.this, menuDrawerList);
        navList.setAdapter(menuDrawerAdapter);


        toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setContentInsetsAbsolute(0,0);
        LayoutInflater mInflater= LayoutInflater.from(this);
        View mCustomView = mInflater.inflate(R.layout.inflate_header_view, null);

        heading_txt = (AdrTextViewMed) mCustomView.findViewById(R.id.text);
        menu_LL = (LinearLayout) mCustomView.findViewById(R.id.menu_LL);
        menu_icon = (ImageView) mCustomView.findViewById(R.id.menu_icon);
        item_counter = (FrameLayout) mCustomView.findViewById(R.id.item_counter);

        final Resources resources = getResources();
        drawerArrowDrawable = new DrawerArrowDrawable(resources);

        drawer_indicator = (ImageView) mCustomView.findViewById(R.id.drawer_indicator);
        drawerArrowDrawable.setStrokeColor(resources.getColor(android.R.color.white));
        drawer_indicator.setImageDrawable(drawerArrowDrawable);

        linearLayout = (LinearLayout) findViewById(R.id.linearLayout);


        userName = (AdrTextViewMed) findViewById(R.id.userName);
        userEmail = (AdrTextViewMed) findViewById(R.id.userEmail);
        userPhoto = (RoundedImageView) findViewById(R.id.userPhoto);
        userBackground = (ImageView) findViewById(R.id.userBackground);

        // =========================================
        heading_txt.setText("Home");
      /*  heading_txt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                *//*showPopup(heading_txt);
                //onInviteClicked();*//*

                //Intent intent = new Intent(MainActivity.this, FireBaseDemo.class);
                //startActivity(intent);
            }
        });*/

        menu_icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                showPopup(menu_LL);
            }
        });

        toolbar.addView(mCustomView);
// =========================================


       /* if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            try
            {
                Resources.Theme theme = this.getTheme();
                TypedArray typedArray = theme.obtainStyledAttributes(new int[]{android.R.attr.colorPrimary});
                drawer_layout.setStatusBarBackground(typedArray.getResourceId(0, 0));
            }
            catch (Exception e)
            {
                Log.e(Constant.TAG,"Exception",e);
            }

            //this.setElevationToolBar(mElevationToolBar);

        }*/

        navList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                Intent intent;
                //                Toast.makeText(getApplicationContext(),"position "+position,30).show();
                Log.i(Constant.TAG,"drawer_position: "+position);
                String activity_info = "";

                PackageManager packageManager = BaseActivity1.this.getPackageManager();
                try {
                    ActivityInfo  info = packageManager.getActivityInfo(BaseActivity1.this.getComponentName(), 0);
                    activity_info = info.toString();

                    Log.v(Constant.TAG, "Activity name:" + info.name);

                } catch (PackageManager.NameNotFoundException e) {

                }

                switch (position)
                {
                    case 0:

                        if(activity_info.length() > 0 && !activity_info.contains("MainActivity"))
                        {
                            intent = new Intent(BaseActivity1.this, MainActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP );
                            intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                            startActivityForResult(intent, Constant.NORMAL);
                        }
                        //
                        break;

                    case 1:

                        intent = new Intent(BaseActivity1.this, LoginActivity.class);
                        startActivityForResult(intent,Constant.NORMAL);
                        //intent = new Intent(BaseActivity.this, SearchActivity.class);
                        //startActivityForResult(intent,Constant.NORMAL);
                        //drawer_indicator.performClick();

                        break;
                    case 2:
                        //intent = new Intent(BaseActivity.this, SearchActivity.class);
                        //startActivityForResult(intent,Constant.NORMAL);
                        //                        drawer_indicator.performClick();

                        //showLogout_Dialog(BaseActivity1.this,getResources().getString(R.string.logout_text));
                        intent = new Intent(BaseActivity1.this, OrderHistoryActivity.class);
                        startActivityForResult(intent,Constant.NORMAL);

                        break;

                    case 3:
                        //intent = new Intent(BaseActivity.this, SearchActivity.class);
                        //startActivityForResult(intent,Constant.NORMAL);
                        //                        drawer_indicator.performClick();

                        if(activity_info.length() > 0 && !activity_info.contains("AddressBookAcitvity")) {
                        intent = new Intent(BaseActivity1.this, AddressBookAcitvity.class);
                        startActivityForResult(intent, Constant.NORMAL);
                    }
                        break;
                    case 4:
                        //intent = new Intent(BaseActivity.this, SearchActivity.class);
                        //intent.putExtra("Type","Complaints");
                        //startActivityForResult(intent,Constant.NORMAL);
                        //                        drawer_indicator.performClick();

                        if(activity_info.length() > 0 && !activity_info.contains("AddressBookAcitvity")) {

                        }
                        break;
                    case 5:
                        //intent = new Intent(BaseActivity.this, SearchActivity.class);
                        //intent.putExtra("Type","Suggestions");
                        //startActivityForResult(intent,Constant.NORMAL);
                        break;
                    case 6:
                        //intent = new Intent(BaseActivity.this, SearchActivity.class);
                        //startActivityForResult(intent,Constant.NORMAL);
                        break;
                    case 7:

                        System.out.println("Logout clickedddddd ");
                        SharedPreferences.Editor editor = getSharedPreferences("my_pref", MODE_PRIVATE).edit();
                        editor.clear();
                        editor.commit();
                        setResult(Constant.EXIT);
                        finish();
                        break;

                    default:
                        break;
                }


                //if (drawer_layout.isDrawerVisible(Gravity.RIGHT))
                {
                    drawer_layout.closeDrawer(scriminsetrelativeDrawer);
                }

            }
        });


      /*  initViews();
        setToViews();
        clickToViews();*/

    }



    public void setMenuDrawer(ArrayList<MenuDrawer_Wrapper> menuDrawerList, String email)
    {
        navList = (ListView) findViewById(R.id.drawer_List1);
        menuDrawerAdapter = new MenuDrawerAdapter(BaseActivity1.this, menuDrawerList);
        navList.setAdapter(menuDrawerAdapter);
    }


    public void initViews()
    {

        _SP = getSharedPreferences(Constant.TAG, MODE_PRIVATE);
        _EDITOR = _SP.edit();
        drawer_indicator_LL = (LinearLayout) findViewById(R.id.drawer_indicator_LL);

    }

    public void setToViews() {

        Log.v(Constant.TAG,"Base setToViews Called");

        this.userName.setText("Welcome");
        this.userEmail.setText("To FreshKart ");
        this.userPhoto.setImageResource(R.drawable.user_icon2);
        this.userBackground.setImageResource(R.drawable.bg_icon1);
    }

    /**
     * Take care of popping the fragment back stack or finishing the activity
     * as appropriate.
     */
    @Override
    public void onBackPressed()
    {
        super.onBackPressed();

        if (drawer_layout.isDrawerVisible(Gravity.RIGHT))
        {
            drawer_layout.closeDrawer(scriminsetrelativeDrawer);
        }
        else
        {
            finish();
        }
    }

    public void clickToViews()
    {
        linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String activity_info = "";

                PackageManager packageManager = BaseActivity1.this.getPackageManager();
                try {
                    ActivityInfo  info = packageManager.getActivityInfo(BaseActivity1.this.getComponentName(), 0);
                    activity_info = info.toString();

                    Log.v(Constant.TAG, "Activity name:" + info.name);

                } catch (PackageManager.NameNotFoundException e) {

                }
                if(activity_info.length() > 0 && !activity_info.contains("UserProfileActivity")) {

                    Intent intent = new Intent(BaseActivity1.this, UserProfileActivity.class);
                    startActivityForResult(intent, Constant.NORMAL);

                    drawer_layout.closeDrawer(scriminsetrelativeDrawer);
                }

            }
        });
        item_counter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String activity_info = "";

                PackageManager packageManager = BaseActivity1.this.getPackageManager();
                try {
                    ActivityInfo  info = packageManager.getActivityInfo(BaseActivity1.this.getComponentName(), 0);
                    activity_info = info.toString();

                    Log.v(Constant.TAG, "Activity name:" + info.name);

                } catch (PackageManager.NameNotFoundException e) {

                }

                if(activity_info.length() > 0 && !activity_info.contains("CartActivity"))
                {
                    Intent intent = new Intent(BaseActivity1.this, CartActivity.class);
                    startActivityForResult(intent, Constant.NORMAL);
                }


            }
        });


        drawer_layout.addDrawerListener(new DrawerLayout.SimpleDrawerListener()
        {
            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                offset = slideOffset;
                // Sometimes slideOffset ends up so close to but not quite 1 or 0.
                if (slideOffset >= .995)
                {
                    flipped = true;
                    drawerArrowDrawable.setFlip(flipped);
                } else if (slideOffset <= .005)
                {
                    flipped = false;
                    drawerArrowDrawable.setFlip(flipped);
                }

                drawerArrowDrawable.setParameter(offset);
            }
        });

       /* drawer_indicator.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if (drawer_layout.isDrawerVisible(Gravity.RIGHT))
                {
                    drawer_layout.closeDrawer(scriminsetrelativeDrawer);
                }
                else
                {
                    drawer_layout.openDrawer(scriminsetrelativeDrawer);
                }
            }
        });*/

        drawer_indicator_LL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (drawer_layout.isDrawerVisible(Gravity.RIGHT)) {
                    drawer_layout.closeDrawer(scriminsetrelativeDrawer);
                } else {
                    drawer_layout.openDrawer(scriminsetrelativeDrawer);
                }
            }
        });

    }


    public void NavigationPerformClick()
    {
        //drawer_indicator.performClick();
    }

    private class MenuDrawerAdapter extends BaseAdapter
    {

        ArrayList<MenuDrawer_Wrapper> menuDrawerList;
        Context context;


        public MenuDrawerAdapter(Context context, ArrayList<MenuDrawer_Wrapper> menuDrawerList)
        {
            super();
            this.context = context;
            this.menuDrawerList = menuDrawerList;


        }

        @Override
        public int getCount()
        {
            return menuDrawerList.size();
        }

        @Override
        public Object getItem(int position)
        {
            return position;
        }

        @Override
        public long getItemId(int position)
        {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent)
        {
            LayoutInflater layoutInflater = LayoutInflater.from(BaseActivity1.this);
            ViewHolder viewHolder;

            if (convertView == null)
            {
                viewHolder = new ViewHolder();
                convertView = layoutInflater.inflate(R.layout.row_menu_drawer, null);

                viewHolder.Title = (TextView) convertView.findViewById(R.id.title);
                viewHolder.Icon = (ImageView) convertView.findViewById(R.id.icon);
                viewHolder.main_RL = (RelativeLayout)convertView.findViewById(R.id.main_RL);
                viewHolder.Icon.setVisibility(View.VISIBLE);
                convertView.setTag(viewHolder);
            }
            else
            {
                viewHolder = (ViewHolder) convertView.getTag();
            }

            MenuDrawer_Wrapper menuDrawerModel = menuDrawerList.get(position);
            //## Setup Data below
            String Name = menuDrawerModel.getName();
            String id = menuDrawerModel.getId();

            viewHolder.Title.setText(menuDrawerModel.getName());

            //            viewHolder.main_RL.setOnClickListener(new ClickToView(BaseActivity.this,position,id,Name));
            viewHolder.Icon.setImageResource(menuDrawerModel.getDrawable_icon());

            return convertView;

        }

        public class ViewHolder
        {
            TextView Title;
            ImageView Icon;
            RelativeLayout main_RL;
        }

    }


    protected class MenuDrawerModel
    {
        private String title;
        private int icon;
        public String Icon_url;

        public MenuDrawerModel(String title, int icon, String icon_url) {
            this.title = title;
            this.icon = icon;
            Icon_url = icon_url;
        }

        public MenuDrawerModel(String title, int icon)
        {
            super();
            this.title = title;
            this.icon = icon;
        }

        public MenuDrawerModel() {
            super();
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title)
        {
            this.title = title;
        }

        public int getIcon() {
            return icon;
        }

        public void setIcon(int icon)
        {
            this.icon = icon;
        }

    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        System.out.println("Logout onActivityResult "+resultCode);
        if(resultCode==Constant.EXIT)
        {
            setResult(Constant.EXIT);
            finish();
        }
    }


    public void updateCart()
    {
      /*List<Product> productList =  CenterRepository.getCenterRepository().getListOfProductsInShoppingList();
        BigDecimal total_amt = new BigDecimal(BigInteger.ZERO);
        int itemCount = 0;

       for(Product product : productList)
       {
          total_amt.add(new BigDecimal(product.getSellMRP()));
           itemCount = itemCount + Integer.parseInt(product.getQuantity());
       }

        ((AdrTextViewMed)findViewById(R.id.text)).setText(Money.rupees(total_amt).toString());
        ((TextView)findViewById(R.id.item_count)).setText(String.valueOf(itemCount));*/

      new CartCalculation().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);

    }

    class CartCalculation extends AsyncTask<String,Void,String>
    {
        BigDecimal total_amt = new BigDecimal(BigInteger.ZERO);
        int itemCount = 0;
        List<Product> productList =  CenterRepository.getCenterRepository().getListOfProductsInShoppingList();

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... params) {

            productList =  CenterRepository.getCenterRepository().getListOfProductsInShoppingList();

            for(Product product : productList)
            {
                int product_amt = Integer.parseInt(product.getSellMRP())*Integer.parseInt(product.getQuantity());
                total_amt = total_amt.add(new BigDecimal(product_amt));
                itemCount = itemCount + Integer.parseInt(product.getQuantity());
            }

            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            ((AdrTextViewMed)findViewById(R.id.text)).setText(Money.rupees(total_amt).toString());
            ((TextView)findViewById(R.id.item_count)).setText(String.valueOf(itemCount));
        }
    }

    public void showLogout_Dialog(Activity activity, String msg){


        final Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);
        dialog.setContentView(R.layout.logout_dialogbox);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        TextView text = (TextView) dialog.findViewById(R.id.description_txt  );
        text.setText(msg);

        Button dialogBtn_no = (Button) dialog.findViewById(R.id.btn_no);
        dialogBtn_no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                    Toast.makeText(getApplicationContext(),"Cancel" ,Toast.LENGTH_SHORT).show();
                dialog.dismiss();

                Intent intent = new Intent(BaseActivity1.this,LoginActivity.class);
                startActivityForResult(intent,Constant.NORMAL);
            }
        });

        Button dialogBtn_yes = (Button) dialog.findViewById(R.id.btn_yes);
        dialogBtn_yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                    Toast.makeText(getApplicationContext(),"Okay" ,Toast.LENGTH_SHORT).show();
                dialog.cancel();
            }
        });

        dialog.show();
    }

    public void showPopup(View v)
    {
        PopupMenu popup = new PopupMenu(BaseActivity1.this, v);
        MenuInflater inflater = popup.getMenuInflater();
        inflater.inflate(R.menu.menu_main, popup.getMenu());
        //MenuPopupHelper menuHelper = new MenuPopupHelper(MainActivity.this, (MenuBuilder) popup.getMenu(), v);
        //menuHelper.setForceShowIcon(true);

        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {

                switch (item.getItemId()) {

                    case R.id.rating:
                        openAppRating(BaseActivity1.this);
                        return true;
                    case R.id.share:
                        shareApp();
                        //onInviteClicked();
                        return true;
                    default:
                        return false;
                }
            }
        });
        popup.show();
    }

    public void shareApp()
    {
        Intent sharingIntent = new Intent(Intent.ACTION_SEND);
        sharingIntent.setType("text/plain");
        String shareBody = "Here is the share content body";
        sharingIntent.putExtra(Intent.EXTRA_SUBJECT, "Subject Here");
        sharingIntent.putExtra(Intent.EXTRA_TEXT, shareBody);
        startActivity(Intent.createChooser(sharingIntent, "Share via"));
    }

    public static void openAppRating(Context context) {
        // you can also use BuildConfig.APPLICATION_ID
        String appId = context.getPackageName();
        Intent rateIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + appId));
        boolean marketFound = false;

        // find all applications able to handle our rateIntent
        final List<ResolveInfo> otherApps = context.getPackageManager().queryIntentActivities(rateIntent, 0);
        for (ResolveInfo otherApp: otherApps)
        {
            // look for Google Play application
            if (otherApp.activityInfo.applicationInfo.packageName.equals("com.rishi.adr_card"))
            {

                ActivityInfo otherAppActivity = otherApp.activityInfo;
                ComponentName componentName = new ComponentName(otherAppActivity.applicationInfo.packageName, otherAppActivity.name);
                // make sure it does NOT open in the stack of your activity
                rateIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                // task reparenting if needed
                rateIntent.addFlags(Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
                // if the Google Play was already open in a search result
                //  this make sure it still go to the app page you requested
                rateIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                // this make sure only the Google Play app is allowed to
                // intercept the intent
                rateIntent.setComponent(componentName);
                context.startActivity(rateIntent);
                marketFound = true;
                break;

            }
        }

        // if GP not present on device, open web browser
        if (!marketFound)
        {
            Intent webIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id="+appId));
            context.startActivity(webIntent);
        }
    }

    public boolean isDirectory_FileExist() {
        File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/aadhar_scanner");
        return file.isDirectory() && new File(file, "AdhaarScanner.xls").exists();
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void checkPermission()
    {
        if (ContextCompat.checkSelfPermission(BaseActivity1.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) + ContextCompat
                .checkSelfPermission(BaseActivity1.this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
        {

            if (ActivityCompat.shouldShowRequestPermissionRationale
                    (BaseActivity1.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) ||
                    ActivityCompat.shouldShowRequestPermissionRationale(BaseActivity1.this, Manifest.permission.CAMERA)) {

                Snackbar.make(coordinatorLayout,
                        "Please Grant Permissions to run app successfully",
                        Snackbar.LENGTH_INDEFINITE).setAction("ENABLE",
                        new View.OnClickListener() {
                            @Override
                            public void onClick(View v)
                            {
                                requestPermissions(new String[]{Manifest.permission
                                        .WRITE_EXTERNAL_STORAGE, Manifest.permission.CAMERA}, PERMISSIONS_MULTIPLE_REQUEST);
                            }
                        }).show();
            }
            else
            {
                requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.CAMERA},
                        PERMISSIONS_MULTIPLE_REQUEST);
            }
        }
        else
        {
            // write your logic code if permission already granted
        }
    }

}

