package com.freshvegitable.interfaces;

import android.webkit.WebView;
import android.widget.ProgressBar;

/**
 * Created by Rishi sahu on 3/2/2017.
 */

public interface FragmentViews {

    public abstract void initViews();
    public abstract void setToViews();
    public abstract void clickToViews();
    public abstract void setwebView(WebView webView, ProgressBar probressbar, String URL);

}
