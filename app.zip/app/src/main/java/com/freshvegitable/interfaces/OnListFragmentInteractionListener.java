package com.freshvegitable.interfaces;

import android.net.Uri;

import com.freshvegitable.Wrappers.Vegitable_Wrapper;

/**
 * Created by Rishi Sahu on 7/23/2017.
 */

public interface OnListFragmentInteractionListener<T> {

    void onListFragmentInteraction(Vegitable_Wrapper item);
    void onFragmentInteraction(Uri uri);
}
