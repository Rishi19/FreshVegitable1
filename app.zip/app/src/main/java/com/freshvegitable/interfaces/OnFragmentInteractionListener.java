package com.freshvegitable.interfaces;

import android.net.Uri;

/**
 * Created by Rishi Sahu on 9/3/2017.
 */

public interface OnFragmentInteractionListener {

        void onFragmentInteraction(Uri uri);

}
