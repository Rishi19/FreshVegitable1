package com.freshvegitable.interfaces;

/**
 * Created by Dell on 19-10-2015.
 */
public interface Views
{
    void initViews();
    void clickToViews();
    void setToViews();

}
