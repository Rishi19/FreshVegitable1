package adrViews;
import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.widget.TextView;

/**
 * @author Prathamesh
 */
public class AdrTextView extends TextView
{
	static Typeface mTypeFace = null;

	public AdrTextView(Context context, AttributeSet attrs, int defStyleAttr)
	{
		super(context, attrs, defStyleAttr);
		initTypeFace();
	}

	public AdrTextView(Context context, AttributeSet attrs)
	{
		super(context, attrs);
		initTypeFace();
	}

	public AdrTextView(Context context)
	{
		super(context);
		initTypeFace();
	}
	
	private void initTypeFace()
	{
		if(!isInEditMode() && mTypeFace == null)
		{
			mTypeFace = Typeface.createFromAsset(getContext().getAssets(), "fonts/Roboto-Regular.ttf");
		}
		if(!isInEditMode())
		{
			setTypeface(mTypeFace);
		}
	}

}
