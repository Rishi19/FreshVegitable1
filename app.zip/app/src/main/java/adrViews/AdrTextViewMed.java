package adrViews;
import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.widget.TextView;

/**
 * @author Rishi
 */
public class AdrTextViewMed extends TextView
{
	static Typeface mTypeFace = null;

	public AdrTextViewMed(Context context, AttributeSet attrs, int defStyleAttr)
	{
		super(context, attrs, defStyleAttr);
		initTypeFace();
	}

	public AdrTextViewMed(Context context, AttributeSet attrs)
	{
		super(context, attrs);
		initTypeFace();
	}

	public AdrTextViewMed(Context context)
	{
		super(context);
		initTypeFace();
	}
	
	private void initTypeFace()
	{
		if(!isInEditMode() && mTypeFace == null)
		{
			mTypeFace = Typeface.createFromAsset(getContext().getAssets(), "fonts/Roboto-Medium.ttf");
		}
		if(!isInEditMode())
		{
			setTypeface(mTypeFace);
		}
	}

}
